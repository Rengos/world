@echo off
chcp 65001 > nul
title Qwen Prompt Enhancer

:: Путь к моделям рядом с папкой
set OLLAMA_MODELS=%~dp0models

:: Проверяем что Ollama установлена
where ollama > nul 2>&1
if errorlevel 1 (
    echo ❌ Ollama не найдена!
    echo Скачай и установи: https://ollama.com/download/windows
    pause
    exit /b 1
)

:: Проверяем что Python установлен
where python > nul 2>&1
if errorlevel 1 (
    echo ❌ Python не найден!
    echo Скачай и установи: https://python.org/downloads
    echo Не забудь галочку "Add Python to PATH"
    pause
    exit /b 1
)

:: Запускаем Ollama в фоне если не запущена
tasklist /fi "imagename eq ollama.exe" | find /i "ollama.exe" > nul 2>&1
if errorlevel 1 (
    echo ⏳ Запускаю Ollama...
    start /min "" ollama serve
    timeout /t 3 /nobreak > nul
) else (
    echo ✅ Ollama уже запущена
)

:: Запускаем enhancer
python "%~dp0prompt_enhancer.py" %*
