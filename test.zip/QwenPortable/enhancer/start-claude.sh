#!/bin/bash
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [ -z "$ANTHROPIC_API_KEY" ]; then
    echo ""
    echo "❌ ANTHROPIC_API_KEY не задан!"
    echo ""
    echo "Добавь в ~/.bashrc или ~/.zshrc:"
    echo "  export ANTHROPIC_API_KEY=sk-ant-твой-ключ"
    echo ""
    echo "Получить ключ: https://console.anthropic.com"
    exit 1
fi

python3 "$SCRIPT_DIR/prompt_enhancer_claude.py" "$@"
