#!/usr/bin/env python3
"""
Prompt Enhancer — Groq API (Llama 3.3 70B) + XML output
=========================================================
Улучшает короткие промпты в XML-структурированные инструкции для Qwen Code.

Использование:
  python prompt_enhancer_groq.py
  python prompt_enhancer_groq.py --once "сделай апи для юзеров"
  python prompt_enhancer_groq.py --key YOUR_GROQ_API_KEY
  python prompt_enhancer_groq.py --no-xml   (plain text режим)
"""

import os
import sys
import json
import time
import argparse
import re
import threading
import urllib.request
import urllib.parse
from pathlib import Path
from difflib import SequenceMatcher

# ── Загрузка .env (без python-dotenv, только stdlib) ─────────────────
_env_file = Path(__file__).parent / ".env"
if _env_file.exists():
    for _line in _env_file.read_text(encoding="utf-8").splitlines():
        _line = _line.strip()
        if _line and not _line.startswith("#") and "=" in _line:
            _k, _v = _line.split("=", 1)
            os.environ.setdefault(_k.strip(), _v.strip())

try:
    from groq import Groq
except ImportError:
    print("Установка groq SDK...")
    os.system(f"{sys.executable} -m pip install groq -q")
    from groq import Groq

# ── Пути ─────────────────────────────────────────────────────────────────────
BASE_DIR      = Path(__file__).parent
EXAMPLES_FILE = BASE_DIR / "prompt_examples.json"
CONFIG_FILE   = BASE_DIR / "groq_config.json"

# ── Конфиг по умолчанию ──────────────────────────────────────────────────────
DEFAULT_CONFIG = {
    "model":            "llama-3.3-70b-versatile",
    "temperature":      0.4,
    "max_tokens":       8192,
    "top_p":            0.9,
    "xml_output":       True,
    "rag_enabled":      True,
    "rag_top_k":        3,
    "rag_min_similarity": 0.35,
    "save_to_examples": True,
    "history_enabled":  True,
    "history_max":      6,
    # === HuggingFace RAG (3 уровня) ===
    "hf_api_key":            "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",
    "hf_codealpha_enabled":  True,
    "hf_codealpha_limit":    3,
    "hf_embed_enabled":      True,
    "hf_embed_model":        "sentence-transformers/all-MiniLM-L6-v2",
    "hf_embed_top_k":        2,
    "hf_timeout":            6
}

# ── Системный промпт — XML режим ─────────────────────────────────────────────
SYSTEM_PROMPT_XML = """Ты — эксперт по составлению промптов для AI-кодинг ассистента Qwen Code.

Твоя задача: преобразовать короткий запрос разработчика в детальный XML-промпт.

ФОРМАТ ОТВЕТА — строго XML, без markdown, без предисловий, без текста вне тегов:

<prompt>
  <task>Одна чёткая задача — что именно нужно создать или сделать</task>

  <context>
    <!-- опционально: что уже есть, особые условия, ограничения -->
  </context>

  <stack>
    <language>TypeScript / Kotlin / Swift / Python / etc</language>
    <framework>Next.js 15 / NestJS / Jetpack Compose / SwiftUI / etc</framework>
    <database>Prisma + PostgreSQL / Drizzle / Room / Core Data / etc</database>
    <libs>дополнительные библиотеки через запятую</libs>
  </stack>

  <requirements>
    <functional>
      <item>конкретное функциональное требование</item>
      <item>ещё одно требование</item>
    </functional>
    <technical>
      <item>архитектурное или техническое требование</item>
      <item>паттерн, best practice</item>
    </technical>
    <security>
      <!-- если применимо: валидация входных данных, аутентификация, защита -->
      <item>требование безопасности</item>
    </security>
  </requirements>

  <code_example>
    <!-- ключевой фрагмент кода — только если структура неочевидна -->
  </code_example>

  <output>
    <format>TypeScript файлы / Kotlin классы / Swift файлы / etc</format>
    <includes>unit тесты / JSDoc / миграции БД / OpenAPI схема</includes>
    <quality>строгая типизация, обработка ошибок, читаемый код</quality>
  </output>
</prompt>

ПРАВИЛА:
1. Отвечай ТОЛЬКО XML — никакого текста до <prompt> или после </prompt>
2. Все описания на РУССКОМ языке (кроме названий технологий и кода)
3. Пропускай секции которые не нужны для задачи (не пиши пустые теги)
4. <code_example> добавляй только когда структура кода неочевидна
5. <item> элементы — короткие конкретные фразы, не абзацы
6. Указывай конкретные версии и названия: не "ORM", а "Prisma 5.x"
7. Секция <security> только если задача связана с данными пользователей или авторизацией"""

# ── Системный промпт — plain text режим ──────────────────────────────────────
SYSTEM_PROMPT_TEXT = """Ты — эксперт-ассистент для улучшения промптов для AI-кодинг ассистента Qwen Code.

Преобразуй короткий запрос в детальный структурированный промпт.

ПРАВИЛА:
1. Отвечай ТОЛЬКО улучшенным промптом — без предисловий и комментариев
2. Используй конкретные технологии (TypeScript, React, Node.js, Prisma и т.д.)
3. Включай: архитектуру, структуру кода, обработку ошибок, типизацию, тесты
4. Добавляй примеры кода в markdown блоках где уместно
5. Структурируй через заголовки и списки
6. На РУССКОМ языке, 200-600 слов"""


# ── RAG ───────────────────────────────────────────────────────────────────────
def load_examples() -> list:
    if not EXAMPLES_FILE.exists():
        return []
    try:
        with open(EXAMPLES_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        # Если это список - возвращаем как есть
        if isinstance(data, list):
            return data
        # Если это объект с полем examples - возвращаем examples
        if isinstance(data, dict):
            return data.get("examples", [])
        return []
    except Exception:
        return []


def similarity(a: str, b: str) -> float:
    return SequenceMatcher(None, a.lower(), b.lower()).ratio()


def find_similar_text(query: str, examples: list, top_k: int = 3, min_sim: float = 0.35) -> list:
    """Текстовый поиск (fallback для векторного)."""
    if not examples:
        return []
    scored = []
    for ex in examples:
        score = (
            similarity(query, ex.get("short", "")) * 0.7 +
            max((similarity(query, t) for t in ex.get("tags", [])), default=0) * 0.3
        )
        if score >= min_sim:
            scored.append((score, ex))
    scored.sort(key=lambda x: x[0], reverse=True)
    return [ex for _, ex in scored[:top_k]]


def build_rag_context(similar: list) -> str:
    if not similar:
        return ""
    lines = ["Похожие примеры из базы знаний (используй как образец стиля и детализации):"]
    for i, ex in enumerate(similar, 1):
        enhanced = ex.get("enhanced", "")
        source = ex.get("source", "локальная база")
        lines.append(f"\n[Пример {i} | {source}] Запрос: {ex['short']}")
        lines.append(f"Теги: {', '.join(ex.get('tags', []))}")
        lines.append(f"Промпт:\n{enhanced[:500]}{'...' if len(enhanced) > 500 else ''}")
    return "\n".join(lines)


# ── HUGGINGFACE RAG — УРОВЕНЬ 2 И 3 ───────────────────────────────────────────
# === НОВАЯ ФУНКЦИЯ: _http_get ===
def _http_get(url: str, headers: dict, timeout: int) -> dict | None:
    """Выполнить GET запрос и вернуть JSON или None при ошибке."""
    try:
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode())
    except Exception:
        return None


# === НОВАЯ ФУНКЦИЯ: _http_post ===
def _http_post(url: str, headers: dict, body: dict, timeout: int) -> dict | None:
    """Выполнить POST запрос и вернуть JSON или None при ошибке."""
    try:
        data = json.dumps(body).encode()
        req = urllib.request.Request(url, data=data, headers=headers, method="POST")
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode())
    except Exception:
        return None


# === НОВАЯ ФУНКЦИЯ: search_codealpha ===
def search_codealpha(query: str, config: dict) -> list[dict]:
    """Уровень 2: Поиск по CodeAlpaca-20k через HuggingFace Datasets Server API."""
    url = (
        "https://datasets-server.huggingface.co/search"
        "?dataset=sahil2801%2FCodeAlpaca-20k"
        "&config=default&split=train"
        f"&query={urllib.parse.quote(query[:200])}"
        f"&offset=0&limit={config['hf_codealpha_limit']}"
    )
    headers = {
        "Accept": "application/json",
        "Authorization": f"Bearer {config['hf_api_key']}"
    }
    data = _http_get(url, headers, config["hf_timeout"])
    if not data:
        return []

    results = []
    for item in data.get("rows", []):
        row = item.get("row", {})
        instruction = row.get("instruction", "").strip()
        output = row.get("output", "").strip()
        if not instruction:
            continue
        results.append({
            "short":    instruction[:200],
            "enhanced": output[:600],
            "tags":     ["general"],
            "source":   "CodeAlpaca-20k"
        })
    return results


# === НОВАЯ ФУНКЦИЯ: get_embedding ===
def get_embedding(text: str, config: dict) -> list[float]:
    """Получить embedding вектор через HuggingFace Inference API."""
    url = f"https://api-inference.huggingface.co/pipeline/feature-extraction/{config['hf_embed_model']}"
    headers = {
        "Authorization": f"Bearer {config['hf_api_key']}",
        "Content-Type": "application/json"
    }
    body = {"inputs": text[:512], "options": {"wait_for_model": True}}
    data = _http_post(url, headers, body, config["hf_timeout"])
    if not data:
        return []

    try:
        import numpy as np
        arr = np.array(data)
        if arr.ndim == 2:
            return arr.mean(axis=0).tolist()
        return arr.tolist()
    except Exception:
        return []


# === НОВАЯ ФУНКЦИЯ: cosine_sim ===
def cosine_sim(a: list[float], b: list[float]) -> float:
    """Косинусное сходство двух векторов."""
    try:
        import numpy as np
        va, vb = np.array(a), np.array(b)
        denom = np.linalg.norm(va) * np.linalg.norm(vb)
        return float(np.dot(va, vb) / denom) if denom > 0 else 0.0
    except Exception:
        return 0.0


# === НОВАЯ ФУНКЦИЯ: search_semantic ===
def search_semantic(query: str, examples: list, config: dict) -> list[dict]:
    """Уровень 3: Семантический поиск по локальной базе через HF Embeddings."""
    q_emb = get_embedding(query, config)
    if not q_emb:
        return []

    scored = []
    for ex in examples:
        emb = ex.get("embedding", [])
        if not emb:
            emb = get_embedding(ex.get("short", ""), config)
            ex["embedding"] = emb
        if not emb:
            continue
        score = cosine_sim(q_emb, emb)
        if score >= 0.45:
            scored.append((score, ex))

    scored.sort(key=lambda x: x[0], reverse=True)
    top = [ex for _, ex in scored[:config["hf_embed_top_k"]]]

    if top:
        print(f"  🧠 Семантика: +{len(top)} примеров (cosine)")
    return top


# ── XML обработка ─────────────────────────────────────────────────────────────
def clean_xml(raw: str) -> str:
    """Извлечь чистый XML — убрать markdown блоки и лишний текст."""
    raw = raw.strip()
    # Убрать ```xml ... ``` обёртку
    raw = re.sub(r"^```(?:xml)?\s*\n?", "", raw)
    raw = re.sub(r"\n?```\s*$", "", raw)
    raw = raw.strip()
    # Обрезать до <prompt> ... </prompt>
    start = raw.find("<prompt>")
    end   = raw.find("</prompt>")
    if start != -1 and end != -1:
        return raw[start:end + len("</prompt>")].strip()
    return raw.strip()


def is_valid_xml(text: str) -> bool:
    return "<prompt>" in text and "</prompt>" in text and "<task>" in text


# ── Копирование в буфер ───────────────────────────────────────────────────────
def copy_to_clipboard(text: str) -> bool:
    try:
        import subprocess
        if sys.platform == "win32":
            subprocess.run("clip", input=text.encode("utf-8"),
                           capture_output=True, shell=True, check=True)
        elif sys.platform == "darwin":
            subprocess.run("pbcopy", input=text.encode("utf-8"),
                           capture_output=True, check=True)
        else:
            subprocess.run(["xclip", "-selection", "clipboard"],
                           input=text.encode("utf-8"), capture_output=True, check=True)
        return True
    except Exception:
        return False


# ── УЛУЧШЕНИЕ 4 — Авто-выбор скилла ───────────────────────────────────────────
SKILL_MAP = {
    "fullstack":              ["api", "endpoint", "rest", "роут", "сервер", "nextjs", "nestjs", "express", "fastapi", "fullstack", "бэкенд", "фронтенд"],
    "security_guardian":      ["auth", "jwt", "oauth", "безопасност", "xss", "csrf", "шифрован", "пароль", "токен", "авториз", "аутентифик"],
    "testing_expert":         ["тест", "testing", "jest", "vitest", "playwright", "e2e", "unit", "coverage", "моки"],
    "performance_optimizer":  ["оптимизац", "производительност", "кэш", "redis", "cache", "быстро", "медленно", "n+1", "индекс", "performance", "latency"],
    "refactoring_specialist": ["рефактор", "refactor", "чист", "clean", "паттерн", "solid", "dry", "дублир"],
    "documentation_writer":   ["документац", "readme", "jsdoc", "swagger", "openapi", "changelog", "комментар"],
    "android_team":           ["android", "kotlin", "compose", "jetpack", "room", "retrofit", "hilt"],
    "apple_design_system":    ["ios", "swift", "swiftui", "xcode", "uikit", "core data", "combine"],
    "code_reviewer":          ["ревью", "review", "проверь", "улучши код", "code review", "качество кода"],
    "failure_observer":       ["баг", "bug", "ошибк", "debug", "отладк", "падает", "не работает", "fix"],
    "deep_reasoning":         ["архитектур", "проектирован", "спроектируй", "design", "структур"],
}

def detect_skill(prompt: str) -> str | None:
    """Определить скилл по ключевым словам."""
    prompt_lower = prompt.lower()
    for skill, keywords in SKILL_MAP.items():
        if any(kw in prompt_lower for kw in keywords):
            return skill
    return None


# ── УЛУЧШЕНИЕ 5 — Векторный поиск ─────────────────────────────────────────────
class VectorIndex:
    """Семантический поиск через sentence-transformers.
    
    Модель: paraphrase-multilingual-MiniLM-L12-v2
    Размер: ~60MB, CPU, русский язык поддерживается.
    Ленивая загрузка — модель грузится при первом поиске.
    Fallback на SequenceMatcher если модель недоступна.
    """
    MODEL_NAME = "paraphrase-multilingual-MiniLM-L12-v2"

    def __init__(self) -> None:
        self._model = None

    def _load(self):
        """Загрузить модель при первом обращении."""
        if self._model is None:
            try:
                from sentence_transformers import SentenceTransformer
                print("  🧠 Загружаю векторную модель (первый запуск ~10с)...")
                self._model = SentenceTransformer(self.MODEL_NAME)
                print("  ✅ Векторная модель готова\n")
            except Exception as e:
                print(f"  ⚠️  Модель недоступна ({e}), использую текстовый поиск\n")
        return self._model

    def encode(self, text: str):
        """Получить embedding. None если модель недоступна."""
        model = self._load()
        if model is None:
            return None
        import numpy as np
        return model.encode(text, convert_to_numpy=True)

    def cosine(self, a, b) -> float:
        """Косинусное сходство двух векторов."""
        import numpy as np
        if a is None or b is None:
            return 0.0
        norm = np.linalg.norm(a) * np.linalg.norm(b)
        return float(np.dot(a, b) / (norm + 1e-9))

    def search(self, query: str, examples: list,
               top_k: int = 3, min_sim: float = 0.5) -> list:
        """Найти top_k похожих примеров.
        Fallback на find_similar_text() если модель недоступна.
        """
        import numpy as np
        model = self._load()
        if model is None:
            return find_similar_text(query, examples, top_k, min_sim=0.35)

        query_vec = self.encode(query)
        scored = []
        for ex in examples:
            if not ex.get("approved", True):
                continue
            emb = ex.get("embedding")
            if emb and len(emb) > 0:
                vec = np.array(emb, dtype=np.float32)
            else:
                vec = self.encode(ex.get("short", ""))
            score = self.cosine(query_vec, vec)
            if score >= min_sim:
                scored.append((score, ex))

        scored.sort(key=lambda x: x[0], reverse=True)
        return [ex for _, ex in scored[:top_k]]


# ── Groq клиент ───────────────────────────────────────────────────────────────
class GroqEnhancer:
    def __init__(self, api_key: str, config: dict):
        self.client   = Groq(api_key=api_key)
        self.config   = config
        self.examples = load_examples()
        self.history: list = []
        # Улучшение 5 — векторный индекс
        self.vec_index = VectorIndex() if config.get("vector_search", True) else None

    def enhance(self, prompt: str, update_uses: bool = True) -> str:
        xml_mode = self.config.get("xml_output", True)
        system   = SYSTEM_PROMPT_XML if xml_mode else SYSTEM_PROMPT_TEXT
        messages = []

        # ── Уровень 1: локальный RAG (синхронно, быстро) ──
        local_similar = []
        if self.config["rag_enabled"] and self.examples:
            if self.vec_index:
                local_similar = self.vec_index.search(
                    prompt, self.examples,
                    top_k=self.config["rag_top_k"],
                    min_sim=self.config["rag_min_similarity"]
                )
            else:
                local_similar = find_similar_text(
                    prompt, self.examples,
                    top_k=self.config["rag_top_k"],
                    min_sim=self.config["rag_min_similarity"]
                )
            if local_similar and update_uses:
                for ex in local_similar:
                    ex["uses"] = ex.get("uses", 0) + 1
                try:
                    with open(EXAMPLES_FILE, "w", encoding="utf-8") as f:
                        json.dump(self.examples, f, ensure_ascii=False, indent=2)
                except:
                    pass

        # ── Уровни 2 и 3: онлайн параллельно ──
        codealpha_results = []
        semantic_results  = []
        threads = []

        if self.config.get("hf_codealpha_enabled") and self.config.get("hf_api_key"):
            def _fetch_codealpha():
                nonlocal codealpha_results
                codealpha_results = search_codealpha(prompt, self.config)
                if codealpha_results:
                    print(f"  🌐 CodeAlpaca: +{len(codealpha_results)} онлайн")
            t1 = threading.Thread(target=_fetch_codealpha, daemon=True)
            threads.append(t1)
            t1.start()

        if self.config.get("hf_embed_enabled") and self.config.get("hf_api_key") and self.examples:
            def _fetch_semantic():
                nonlocal semantic_results
                semantic_results = search_semantic(prompt, self.examples, self.config)
            t2 = threading.Thread(target=_fetch_semantic, daemon=True)
            threads.append(t2)
            t2.start()

        for t in threads:
            t.join(timeout=self.config.get("hf_timeout", 6) + 1)

        # ── Объединить результаты (дедупликация по short) ──
        seen = set()
        combined = []
        for ex in local_similar + semantic_results + codealpha_results:
            key = ex.get("short", "")[:80]
            if key not in seen:
                seen.add(key)
                combined.append(ex)

        if combined:
            rag_ctx = build_rag_context(combined)
            messages.append({"role": "user",      "content": rag_ctx})
            messages.append({"role": "assistant", "content": "Понял, учту эти примеры."})

        # История диалога
        if self.config["history_enabled"]:
            messages.extend(self.history[-self.config["history_max"]:])

        # Запрос
        user_msg = (
            f"Создай XML-промпт для задачи (ответ ТОЛЬКО XML, начни с <prompt>):\n\n{prompt}"
            if xml_mode
            else f"Улучши этот промпт:\n\n{prompt}"
        )
        messages.append({"role": "user", "content": user_msg})

        try:
            t0 = time.time()
            response = self.client.chat.completions.create(
                model=self.config["model"],
                messages=[{"role": "system", "content": system}] + messages,
                temperature=self.config["temperature"],
                max_tokens=self.config["max_tokens"],
                top_p=self.config["top_p"],
            )
            elapsed = time.time() - t0
            raw    = response.choices[0].message.content.strip()
            result = clean_xml(raw) if xml_mode else raw

            # Повтор если XML не распознан
            if xml_mode and not is_valid_xml(result):
                print("  ⚠️  XML не распознан, повторяю с пониженной температурой...")
                messages[-1]["content"] = (
                    f"Задача: {prompt}\n\n"
                    "Ответь ТОЛЬКО валидным XML начиная с тега <prompt> и заканчивая </prompt>. "
                    "Никакого текста вне XML тегов."
                )
                response = self.client.chat.completions.create(
                    model=self.config["model"],
                    messages=[{"role": "system", "content": system}] + messages,
                    temperature=0.15,
                    max_tokens=self.config["max_tokens"],
                    top_p=0.9,
                )
                raw    = response.choices[0].message.content.strip()
                result = clean_xml(raw)

            # Обновить историю
            if self.config["history_enabled"]:
                self.history.append({"role": "user",      "content": user_msg})
                self.history.append({"role": "assistant", "content": result[:600]})

            # Статус
            usage = response.usage
            print(f"\n  ⚡ {elapsed:.1f}s | "
                  f"in: {usage.prompt_tokens} / out: {usage.completion_tokens} токенов | "
                  f"{'XML' if xml_mode else 'TEXT'}")

            # УЛУЧШЕНИЕ 4 — Авто-выбор скилла
            detected_skill = detect_skill(prompt)
            if detected_skill:
                if xml_mode and is_valid_xml(result):
                    # Вставить <skill> перед </prompt>
                    if "<skill>" not in result:
                        result = result.replace("</prompt>", f"  <skill>{detected_skill}</skill>\n</prompt>")
                else:
                    result += f"\n\nАктивируй скилл: {detected_skill}"

            # Сохранить новый пример
            if self.config["save_to_examples"]:
                self._save_example(prompt, result, detected_skill)

            return result

        except Exception as e:
            err = str(e)
            if "rate_limit" in err.lower():
                print("  ⚠️  Rate limit — жду 30 секунд...")
                time.sleep(30)
                return self.enhance(prompt)
            elif "invalid_api_key" in err.lower():
                raise ValueError("❌ Неверный Groq API ключ. Получи на https://console.groq.com/keys")
            raise

    def _save_example(self, short: str, enhanced: str, detected_skill: str | None = None):
        """Авто-сохранение нового примера в RAG базу с дедупликацией (Улучшение 5)."""
        # УЛУЧШЕНИЕ 5 — Дедупликация перед сохранением
        if self.examples:
            max_sim = max(
                similarity(short, ex.get("short", ""))
                for ex in self.examples
            )
            if max_sim >= 0.85:
                # Найти лучший дубликат и увеличить uses
                best = max(self.examples,
                          key=lambda ex: similarity(short, ex.get("short", "")))
                best["uses"] = best.get("uses", 0) + 1
                with open(EXAMPLES_FILE, "w", encoding="utf-8") as f:
                    json.dump(self.examples, f, ensure_ascii=False, indent=2)
                return  # не создавать дубликат

        tag_map = {
            "api":         ["api", "endpoint", "rest", "роут", "сервер"],
            "react":       ["react", "компонент", "хук", "jsx"],
            "typescript":  ["typescript", "ts", "тип", "generic"],
            "auth":        ["авториз", "аутентифик", "jwt", "oauth"],
            "database":    ["база", "бд", "sql", "prisma", "drizzle"],
            "testing":     ["тест", "jest", "vitest", "playwright"],
            "security":    ["безопасност", "xss", "csrf", "шифрован"],
            "performance": ["оптимизац", "производительност", "кэш"],
            "android":     ["android", "kotlin", "compose"],
            "ios":         ["ios", "swift", "swiftui"],
            "devops":      ["docker", "ci/cd", "kubernetes", "deploy"],
        }
        tags = [tag for tag, kws in tag_map.items()
                if any(kw in short.lower() for kw in kws)] or ["general"]

        # УЛУЧШЕНИЕ 5 — вычисляем embedding при сохранении
        emb = None
        if self.vec_index:
            emb = self.vec_index.encode(short)

        self.examples.append({
            "id":         str(len(self.examples) + 1).zfill(4),
            "tags":       tags,
            "short":      short,
            "enhanced":   enhanced,
            "skill":      detected_skill,  # УЛУЧШЕНИЕ 4
            "approved":   False,
            "uses":       0,
            "created_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
            "embedding":  emb.tolist() if emb is not None else []  # УЛУЧШЕНИЕ 5
        })
        try:
            with open(EXAMPLES_FILE, "w", encoding="utf-8") as f:
                json.dump(self.examples, f, ensure_ascii=False, indent=2)
        except Exception:
            pass

    def cleanup_dead_examples(self, min_uses: int = 0, older_than_days: int = 30):
        """УЛУЧШЕНИЕ 1 — Очистка мёртвых примеров."""
        from datetime import datetime, timedelta
        
        if not self.examples:
            print("  База пуста\n")
            return
        
        cutoff = datetime.now() - timedelta(days=older_than_days)
        to_delete = []
        
        for i, ex in enumerate(self.examples):
            if ex.get("approved", True) and ex.get("uses", 0) == min_uses:
                created_at = ex.get("created_at")
                if not created_at:
                    to_delete.append(i)  # нет даты — считаем старым
                else:
                    try:
                        created = datetime.fromisoformat(created_at)
                        if created < cutoff:
                            to_delete.append(i)
                    except:
                        to_delete.append(i)
        
        if not to_delete:
            print(f"  Нет примеров для очистки (uses={min_uses}, days={older_than_days})\n")
            return
        
        print(f"\n  Найдено {len(to_delete)} старых примеров с uses={min_uses}:")
        for i in to_delete[:5]:  # показать первые 5
            ex = self.examples[i]
            print(f"    - {ex.get('created_at', 'unknown')}: {ex['short'][:50]}")
        if len(to_delete) > 5:
            print(f"    ... и ещё {len(to_delete) - 5}")
        
        answer = input(f"\n  Удалить {len(to_delete)} примеров? (д/н): ").strip().lower()
        if answer == "д":
            # Удалять с конца чтобы индексы не сбились
            for i in sorted(to_delete, reverse=True):
                del self.examples[i]
            try:
                with open(EXAMPLES_FILE, "w", encoding="utf-8") as f:
                    json.dump(self.examples, f, ensure_ascii=False, indent=2)
                print(f"  ✅ Удалено {len(to_delete)} примеров\n")
            except Exception as e:
                print(f"  ❌ Ошибка сохранения: {e}\n")
        else:
            print("  Отменено\n")


# ── Интерактивный режим ───────────────────────────────────────────────────────
def interactive_mode(enhancer: GroqEnhancer):
    xml_mode = enhancer.config.get("xml_output", True)
    print("\n" + "═" * 62)
    print(f"  🚀 Prompt Enhancer  |  Groq Llama 3.3 70B  |  {'XML' if xml_mode else 'TEXT'} режим")
    print("  Команды: выход  режим  история  очистить  статус  онлайн  семантика")
    print("═" * 62 + "\n")

    while True:
        try:
            user_input = input("📝 Промпт: ").strip()
        except (KeyboardInterrupt, EOFError):
            print("\n👋 До свидания!")
            break

        if not user_input:
            continue

        cmd = user_input.lower()

        if cmd in ("выход", "exit", "quit", "q"):
            print("👋 До свидания!")
            break

        elif cmd == "режим":
            enhancer.config["xml_output"] = not enhancer.config.get("xml_output", True)
            save_config(enhancer.config)
            mode = "XML" if enhancer.config["xml_output"] else "TEXT"
            print(f"  ✅ Режим: {mode}\n")
            continue

        elif cmd == "история":
            if not enhancer.history:
                print("  История пуста\n")
            else:
                for msg in enhancer.history:
                    role = "Вы" if msg["role"] == "user" else "AI"
                    print(f"  [{role}]: {msg['content'][:120]}...")
                print()
            continue

        elif cmd == "очистить":
            enhancer.history.clear()
            print("  ✅ История диалога очищена\n")
            continue

        elif cmd == "статус":
            mode = "XML" if enhancer.config.get("xml_output", True) else "TEXT"
            hf_key = enhancer.config.get("hf_api_key", "")
            key_str = f"***{hf_key[-4:]}" if hf_key else "не задан"
            print(f"\n  Модель:       {enhancer.config['model']}")
            print(f"  Режим:        {mode}")
            print(f"  RAG:          {'вкл' if enhancer.config['rag_enabled'] else 'выкл'}")
            print(f"  Примеров RAG: {len(enhancer.examples)}")
            print(f"  История:      {len(enhancer.history) // 2} пар")
            print(f"  HF API ключ:  {key_str}")
            print(f"  CodeAlpaca онлайн: {'вкл ✅' if enhancer.config.get('hf_codealpha_enabled') else 'выкл'}")
            print(f"  Семантика (emb): {'вкл ✅' if enhancer.config.get('hf_embed_enabled') else 'выкл'}\n")
            continue

        elif cmd == "онлайн":
            enhancer.config["hf_codealpha_enabled"] = not enhancer.config.get("hf_codealpha_enabled", False)
            save_config(enhancer.config)
            status = "включён ✅" if enhancer.config["hf_codealpha_enabled"] else "выключен"
            print(f"  CodeAlpaca онлайн: {status}\n")
            continue

        elif cmd == "семантика":
            # Проверяем numpy перед включением
            if not enhancer.config.get("hf_embed_enabled", False):
                try:
                    import numpy
                except ImportError:
                    print("  ⚙️  Устанавливаю numpy...")
                    os.system(f"{sys.executable} -m pip install numpy -q")
            enhancer.config["hf_embed_enabled"] = not enhancer.config.get("hf_embed_enabled", False)
            save_config(enhancer.config)
            status = "включена ✅" if enhancer.config["hf_embed_enabled"] else "выключена"
            print(f"  Семантический RAG: {status}\n")
            continue

        elif cmd == "очистка":
            enhancer.cleanup_dead_examples()
            continue

        elif cmd == "индекс":
            # Улучшение 5 — пересчитать embeddings
            if enhancer.vec_index is None:
                print("  ⚠️  Векторный поиск выключен (--no-vector)\n")
                continue
            model = enhancer.vec_index._load()
            if model is None:
                print("  ❌ Модель sentence-transformers недоступна\n")
                continue
            count = 0
            total = len(enhancer.examples)
            for i, ex in enumerate(enhancer.examples):
                if not ex.get("embedding"):
                    import numpy as np
                    vec = enhancer.vec_index.encode(ex.get("short", ""))
                    if vec is not None:
                        ex["embedding"] = vec.tolist()
                        count += 1
                if (i + 1) % 20 == 0:
                    print(f"  ⏳ {i+1}/{total}...")
            try:
                with open(EXAMPLES_FILE, "w", encoding="utf-8") as f:
                    json.dump(enhancer.examples, f, ensure_ascii=False, indent=2)
                print(f"  ✅ Проиндексировано {count} новых примеров\n")
            except Exception as e:
                print(f"  ❌ Ошибка сохранения: {e}\n")
            continue

        # ── Генерация ─────────────────────────────────────────────────────────
        hint = "XML-промпт" if enhancer.config.get("xml_output") else "промпт"
        print(f"\n  ⏳ Генерирую {hint}...\n")

        try:
            result = enhancer.enhance(user_input)
            print("\n" + "─" * 62)
            print("✨ РЕЗУЛЬТАТ:")
            print("─" * 62)
            print(result)
            print("─" * 62)

            if copy_to_clipboard(result):
                print("  📋 Скопировано в буфер обмена\n")

            # УЛУЧШЕНИЕ 3 — Запрос обратной связи
            if enhancer.config.get("save_to_examples", True):
                feedback = input("  Результат хороший? (д/н/enter=пропустить): ").strip().lower()
                if feedback == "н":
                    # найти последний сохранённый пример и установить approved=False
                    if enhancer.examples:
                        last = enhancer.examples[-1]
                        last["approved"] = False
                        try:
                            with open(EXAMPLES_FILE, "w", encoding="utf-8") as f:
                                json.dump(enhancer.examples, f, ensure_ascii=False, indent=2)
                            print("  ✅ Помечен как неудачный, не будет использоваться в RAG\n")
                        except:
                            pass
                elif feedback == "д":
                    # найти последний пример и увеличить uses
                    if enhancer.examples:
                        last = enhancer.examples[-1]
                        last["uses"] = last.get("uses", 0) + 1
                        last["approved"] = True
                        try:
                            with open(EXAMPLES_FILE, "w", encoding="utf-8") as f:
                                json.dump(enhancer.examples, f, ensure_ascii=False, indent=2)
                            print("  ✅ Пример усилен в базе\n")
                        except:
                            pass
                else:
                    print()
            else:
                print()

        except Exception as e:
            print(f"\n  ❌ Ошибка: {e}\n")


# ── Конфиг I/O ────────────────────────────────────────────────────────────────
def load_config() -> dict:
    if CONFIG_FILE.exists():
        try:
            with open(CONFIG_FILE) as f:
                return {**DEFAULT_CONFIG, **json.load(f)}
        except Exception:
            pass
    return DEFAULT_CONFIG.copy()


def save_config(config: dict):
    try:
        with open(CONFIG_FILE, "w") as f:
            json.dump(config, f, indent=2)
    except Exception:
        pass


# ── Main ──────────────────────────────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(description="Groq Prompt Enhancer — XML + RAG")
    parser.add_argument("--key",     help="Groq API ключ (или env GROQ_API_KEY)")
    parser.add_argument("--once",    help="Улучшить один промпт и выйти")
    parser.add_argument("--model",   help="Модель Groq")
    parser.add_argument("--no-xml",  action="store_true", help="Plain text вместо XML")
    parser.add_argument("--no-rag",  action="store_true", help="Отключить RAG")
    parser.add_argument("--no-save", action="store_true", help="Не сохранять примеры")
    parser.add_argument("--no-vector", action="store_true", help="Отключить векторный поиск (Улучшение 5)")
    args = parser.parse_args()

    # API ключ
    api_key = args.key or os.environ.get("GROQ_API_KEY")
    if not api_key:
        api_key = load_config().get("api_key")
    if not api_key:
        print("\n🔑 Groq API ключ не найден.")
        print("   Получи бесплатно: https://console.groq.com/keys\n")
        api_key = input("   Введи API ключ: ").strip()
        if not api_key:
            print("❌ Ключ не введён. Выход.")
            sys.exit(1)

    # Собрать конфиг
    config = load_config()
    config["api_key"] = api_key
    if args.model:      config["model"]       = args.model
    if args.no_xml:     config["xml_output"]  = False
    if args.no_rag:     config["rag_enabled"] = False
    if args.no_save:    config["save_to_examples"] = False
    if args.no_vector:  config["vector_search"] = False  # Улучшение 5
    save_config(config)

    # Старт
    enhancer = GroqEnhancer(api_key=api_key, config=config)
    mode_str = "XML" if config.get("xml_output", True) else "TEXT"
    print(f"\n  ✅ Groq подключён | {config['model']} | режим: {mode_str}")
    print(f"  📚 RAG база: {len(enhancer.examples)} примеров")

    if args.once:
        print()
        print(enhancer.enhance(args.once))
    else:
        interactive_mode(enhancer)


if __name__ == "__main__":
    main()
