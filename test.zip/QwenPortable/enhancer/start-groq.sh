#!/bin/bash
# Prompt Enhancer — Groq Llama 70B

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [ -z "$GROQ_API_KEY" ]; then
    echo ""
    echo "  ℹ️  Groq API ключ не задан."
    echo "  Можно: export GROQ_API_KEY=gsk_..."
    echo ""
fi

python3 "$SCRIPT_DIR/prompt_enhancer_groq.py" "$@"
