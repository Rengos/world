"""
Qwen Prompt Enhancer v3.0 — через Claude API
Улучшает промпты до профессионального уровня
"""

import anthropic
import subprocess
import sys
import os
from pathlib import Path

# ─── Конфиг ──────────────────────────────────────────────────────────────────

# API ключ — задай через переменную окружения:
# Windows: set ANTHROPIC_API_KEY=sk-ant-...
# Linux:   export ANTHROPIC_API_KEY=sk-ant-...
API_KEY = os.environ.get("ANTHROPIC_API_KEY", "")

SKILLS_DIR = Path(__file__).parent.parent / "skills"

# ─── Список скиллов для контекста ────────────────────────────────────────────

def get_skills_context() -> str:
    if not SKILLS_DIR.exists():
        return ""
    skills = []
    for skill_dir in sorted(SKILLS_DIR.iterdir()):
        json_file = skill_dir / "skill.json"
        if json_file.exists():
            import json
            try:
                data = json.loads(json_file.read_text(encoding="utf-8"))
                triggers = data.get("triggers", data.get("triggerPhrases", []))[:3]
                skills.append(f"- {data['name']}: {', '.join(triggers)}")
            except:
                pass
    return "\n".join(skills)

# ─── Системный промпт ─────────────────────────────────────────────────────────

def build_system_prompt() -> str:
    skills_ctx = get_skills_context()
    skills_section = f"""
Available skills (add activation trigger if relevant):
{skills_ctx}
""" if skills_ctx else ""

    return f"""You are an expert prompt engineer for Qwen Code CLI — an AI coding assistant.

Your job: transform a short, vague user request into a detailed, professional prompt that will produce excellent results.
{skills_section}
## HOW TO IMPROVE A PROMPT

1. **Preserve intent** — keep the original goal, just make it clearer
2. **Add technical context** — specify language, framework, patterns if implied
3. **Clarify input/output** — what goes in, what comes out
4. **Add quality requirements** — TypeScript types, error handling, tests if relevant
5. **Mention edge cases** — what should happen when things go wrong
6. **Add skill trigger** — if a skill matches, append the activation phrase naturally
7. **Match the language** — Russian input → Russian output, English → English, mixed → match dominant

## WHAT NOT TO DO

- Don't add requirements the user didn't imply
- Don't make it longer than needed — quality over length
- Don't add preamble or explanation — output ONLY the improved prompt
- Don't translate between Russian and English

## OUTPUT

Respond with ONLY the improved prompt. Nothing else. No "Here is your improved prompt:", no explanation."""

# ─── Улучшение промпта ────────────────────────────────────────────────────────

def enhance_prompt(user_input: str) -> str:
    client = anthropic.Anthropic(api_key=API_KEY)

    message = client.messages.create(
        model="claude-sonnet-4-20250514",
        max_tokens=1024,
        system=build_system_prompt(),
        messages=[
            {"role": "user", "content": user_input}
        ]
    )
    return message.content[0].text.strip()

# ─── Вспомогательные функции ──────────────────────────────────────────────────

def copy_to_clipboard(text: str):
    try:
        if sys.platform == "win32":
            subprocess.run(["clip"], input=text.encode("utf-8"), check=True)
        else:
            subprocess.run(["xclip", "-selection", "clipboard"],
                         input=text.encode("utf-8"), check=True)
        print("📋 Скопировано в буфер обмена!")
    except Exception:
        print("⚠️  Не удалось скопировать (установи xclip на Linux)")

def send_to_qwen(prompt: str):
    print("\n📤 Отправляю в Qwen Code...\n")
    subprocess.run(["qwen", "-p", prompt])

# ─── Главная функция ──────────────────────────────────────────────────────────

def main():
    # Проверяем API ключ
    if not API_KEY:
        print("""
❌ ANTHROPIC_API_KEY не задан!

Получи ключ на: https://console.anthropic.com

Затем задай переменную окружения:
  Windows:  set ANTHROPIC_API_KEY=sk-ant-...
  Linux:    export ANTHROPIC_API_KEY=sk-ant-...

Или добавь в .env файл рядом со скриптом.
""")
        input("Нажми Enter для выхода...")
        return

    os.system("cls" if os.name == "nt" else "clear")
    print("=" * 60)
    print("  🚀 Qwen Prompt Enhancer v3.0 — Claude API")
    print("=" * 60)

    # Получаем промпт
    if len(sys.argv) > 1:
        user_input = " ".join(sys.argv[1:]).strip()
        print(f"\n💬 Промпт: {user_input}")
    else:
        print()
        user_input = input("💬 Твой промпт: ").strip()

    if not user_input:
        print("❌ Промпт пустой!")
        return

    # Улучшаем
    print("\n⏳ Улучшаю через Claude API...\n")
    try:
        enhanced = enhance_prompt(user_input)
    except anthropic.AuthenticationError:
        print("❌ Неверный API ключ. Проверь ANTHROPIC_API_KEY.")
        input("\nНажми Enter для выхода...")
        return
    except Exception as e:
        print(f"❌ Ошибка API: {e}")
        input("\nНажми Enter для выхода...")
        return

    # Показываем результат
    print("✅ Улучшенный промпт:")
    print("-" * 60)
    print(enhanced)
    print("-" * 60)

    # Меню
    print("\nЧто делаем?")
    print("  1 — Отправить в Qwen Code")
    print("  2 — Скопировать в буфер")
    print("  3 — Отправить И скопировать")
    print("  4 — Ввести новый промпт")
    print("  0 — Выйти")

    choice = input("\nВыбор: ").strip()

    if choice == "1":
        send_to_qwen(enhanced)
    elif choice == "2":
        copy_to_clipboard(enhanced)
    elif choice == "3":
        copy_to_clipboard(enhanced)
        send_to_qwen(enhanced)
    elif choice == "4":
        main()

    input("\nНажми Enter для выхода...")

if __name__ == "__main__":
    main()
