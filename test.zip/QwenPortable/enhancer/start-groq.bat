@echo off
chcp 65001 >nul
title Prompt Enhancer — Groq Llama 3.3 70B

:: Загружаем API ключ из .env если есть
if exist "%~dp0.env" (
    for /f "tokens=1,* delims==" %%a in ('type "%~dp0.env"') do (
        if "%%a"=="GROQ_API_KEY" set GROQ_API_KEY=%%b
    )
    echo ✅ API ключ загружен из .env
)

:: Проверка Python
where python >nul 2>&1
if errorlevel 1 (
    echo ❌ Python не найден!
    pause
    exit /b 1
)

:: Запуск Prompt Enhancer с Groq
echo.
echo 🚀 Prompt Enhancer — Groq Llama 3.3 70B
echo.
python "%~dp0prompt_enhancer_groq.py" %*

if errorlevel 1 (
    echo.
    echo ⚠️  Ошибка выполнения. Проверь API ключ в .env
    pause
)
