@echo off
chcp 65001 > nul
title Qwen Prompt Enhancer — Claude API

:: Задай свой ключ здесь ИЛИ через переменную окружения системы
:: set ANTHROPIC_API_KEY=sk-ant-...

if "%ANTHROPIC_API_KEY%"=="" (
    echo.
    echo ❌ ANTHROPIC_API_KEY не задан!
    echo.
    echo Открой этот файл блокнотом и добавь ключ:
    echo   set ANTHROPIC_API_KEY=sk-ant-твой-ключ
    echo.
    echo Или задай переменную окружения в системе Windows.
    echo Получить ключ: https://console.anthropic.com
    echo.
    pause
    exit /b 1
)

python "%~dp0prompt_enhancer_claude.py" %*
