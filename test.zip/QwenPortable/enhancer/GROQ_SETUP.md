# 🚀 GROQ PROMPT ENHANCER — Настройка и Использование

**Версия:** 2.0 (Groq API)
**Дата:** 21 марта 2026 г.
**Модель:** Llama 3.3 70B

---

## ✅ НАСТРОЙКА ВЫПОЛНЕНА

### API ключ уже настроен!

**Ключ:** `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`
**Хранение:** `enhancer/.env`

---

## 🚀 ЗАПУСК

### Вариант 1: Через start.bat (Главный)

```bash
# Дважды кликни или из консоли:
cd "C:\Users\Alex\Desktop\Новая папка\QwenPortable (2)\QwenPortable"
start.bat
```

### Вариант 2: Через start-groq.bat

```bash
# Дважды кликни или из консоли:
cd "C:\Users\Alex\Desktop\Новая папка\QwenPortable (2)\QwenPortable"
start-groq.bat
```

### Вариант 3: Напрямую

```bash
python enhancer/prompt_enhancer_groq.py
```

---

## 💡 ПРИМЕРЫ ИСПОЛЬЗОВАНИЯ

### Интерактивный режим

```bash
python enhancer/prompt_enhancer_groq.py
```

**Пример сессии:**

```
═══════════════════════════════════════════════════════════
  🚀 Prompt Enhancer — Groq Llama 3.3 70B
  Команды: 'выход' | 'история' | 'очистить' | 'модель'
═══════════════════════════════════════════════════════════

📝 Ваш промпт: создай api для пользователей

  ⏳ Улучшаю промпт...

  ⚡ 3.2s | токены: 145→892 | модель: llama-3.3-70b-versatile

────────────────────────────────────────────────────────────
✨ УЛУЧШЕННЫЙ ПРОМПТ:
────────────────────────────────────────────────────────────

<enhanced_prompt>
Создай RESTful API для управления пользователями...
[Далее следует детальный XML промпт]
</enhanced_prompt>

────────────────────────────────────────────────────────────

  📋 Скопировано в буфер обмена
```

### Одиночный режим

```bash
python enhancer/prompt_enhancer_groq.py --once "создай компонент React"
```

### С ключом напрямую

```bash
python enhancer/prompt_enhancer_groq.py --key gsk_... --once "создай api"
```

### Без XML (plain text)

```bash
python enhancer/prompt_enhancer_groq.py --no-xml --once "создай api"
```

---

## 📊 СРАВНЕНИЕ: Ollama vs Groq

| Параметр | Ollama (qwen2.5:1.5b) | Groq (llama-3.3-70b) |
|----------|----------------------|----------------------|
| **Параметры** | 1.5B | 70B |
| **Скорость** | 30-60 сек | 2-5 сек ⚡ |
| **Качество** | ⭐⭐⭐ | ⭐⭐⭐⭐⭐ |
| **RAM** | 4GB | 0GB |
| **Цена** | Бесплатно | Бесплатно (100 req/day) |
| **Интернет** | Не нужен | Нужен |

---

## ⚙️ КОНФИГУРАЦИЯ

### enhancer/groq_config.json

```json
{
  "model": "llama-3.3-70b-versatile",
  "temperature": 0.4,
  "max_tokens": 1800,
  "top_p": 0.9,
  "xml_output": true,
  "rag_enabled": true,
  "rag_top_k": 3,
  "rag_min_similarity": 0.35,
  "save_to_examples": true,
  "history_enabled": true,
  "history_max": 6
}
```

### enhancer/.env

```env
GROQ_API_KEY=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
```

---

## 🔧 КОМАНДЫ В ИНТЕРАКТИВНОМ РЕЖИМЕ

- `выход` / `exit` / `q` — выйти
- `история` — показать историю диалога
- `очистить` — очистить историю
- `модель` — показать текущую модель

---

## 📁 ФАЙЛЫ

```
enhancer/
├── prompt_enhancer_groq.py    # Основной скрипт
├── start-groq.bat             # Запуск Groq
├── .env                       # API ключ
├── groq_config.json           # Конфигурация
├── prompt_examples.json       # RAG база примеров
└── GROQ_SETUP.md              # Документация
```

---

## 🎯 ЧТО ИЗМЕНИЛОСЬ

### Было (Ollama):
- ❌ Модель: qwen2.5:1.5b (1.5B)
- ❌ Локально: 4GB RAM
- ❌ Медленно: 30-60 сек
- ❌ Качество: среднее

### Стало (Groq):
- ✅ Модель: llama-3.3-70b (70B)
- ✅ Облако: 0GB RAM
- ✅ Быстро: 2-5 сек
- ✅ Качество: отличное!
- ✅ XML output
- ✅ RAG с базой примеров

---

## 💰 ТАРИФЫ GROQ

### Бесплатный план:
- ✅ **100 запросов в день**
- ✅ **30 запросов в минуту**
- ✅ **Llama 3.3 70B**

**Хватит для:**
- ~30-50 улучшений промптов в день
- Разработки и тестирования
- Личного использования

---

## 🔧 ТРОУБЛШУТИНГ

### Ошибка: "No module named 'groq'"

```bash
python -m pip install groq
```

### Ошибка: "invalid_api_key"

1. Проверь ключ в `enhancer/.env`
2. Убедись что ключ активен на https://console.groq.com/keys
3. Пересоздай ключ если нужно

### Ошибка: "rate_limit"

- Бесплатный план: 100 запросов в день
- Подожди 24 часа

### Ошибка: "timeout"

- Проверь интернет соединение
- Попробуй позже

---

## 📚 ДОПОЛНИТЕЛЬНЫЕ РЕСУРСЫ

- [Groq Console](https://console.groq.com)
- [Groq API Docs](https://console.groq.com/docs)
- [Llama 3.3 Model](https://groq.com/llama-3-3)
- [Python SDK](https://github.com/groq/groq-python)

---

## ✅ ЧЕКЛИСТ

- [x] API ключ в `.env`
- [x] Groq SDK установлен
- [x] `start.bat` обновлен
- [x] `start-groq.bat` работает
- [x] Конфигурация готова
- [x] Можно использовать!

---

**Готово! Prompt Enhancer теперь работает на Groq Llama 3.3 70B!** 🚀
