@echo off
chcp 65001 > nul
title Установка Qwen Prompt Enhancer

echo ================================================
echo   Установка Qwen Prompt Enhancer v2.0
echo ================================================
echo.

:: Проверяем Python
where python > nul 2>&1
if errorlevel 1 (
    echo ❌ Python не найден!
    echo Скачай: https://python.org/downloads
    echo Установи с галочкой "Add Python to PATH"
    pause
    exit /b 1
)
echo ✅ Python найден

:: Устанавливаем зависимости
echo.
echo ⏳ Устанавливаю зависимости...
pip install ollama --quiet
echo ✅ ollama установлен

:: Проверяем Ollama
where ollama > nul 2>&1
if errorlevel 1 (
    echo.
    echo ⚠️  Ollama не найдена!
    echo Скачай и установи: https://ollama.com/download/windows
    echo После установки запусти этот файл снова.
    pause
    exit /b 1
)
echo ✅ Ollama найдена

:: Скачиваем модель если нет в папке models
echo.
set OLLAMA_MODELS=%~dp0models
if not exist "%~dp0models" mkdir "%~dp0models"

echo ⏳ Проверяю модель qwen2.5:1.5b...
echo    (если не скачана — скачаю сейчас, ~1GB)
echo.
start /min "" ollama serve
timeout /t 3 /nobreak > nul
ollama pull qwen2.5:1.5b

echo.
echo ================================================
echo   ✅ Установка завершена!
echo   Теперь используй start.bat
echo ================================================
pause
