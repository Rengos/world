#!/usr/bin/env python3
"""
Multi-Agent Orchestrator для Qwen Code CLI
==========================================
Делит большую задачу на независимые подзадачи,
запускает несколько qwen процессов параллельно,
собирает результаты.

Использование:
  python multi_agent.py
  python multi_agent.py --task "создай fullstack todo приложение"
  python multi_agent.py --agents 2
"""

import os
import sys
import json
import time
import argparse
import subprocess
import threading
from pathlib import Path
from dataclasses import dataclass
from typing import Optional
from queue import Queue

try:
    from groq import Groq
except ImportError:
    print("Установка groq SDK...")
    os.system(f'"{sys.executable}" -m pip install groq -q')
    from groq import Groq

# ── Константы ─────────────────────────────────────────────────────────────────
MAX_AGENTS   = 3
QWEN_CMD     = "qwen"
CONFIG_FILE  = Path(__file__).parent / "groq_config.json"
RESULTS_DIR  = Path(__file__).parent / "agent_results"
GROQ_MODEL   = "llama-3.3-70b-versatile"


# ── Структуры ─────────────────────────────────────────────────────────────────
@dataclass
class SubTask:
    id:          int
    title:       str
    prompt:      str
    skill:       Optional[str] = None
    status:      str = "pending"
    result:      str = ""
    started_at:  float = 0.0
    finished_at: float = 0.0


@dataclass
class AgentResult:
    task_id:  int
    success:  bool
    output:   str
    duration: float


# ── Определение режима запуска qwen ───────────────────────────────────────────
def detect_qwen_input_mode() -> str:
    """Определить как qwen принимает промпт: 'stdin' или 'file'."""
    try:
        r = subprocess.run([QWEN_CMD, "--help"],
                           capture_output=True, text=True, timeout=10)
        help_text = r.stdout + r.stderr
        if "--file" in help_text or "-f " in help_text:
            return "file"
        return "stdin"
    except Exception:
        return "stdin"


INPUT_MODE = detect_qwen_input_mode()


# ── Разбивка задачи через Groq ────────────────────────────────────────────────
def split_task(main_task: str, api_key: str,
               max_subtasks: int = MAX_AGENTS) -> list[SubTask]:
    """Разбить большую задачу на независимые подзадачи через Groq."""
    client = Groq(api_key=api_key)
    system = f"""Ты — оркестратор задач. Раздели задачу на {max_subtasks} независимых подзадач.

Правила:
- Подзадачи НЕЗАВИСИМЫ (выполняются параллельно без зависимостей)
- Каждая подзадача = один конкретный файл или модуль
- Ответ ТОЛЬКО валидным JSON без текста вне JSON

Формат:
{{
  "subtasks": [
    {{"id": 1, "title": "название", "prompt": "детальный промпт для qwen", "skill": "fullstack"}}
  ]
}}"""

    try:
        resp = client.chat.completions.create(
            model=GROQ_MODEL,
            messages=[
                {"role": "system", "content": system},
                {"role": "user",   "content": f"Задача:\n\n{main_task}"}
            ],
            temperature=0.3,
            max_tokens=2000,
            response_format={"type": "json_object"}
        )
        data = json.loads(resp.choices[0].message.content)
        return [
            SubTask(
                id=item["id"],
                title=item.get("title", f"Задача {item['id']}"),
                prompt=item.get("prompt", ""),
                skill=item.get("skill")
            )
            for item in data.get("subtasks", [])[:max_subtasks]
        ]
    except Exception as e:
        print(f"  ⚠️  Ошибка разбивки: {e}. Запускаю как одну задачу.")
        return [SubTask(id=1, title="Основная задача", prompt=main_task)]


# ── Запуск одного агента ──────────────────────────────────────────────────────
def run_agent(subtask: SubTask, results_queue: Queue,
              input_mode: str = "stdin") -> None:
    """Запустить qwen CLI для одной подзадачи."""
    subtask.status     = "running"
    subtask.started_at = time.time()
    RESULTS_DIR.mkdir(exist_ok=True)

    print(f"  🤖 Агент {subtask.id} запущен: {subtask.title}")

    try:
        if input_mode == "file":
            prompt_file = RESULTS_DIR / f"task_{subtask.id}_prompt.txt"
            prompt_file.write_text(subtask.prompt, encoding="utf-8")
            proc = subprocess.run(
                [QWEN_CMD, "--file", str(prompt_file)],
                capture_output=True, text=True,
                encoding="utf-8", timeout=300
            )
        else:
            proc = subprocess.run(
                [QWEN_CMD],
                input=subtask.prompt,
                capture_output=True, text=True,
                encoding="utf-8", timeout=300
            )
        output  = proc.stdout.strip() or proc.stderr.strip() or "Нет вывода"
        success = proc.returncode == 0

    except subprocess.TimeoutExpired:
        output, success = "❌ Timeout (5 мин)", False
    except FileNotFoundError:
        output  = f"❌ Команда '{QWEN_CMD}' не найдена. Убедись что qwen установлен."
        success = False
    except Exception as e:
        output, success = f"❌ Ошибка: {e}", False

    subtask.finished_at = time.time()
    subtask.status      = "done" if success else "failed"
    subtask.result      = output
    duration            = subtask.finished_at - subtask.started_at

    (RESULTS_DIR / f"result_{subtask.id}.txt").write_text(output, encoding="utf-8")

    icon = "✅" if success else "❌"
    print(f"  {icon} Агент {subtask.id} завершён за {duration:.1f}s: {subtask.title}")

    results_queue.put(AgentResult(
        task_id=subtask.id, success=success,
        output=output, duration=duration
    ))


# ── Оркестратор ───────────────────────────────────────────────────────────────
class MultiAgentOrchestrator:
    """Управляет параллельным выполнением задач через Qwen Code CLI."""

    def __init__(self, api_key: str, max_agents: int = MAX_AGENTS) -> None:
        self.api_key    = api_key
        self.max_agents = min(max_agents, MAX_AGENTS)

    def run(self, main_task: str) -> dict:
        """Выполнить задачу параллельно. Возвращает dict[task_id, AgentResult]."""
        print(f"\n{'═' * 60}")
        print(f"  🚀 Multi-Agent Orchestrator | агентов: {self.max_agents} | режим: {INPUT_MODE}")
        print(f"{'═' * 60}\n")

        # 1. Разбить задачу
        print("  📋 Разбиваю задачу...")
        subtasks = split_task(main_task, self.api_key, self.max_agents)
        print(f"  ✅ Подзадач: {len(subtasks)}\n")
        for st in subtasks:
            skill_str = f" [{st.skill}]" if st.skill else ""
            print(f"    {st.id}. {st.title}{skill_str}")
        print()

        # 2. Запустить параллельно
        q: Queue = Queue()
        threads  = []
        t0       = time.time()

        for st in subtasks:
            thr = threading.Thread(
                target=run_agent,
                args=(st, q, INPUT_MODE),
                daemon=True
            )
            threads.append(thr)
            thr.start()
            time.sleep(0.5)

        for thr in threads:
            thr.join(timeout=360)

        total = time.time() - t0

        # 3. Собрать результаты
        results: dict[int, AgentResult] = {}
        while not q.empty():
            r = q.get()
            results[r.task_id] = r

        # 4. Итог
        ok = sum(1 for r in results.values() if r.success)
        print(f"\n{'─' * 60}")
        print(f"  📊 ИТОГ: {ok}/{len(subtasks)} успешно | {total:.1f}s")
        print(f"  📁 Результаты: {RESULTS_DIR}")
        print(f"{'─' * 60}")
        for st in subtasks:
            r = results.get(st.id)
            if r:
                icon = "✅" if r.success else "❌"
                print(f"  {icon} [{st.id}] {st.title} ({r.duration:.1f}s)")
        print()
        return results


# ── Интерактивный режим ───────────────────────────────────────────────────────
def interactive_mode(orch: MultiAgentOrchestrator) -> None:
    """Интерактивный режим оркестратора."""
    print("\n" + "═" * 60)
    print("  🤖 Multi-Agent Orchestrator для Qwen Code")
    print("  Введи большую задачу — она будет разбита и выполнена параллельно")
    print("  Команды: выход | результаты")
    print("═" * 60 + "\n")

    while True:
        try:
            task = input("🎯 Задача: ").strip()
        except (KeyboardInterrupt, EOFError):
            print("\n👋 До свидания!")
            break

        if not task:
            continue
        if task.lower() in ("выход", "exit", "q"):
            print("👋 До свидания!")
            break
        if task.lower() == "результаты":
            files = sorted(RESULTS_DIR.glob("result_*.txt")) if RESULTS_DIR.exists() else []
            if files:
                for f in files:
                    print(f"  📄 {f.name}")
            else:
                print("  Результатов нет")
            print()
            continue

        orch.run(task)


# ── Main ──────────────────────────────────────────────────────────────────────
def main() -> None:
    parser = argparse.ArgumentParser(description="Multi-Agent Qwen Orchestrator")
    parser.add_argument("--task",   help="Задача")
    parser.add_argument("--agents", type=int, default=MAX_AGENTS)
    parser.add_argument("--key",    help="Groq API ключ")
    args = parser.parse_args()

    api_key = args.key or os.environ.get("GROQ_API_KEY")
    if not api_key and CONFIG_FILE.exists():
        try:
            api_key = json.loads(CONFIG_FILE.read_text(encoding="utf-8")).get("api_key")
        except Exception:
            pass
    if not api_key:
        api_key = input("🔑 Groq API ключ: ").strip()
        if not api_key:
            print("❌ Ключ не введён")
            sys.exit(1)

    orch = MultiAgentOrchestrator(api_key=api_key, max_agents=args.agents)

    if args.task:
        orch.run(args.task)
    else:
        interactive_mode(orch)


if __name__ == "__main__":
    main()
