@echo off
chcp 65001 >nul
title Multi-Agent Qwen Orchestrator
python "%~dp0multi_agent.py" %*
pause
