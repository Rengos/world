"""
Qwen Prompt Enhancer v4.0 — Ollama + RAG
Улучшает промпты используя базу одобренных примеров.
Чем больше одобряешь — тем умнее становится.
"""

import ollama
import subprocess
import sys
import os
import json
from pathlib import Path
from difflib import SequenceMatcher

SCRIPT_DIR    = Path(__file__).parent
EXAMPLES_FILE = SCRIPT_DIR / "prompt_examples.json"
MODEL         = "qwen2.5:1.5b"

# ─── База примеров ────────────────────────────────────────────────────────────

def load_examples() -> list:
    if not EXAMPLES_FILE.exists():
        return []
    with open(EXAMPLES_FILE, "r", encoding="utf-8") as f:
        data = json.load(f)
    return [e for e in data.get("examples", []) if e.get("approved")]

def save_example(short: str, enhanced: str, skill):
    if not EXAMPLES_FILE.exists():
        return
    with open(EXAMPLES_FILE, "r", encoding="utf-8") as f:
        data = json.load(f)
    new_id = str(len(data.get("examples", [])) + 1).zfill(3)
    data.setdefault("examples", []).append({
        "id": new_id, "tags": [], "short": short,
        "enhanced": enhanced, "skill": skill,
        "approved": True, "uses": 0
    })
    with open(EXAMPLES_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=4)
    return new_id

def increment_uses(ids: list):
    if not EXAMPLES_FILE.exists() or not ids:
        return
    with open(EXAMPLES_FILE, "r", encoding="utf-8") as f:
        data = json.load(f)
    for ex in data.get("examples", []):
        if ex["id"] in ids:
            ex["uses"] = ex.get("uses", 0) + 1
    with open(EXAMPLES_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=4)

# ─── RAG: поиск похожих примеров ─────────────────────────────────────────────

def similarity(a: str, b: str) -> float:
    return SequenceMatcher(None, a.lower(), b.lower()).ratio()

def find_similar(query: str, top_k: int = 3) -> list:
    examples = load_examples()
    if not examples:
        return []
    scored = []
    q = query.lower()
    for ex in examples:
        score = similarity(q, ex["short"].lower())
        for tag in ex.get("tags", []):
            if tag in q:
                score += 0.15
        scored.append((score, ex))
    scored.sort(key=lambda x: x[0], reverse=True)
    return [ex for s, ex in scored[:top_k] if s > 0.2]

# ─── Скиллы ──────────────────────────────────────────────────────────────────

SKILLS = {
    "fullstack":              {"t": ["next.js","react","api","frontend","backend","компонент","trpc","drizzle"], "p": "используй fullstack skill"},
    "android_team":           {"t": ["android","kotlin","compose","hilt"],                                      "p": "используй android_team skill"},
    "apple_design_system":    {"t": ["ios","swift","swiftui"],                                                  "p": "используй apple_design_system skill"},
    "code_reviewer":          {"t": ["проверь код","review","найди баги","ревью"],                             "p": "используй code_reviewer skill"},
    "security_guardian":      {"t": ["безопасност","security","auth","уязвимост"],                             "p": "используй security_guardian skill"},
    "documentation_writer":   {"t": ["документац","readme","docs","changelog"],                                "p": "используй documentation_writer skill"},
    "chain_of_thought":       {"t": ["пошагово","объясни","как работает"],                                     "p": "используй chain_of_thought"},
    "deep_reasoning":         {"t": ["архитектур","спроектируй","лучший способ"],                              "p": "используй deep_reasoning skill"},
    "performance_optimizer":  {"t": ["оптимизируй","performance","медленно"],                                  "p": "используй performance_optimizer skill"},
    "refactoring_specialist": {"t": ["рефакторинг","refactor","перепиши","почисти"],                           "p": "используй refactoring_specialist skill"},
    "testing_expert":         {"t": ["тест","test","unit","e2e","vitest"],                                     "p": "используй testing_expert skill"},
    "humanizer":              {"t": ["объясни просто","для начинающих","понятно"],                             "p": "используй humanizer skill"},
}

def detect_skill(text: str):
    t = text.lower()
    for name, data in SKILLS.items():
        for trigger in data["t"]:
            if trigger in t:
                return name, data["p"]
    return None, None

# ─── Улучшение через Ollama + RAG ────────────────────────────────────────────

def enhance(user_input: str):
    examples = find_similar(user_input)
    skill_name, skill_phrase = detect_skill(user_input)

    # Строим контекст из примеров
    ctx = ""
    if examples:
        ctx = "\n\nСхожие улучшенные промпты для ориентира:\n"
        for ex in examples:
            ctx += f"\nИсходный: {ex['short']}\nУлучшенный: {ex['enhanced']}\n---"

    skill_hint = f"\n\nДобавь в конец: {skill_phrase}" if skill_phrase else ""

    prompt = f"""Улучши промпт для AI coding assistant Qwen Code CLI.{ctx}

Правила:
- Сохрани язык оригинала (русский→русский, английский→английский)
- Добавь технические детали, входные/выходные данные, edge cases
- Сохрани исходный смысл{skill_hint}
- Выведи ТОЛЬКО улучшенный промпт, без объяснений

Промпт для улучшения: {user_input}"""

    response = ollama.chat(
        model=MODEL,
        messages=[{"role": "user", "content": prompt}],
        options={"temperature": 0.3}
    )
    return response["message"]["content"].strip(), [ex["id"] for ex in examples], skill_name

# ─── UI ──────────────────────────────────────────────────────────────────────

def copy(text: str):
    try:
        if sys.platform == "win32":
            subprocess.run(["clip"], input=text.encode("utf-8"), check=True)
        else:
            subprocess.run(["xclip", "-selection", "clipboard"], input=text.encode("utf-8"), check=True)
        print("📋 Скопировано!")
    except Exception:
        print("⚠️  Не удалось скопировать")

def send_qwen(prompt: str):
    print("\n📤 Отправляю в Qwen Code...\n" + "="*60)
    subprocess.run(["qwen", "-p", prompt])

def main():
    os.system("cls" if os.name == "nt" else "clear")
    count = len(load_examples())
    print("=" * 60)
    print(f"  🚀 Qwen Prompt Enhancer v4.0 — Ollama + RAG")
    print(f"  📚 База примеров: {count} шт.")
    print("=" * 60)

    user_input = (" ".join(sys.argv[1:]) if len(sys.argv) > 1 else input("\n💬 Твой промпт: ")).strip()
    if not user_input:
        print("❌ Пустой промпт!")
        return

    print("\n⏳ Ищу примеры и улучшаю...\n")
    try:
        enhanced, used_ids, skill = enhance(user_input)
    except Exception as e:
        print(f"❌ Ошибка Ollama: {e}")
        input("\nEnter для выхода...")
        return

    if used_ids:
        print(f"📚 Найдено похожих примеров: {len(used_ids)}")
    if skill:
        print(f"🎯 Скилл: {skill}")

    print("\n✅ Улучшенный промпт:")
    print("-" * 60)
    print(enhanced)
    print("-" * 60)

    print("\n  1 — Отправить в Qwen Code")
    print("  2 — Скопировать")
    print("  3 — Отправить + скопировать")
    print("  4 — ✅ Сохранить в базу (улучшит следующие промпты)")
    print("  5 — Новый промпт")
    print("  0 — Выйти")

    choice = input("\nВыбор: ").strip()

    if choice == "1":
        increment_uses(used_ids)
        send_qwen(enhanced)
    elif choice == "2":
        copy(enhanced)
    elif choice == "3":
        increment_uses(used_ids)
        copy(enhanced)
        send_qwen(enhanced)
    elif choice == "4":
        save_example(user_input, enhanced, skill)
        print(f"✅ Сохранено! База: {len(load_examples())} примеров.")
        if input("  Отправить в Qwen? (y/n): ").strip().lower() == "y":
            increment_uses(used_ids)
            send_qwen(enhanced)
    elif choice == "5":
        main()
        return

    input("\nEnter для выхода...")

if __name__ == "__main__":
    main()
