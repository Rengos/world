# ⚡ БЫСТРЫЙ СТАРТ

**Перенёс папку на другой ПК? Выполните эти 5 шагов:**

```bash
# 1. Установи зависимости (один раз)
pip install groq sentence-transformers numpy

# 2. Замени API ключ в enhancer/.env
GROQ_API_KEY=твой_новый_ключ

# 3. Протестируй
python enhancer/prompt_enhancer_groq.py --once "создай api"

# 4. Сделай бэкап (рекомендуется)
python backup_system.py
# или
backup.bat

# 5. Пользуйся!
start.bat
```

**Всё! Теперь каждый твой промпт будет автоматически улучшаться через Groq API (Llama 3.3 70B).**

---

# 🚀 Qwen Portable — Полная Инструкция по Переносу и Запуску

**Версия:** 3.4.0  
**Последнее обновление:** Март 2026  
**Статус:** ✅ Production Ready

---

## 📋 ЧТО ЭТО ТАКОЕ

**Qwen Portable** — это автономная система для улучшения промптов и генерации кода через AI:

- ✅ **Prompt Enhancer** — улучшает ваши промпты через Groq API (Llama 3.3 70B)
- ✅ **18 скиллов** — специализированные модули для разных задач
- ✅ **Multi-Agent** — параллельное выполнение больших задач
- ✅ **MCP серверы** — доступ к документации библиотек
- ✅ **RAG база** — 220+ примеров улучшенных промптов

**Главная фича:** Каждый ваш промпт автоматически улучшается через Prompt Enhancer перед отправкой в Qwen Code CLI.

---

## 🔄 ПЕРЕНОС НА ДРУГОЙ ПК

### Шаг 1: Скопируй папку

```
Скопируй всю папку QwenPortable целиком:
📁 QwenPortable/
   ├── enhancer/          ← Prompt Enhancer + RAG база
   ├── skills/            ← 18 скиллов
   ├── settings.json      ← MCP конфигурация
   ├── AGENT.md           ← инструкции агента
   └── start.bat          ← главный launcher
```

**Важно:** Копируй ВСЮ папку включая `models/` если есть (локальные модели Ollama).

---

### Шаг 2: Установи зависимости на новом ПК

#### 2.1 Python (обязательно)
```
Скачай: https://python.org/downloads
✅ Галочка: "Add Python to PATH"
✅ Версия: Python 3.10+
```

#### 2.2 Groq API ключ (обязательно для Prompt Enhancer)
```
1. Зайди: https://console.groq.com/keys
2. Создай бесплатный ключ (100 запросов/день)
3. Скопируй ключ
```

#### 2.3 Qwen Code CLI (обязательно)
```bash
npm install -g @qwen-code/qwen-code
```

#### 2.4 Node.js (если нет)
```
Скачай: https://nodejs.org
✅ Версия: LTS
```

---

### Шаг 3: Настрой систему

#### 3.1 Открой файл `.env`
```
📁 Путь: QwenPortable/enhancer/.env
```

#### 3.2 Замени API ключ на свой
```env
GROQ_API_KEY=твой_новый_ключ_gsk_...
```

**Важно:** Без этого Prompt Enhancer не будет работать!

---

### Шаг 4: Установи Python зависимости

```bash
cd QwenPortable
pip install groq sentence-transformers numpy
```

**Что это даёт:**
- `groq` — Groq API SDK
- `sentence-transformers` — векторный поиск по RAG базе (опционально, ~60MB)
- `numpy` — для векторных вычислений

---

### Шаг 5: Проверь работу

#### Тест 1: Prompt Enhancer
```bash
cd QwenPortable
python enhancer/prompt_enhancer_groq.py --once "создай API для пользователей"
```

**Ожидаемый результат:**
```
✅ Groq подключён | llama-3.3-70b-versatile | режим: XML
📚 RAG база: 220 примеров

⚡ 1.4s | in: 1305 / out: 285 токенов | XML

<prompt>
  <task>Создать REST API для пользователей</task>
  <stack>...</stack>
  <skill>fullstack</skill>
</prompt>
```

#### Тест 2: Qwen Code CLI
```bash
qwen --version
```

**Ожидаемый результат:** `0.12.6` или новее

---

## 🎯 КАК ИСПОЛЬЗОВАТЬ

### Вариант 1: Через start.bat (рекомендуется)

```bash
# Двойной клик на start.bat
# или из консоли:
cd QwenPortable
start.bat
```

**Что происходит:**
1. ✅ Проверяется Python
2. ✅ Проверяется GROQ_API_KEY
3. ✅ Запускается Prompt Enhancer
4. ✅ Вводишь короткий промпт → получаешь улучшенный XML
5. ✅ Автоматически отправляется в Qwen Code CLI

---

### Вариант 2: Интерактивный режим Prompt Enhancer

```bash
cd QwenPortable
python enhancer/prompt_enhancer_groq.py
```

**Пример сессии:**
```
═══════════════════════════════════════════════════════════
  🚀 Prompt Enhancer — Groq Llama 3.3 70B
  Команды: выход | история | очистить | статус | очистка
═══════════════════════════════════════════════════════════

📝 Промпт: создай api для пользователей

  ⏳ Генерирую XML-промпт...

  ⚡ 1.4s | in: 1305 / out: 285 токенов | XML

────────────────────────────────────────────────────────────
✨ РЕЗУЛЬТАТ:
────────────────────────────────────────────────────────────

<prompt>
  <task>Создать REST API для пользователей</task>
  <stack>
    <language>TypeScript</language>
    <framework>Next.js 15</framework>
    <database>Prisma + PostgreSQL</database>
  </stack>
  <requirements>
    <functional>
      <item>GET /api/users — список с пагинацией</item>
      <item>POST /api/users — создание с валидацией</item>
      <item>GET /api/users/[id] — один объект</item>
    </functional>
    <technical>
      <item>Prisma ORM</item>
      <item>Zod валидация</item>
    </technical>
  </requirements>
  <output>
    <format>TypeScript файлы</format>
    <includes>unit тесты, OpenAPI схема</includes>
  </output>
  <skill>fullstack</skill>
</prompt>

────────────────────────────────────────────────────────────
  📋 Скопировано в буфер обмена

  Результат хороший? (д/н/enter=пропустить): д
  ✅ Пример усилен в базе
```

---

### Вариант 3: Напрямую в Qwen Code CLI

```bash
cd QwenPortable
qwen
```

**Что происходит:**
1. ✅ Qwen читает `settings.json` → MCP серверы
2. ✅ Qwen читает `AGENT.md` → инструкции агента
3. ✅ Qwen читает `QWEN.md` → главный контекст
4. ✅ Qwen загружает скиллы из `skills/`
5. ✅ Готов к работе!

---

### Вариант 4: Multi-Agent Orchestrator

Для больших задач (3+ файлов):

```bash
cd QwenPortable/enhancer
python multi_agent.py --task "создай fullstack Todo приложение"
```

**Что происходит:**
1. ✅ Задача разбивается на 2-3 подзадачи через Groq API
2. ✅ Запускаются 2-3 qwen процесса параллельно
3. ✅ Результаты сохраняются в `agent_results/`
4. ✅ Общее время: ~30-60 сек вместо 3-5 мин

---

## ⚙️ КОНФИГУРАЦИЯ

### enhancer/.env
```env
GROQ_API_KEY=gsk_твой_ключ
```

### enhancer/groq_config.json
```json
{
  "model": "llama-3.3-70b-versatile",
  "temperature": 0.4,
  "max_tokens": 1500,
  "xml_output": true,
  "rag_enabled": true,
  "rag_top_k": 3,
  "vector_search": false
}
```

### settings.json (главный конфиг)
```json
{
  "mcpServers": {
    "context7": { "command": "npx", "args": ["-y", "@upstash/context7-mcp@latest"] },
    "memory": { "command": "npx", "args": ["-y", "@modelcontextprotocol/server-memory@latest"] },
    "sequential-thinking": { "command": "npx", "args": ["-y", "@modelcontextprotocol/server-sequential-thinking@latest"] }
  },
  "skills": { "directory": "./skills" },
  "agents": { "directory": "./agents" },
  "systemPrompt": "C:\\путь\\к\\QwenPortable\\AGENT.md"
}
```

**Важно:** Замени путь в `systemPrompt` на актуальный!

---

## 🎯 АВТОМАТИЧЕСКОЕ УЛУЧШЕНИЕ ПРОМПТОВ

### Как это работает

```
1. Ты вводишь: "создай api"
   ↓
2. Prompt Enhancer получает промпт
   ↓
3. ТРЁХУРОВНЕВЫЙ RAG поиск:
   ├─ Уровень 1: Локальный RAG (SequenceMatcher) — быстро
   ├─ Уровень 2: CodeAlpaca-20k (HF Datasets API) — 20K примеров
   └─ Уровень 3: Семантика (HF Embeddings API) — умный поиск
   ↓
4. Объединение и дедупликация результатов
   ↓
5. Отправляет в Groq API (Llama 3.3 70B)
   ↓
6. Получает улучшенный XML промпт
   ↓
7. Добавляет тег <skill>fullstack</skill>
   ↓
8. Копирует в буфер обмена
   ↓
9. Отправляет в Qwen Code CLI
   ↓
10. Qwen активирует скилл `fullstack`
   ↓
11. Генерирует код по всем правилам скилла
```

### Триггеры скиллов

| Твои слова | Активируется скилл |
|------------|-------------------|
| `next.js`, `react`, `api` | `fullstack` |
| `android`, `kotlin` | `android_team` |
| `ios`, `swift` | `apple_design_system` |
| `проверь код`, `ревью` | `code_reviewer` |
| `безопасность`, `auth` | `security_guardian` |
| `тест`, `unit`, `e2e` | `testing_expert` |
| `оптимизируй` | `performance_optimizer` |
| `рефакторинг` | `refactoring_specialist` |
| `документация`, `readme` | `documentation_writer` |

---

## 🧠 ТРЁХУРОВНЕВЫЙ RAG

### Уровень 1: Локальный поиск

**Технология:** SequenceMatcher  
**Скорость:** < 0.1 сек  
**База:** 220+ локальных примеров  
**Статус:** ✅ Всегда включен

---

### Уровень 2: CodeAlpaca-20k онлайн

**Технология:** HuggingFace Datasets Server API  
**Скорость:** 2-6 сек  
**База:** 20,000 примеров кода  
**Статус:** ✅ Включен по умолчанию

**Команда управления:**
```bash
python enhancer/prompt_enhancer_groq.py
> онлайн  # Вкл/выкл CodeAlpaca
```

---

### Уровень 3: Семантический поиск

**Технология:** HuggingFace Embeddings API + numpy  
**Модель:** sentence-transformers/all-MiniLM-L6-v2  
**Скорость:** 3-6 сек  
**База:** 220+ локальных примеров с embeddings  
**Статус:** ✅ Включен по умолчанию

**Команда управления:**
```bash
python enhancer/prompt_enhancer_groq.py
> семантика  # Вкл/выкл семантический поиск
```

**Требования:**
- numpy (устанавливается автоматически при первом включении)

---

### Параллельное выполнение

Уровни 2 и 3 работают **параллельно** через threading:

```
Запрос
  ├─ Уровень 1 (синхронно) ──────┐
  ├─ Уровень 2 (поток) ──────────┤
  └─ Уровень 3 (поток) ──────────┤
                                 ↓
                    Объединение + дедупликация
                                 ↓
                         RAG контекст для Groq
```

**Таймаут:** 6 секунд на онлайн запрос  
**Дедупликация:** по short[:80] символам

---

### Конфигурация RAG

**enhancer/groq_config.json:**
```json
{
  "rag_enabled": true,
  "hf_codealpha_enabled": true,    // CodeAlpaca онлайн
  "hf_embed_enabled": true,        // Семантический поиск
  "hf_codealpha_limit": 3,
  "hf_embed_top_k": 2,
  "hf_timeout": 6
}
```

**По умолчанию:** все уровни включены ✅

---

## 📊 МЕТРИКИ

| Компонент | Значение |
|-----------|----------|
| **Скорость улучшения** | 1.0-1.6 сек |
| **RAG база** | 320 примеров (локально) |
| **CodeAlpaca-20k** | 20,000 примеров (онлайн) |
| **Модель** | Llama 3.3 70B (Groq) |
| **Скиллы** | 18 штук |
| **MCP серверы** | 9 штук |
| **Лимит Groq** | 100 запросов/день (бесплатно) |
| **Таймаут RAG** | 6 секунд на уровень |

---

## 🔧 ТРОУБЛШУТИНГ

### Ошибка: "GROQ_API_KEY не найден"

**Решение:**
```bash
# Открой enhancer/.env
# Замени на свой ключ:
GROQ_API_KEY=gsk_твой_новый_ключ
```

---

### Ошибка: "No module named 'groq'"

**Решение:**
```bash
pip install groq
```

---

### Ошибка: "qwen: команда не найдена"

**Решение:**
```bash
npm install -g @qwen-code/qwen-code
```

---

### Ошибка: "Python не найден"

**Решение:**
1. Скачай Python: https://python.org/downloads
2. Установи с галочкой **"Add Python to PATH"**
3. Перезапусти терминал

---

### Ошибка: "Rate limit exceeded"

**Причина:** Превышен лимит 100 запросов в день (бесплатный план Groq)

**Решение:**
- Подожди 24 часа
- Или используй режим без Groq:
  ```bash
  python enhancer/prompt_enhancer.py  # Ollama локально
  ```

---

### Ошибка: "No module named 'numpy'"

**Решение:**
```bash
pip install numpy
```

Или включи семантический поиск — numpy установится автоматически:
```bash
python enhancer/prompt_enhancer_groq.py
> семантика
  ⚙️  Устанавливаю numpy...
  Семантический RAG: включена ✅
```

---

## 📁 СТРУКТУРА ФАЙЛОВ

```
QwenPortable/
│
├── 📄 Конфигурация
│   ├── QWEN.md              ← Главный контекст
│   ├── AGENT.md             ← Инструкции агента v3.1.0
│   ├── settings.json        ← MCP серверы
│   └── .env                 ← GROQ_API_KEY
│
├── 🚀 Запуск
│   ├── start.bat            ← Главный launcher
│   ├── start-groq.bat       ← Groq launcher
│   ├── install.bat          ← Установка
│   └── bootstrap.ps1        ← Автоустановка
│
├── 🧠 Prompt Enhancer (enhancer/)
│   ├── prompt_enhancer_groq.py  ← Groq API ✅
│   ├── multi_agent.py           ← Мульти-агент
│   ├── start-agents.bat         ← Запуск multi_agent
│   ├── groq_config.json         ← Конфиг Groq
│   └── prompt_examples.json     ← RAG база (220 примеров)
│
├── 🎯 Скиллы (skills/) — 18 папок
│   ├── fullstack/
│   ├── code_reviewer/
│   ├── security_guardian/
│   └── ... (ещё 15)
│
└── 📚 Документация
    ├── README.md
    ├── SETUP_INSTRUCTIONS.md  ← Этот файл
    └── AGENT_UPDATE_REPORT.md
```

---

## 🎯 БЫСТРЫЙ СТАРТ (ЧЕКЛИСТ)

```
□ 1. Скопировал папку QwenPortable
□ 2. Установил Python 3.10+
□ 3. Установил Node.js
□ 4. Установил Qwen Code CLI: npm install -g @qwen-code/qwen-code
□ 5. Получил Groq API ключ: https://console.groq.com/keys
□ 6. Заменил ключ в enhancer/.env
□ 7. Установил pip зависимости: pip install groq sentence-transformers numpy
□ 8. Протестировал: python enhancer/prompt_enhancer_groq.py --once "создай api"
□ 9. Проверил RAG: > статус (в интерактивном режиме)
□ 10. Сделал бэкап: python backup_system.py (рекомендуется!)
□ 11. Готово! ✅
```

---

## 💡 СОВЕТЫ

### Для лучших результатов:

1. **Вводи короткие промпты** — Prompt Enhancer сам добавит детали
   - ✅ "создай api" → развёрнется в полный XML промпт
   - ❌ Не пиши длинные промпты вручную

2. **Используй триггеры скиллов** — система поймёт контекст
   - "создай api" → `fullstack`
   - "проверь код" → `code_reviewer`

3. **Давай обратную связь** — после генерации:
   - `д` → пример сохраняется и усиливается в RAG
   - `н` → пример помечается как неудачный

4. **Для больших задач используй Multi-Agent**
   - `python multi_agent.py --task "создай приложение"`
   - 3 агента работают параллельно

---

## 🔗 ПОЛЕЗНЫЕ ССЫЛКИ

- [Groq Console](https://console.groq.com) — управление API ключами
- [Qwen Code CLI](https://github.com/qwen-code/qwen-code) — документация
- [Ollama](https://ollama.com) — локальные модели (fallback)

---

## 🎉 ГОТОВО!

Теперь система полностью готова к работе на любом ПК.

**Просто запусти:**
```bash
start.bat
```

**И вводи любые промпты — они будут автоматически улучшены!** 🚀

---

**Версия инструкции:** 3.2.0  
**Последнее обновление:** Март 2026  
**Совместимость:** Windows 10/11, Linux (Ubuntu/Debian)

---

## 🆕 ЧТО НОВОГО В ВЕРСИИ 3.4.0

### Обновление RAG базы

**Дата:** 22 марта 2026

**Было:** 226 примеров  
**Стало:** 320 примеров  
**Прирост:** +94 примера (+41%)

**Новые темы:**
- Обработка видео (FFmpeg)
- HTTP кэширование и CDN
- OpenTelemetry трассировка
- i18n интернационализация
- Кастомные React хуки
- Анимации Compose/SwiftUI
- Dependency scanning
- Health check endpoint
- API версионирование
- PostgreSQL оптимизация

**Утилита слияния:** `merge_rag_examples.py`
- Автоматическое обнаружение дубликатов
- Добавление missing полей
- Статистика слияния

---

## 🆕 ЧТО НОВОГО В ВЕРСИИ 3.3.0

### Бэкап системы

**Новая утилита:** `backup_system.py` + `backup.bat`

**Назначение:** Создание резервной копии проекта перед внесением сильных изменений.

**Использование:**
```bash
# Автоматическое имя (backup_YYYY-MM-DD_HH-MM.zip)
python backup_system.py

# Своё имя
python backup_system.py --output my_backup.zip

# Через .bat файл
backup.bat
```

**Исключаются из бэкапа:**
- `__pycache__/`, `*.pyc`, `*.log`
- `agent_results/`, `.git/`, `.qwen/`
- `models/` (локальные модели, большие файлы)
- `*.zip` (старые бэкапы)

### Правило в AGENT.md

**Раздел 6:** "Бэкап системы и обновление инструкций"

**Триггеры для бэкапа:**
- Изменение ≥ 3 файлов одновременно
- Изменение core-файлов (AGENT.md, QWEN.md, settings.json, prompt_enhancer_groq.py)
- Добавление ≥ 2 новых файлов
- Изменение структуры папок

**Протокол:**
1. Агент спрашивает: "Сделать бэкап в backup.zip?"
2. Если "да" → создаёт бэкап ДО изменений
3. Если "нет" → вносит изменения, затем обновляет инструкции

**Автообновление инструкций** (если бэкап НЕ делался):
- SETUP_INSTRUCTIONS.md
- START_HERE.md
- QWEN.md, README.md (при необходимости)
- SETUP_UPDATE_REPORT.md (отчёт)

---

## 🆕 ЧТО НОВОГО В ВЕРСИИ 3.2.0

### Трёхуровневый RAG

**Уровень 1:** Локальный поиск (SequenceMatcher) — быстро, без сети  
**Уровень 2:** CodeAlpaca-20k онлайн (HuggingFace Datasets API) — 20,000 примеров  
**Уровень 3:** Семантический поиск (HuggingFace Embeddings API + numpy) — умный RAG

### Новые команды

- `онлайн` — вкл/выкл CodeAlpaca-20k
- `семантика` — вкл/выкл семантический поиск
- `статус` — показывает все настройки RAG

### Зависимости

- **numpy** — для семантического поиска (устанавливается автоматически)
- **sentence-transformers** — для локальных embeddings

### Производительность

- **Без онлайн RAG:** 0.7-1.1 сек
- **С онлайн RAG:** 1.1-1.6 сек
- **Таймаут:** 6 секунд на уровень
