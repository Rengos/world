# 🚀 QWEN PORTABLE — ИНИЦИАЛИЗАЦИЯ СЕССИИ

**Для новой сессии Qwen:** Прочитай этот файл ПЕРВЫМ!

---

## ⚡ БЫСТРЫЙ СТАРТ (30 секунд)

```bash
# 1. Прочитай этот файл (ты уже здесь!) ✅
# 2. Просканируй систему командой ниже
# 3. Начни работу
```

---

## 🔍 СКАНИРОВАНИЕ СИСТЕМЫ

**Выполни команду для полного сканирования (из папки QwenPortable):**

```bash
# Windows CMD
dir /s /b . | findstr /v "__pycache__" | findstr /v ".git" | findstr /v "node_modules"

# Windows PowerShell
Get-ChildItem -Recurse | Where-Object {$_.Name -notmatch "__pycache__|\.git|node_modules"} | Select-Object FullName

# Python
python -c "import os; [print(os.path.join(r,f)) for r,d,files in os.walk('.') for f in files if '__pycache__' not in r and not f.endswith('.pyc')]"
```

---

## 📁 СТРУКТУРА ПРОЕКТА

```
QwenPortable/
│
├── 📄 CORE ФАЙЛЫ (прочитай в первую очередь)
│   ├── AGENT.md              ← Инструкции агента (v3.4.0)
│   ├── QWEN.md               ← Главный контекст
│   ├── settings.json         ← MCP серверы (9 шт)
│   └── README.md             ← Основная документация
│
├── 🚀 ЗАПУСК
│   ├── start.bat             ← Главный launcher
│   ├── start-groq.bat        ← Groq launcher
│   ├── backup.bat            ← Бэкап системы
│   └── START/                ← Инструкции по установке
│       ├── START_HERE.md     ← Быстрый старт
│       ├── SETUP_INSTRUCTIONS.md ← Полная инструкция
│       └── SESSION_INITIALIZER.md ← Этот файл
│
├── 🧠 PROMPT ENHANCER (enhancer/)
│   ├── prompt_enhancer_groq.py   ← Улучшение промптов (Groq API)
│   ├── multi_agent.py            ← Мульти-агент оркестратор
│   ├── groq_config.json          ← Конфигурация Groq
│   ├── prompt_examples.json      ← RAG база (337+ примеров)
│   └── .env                      ← GROQ_API_KEY
│
├── 🎯 СКИЛЛЫ (skills/) — 18 скиллов
│   ├── fullstack/                ← React, Next.js, Node.js
│   ├── android_team/             ← Kotlin, Jetpack Compose
│   ├── apple_design_system/      ← Swift, SwiftUI
│   ├── code_reviewer/            ← Ревью кода
│   ├── security_guardian/        ← Безопасность
│   ├── testing_expert/           ← Тесты (Unit, E2E)
│   ├── performance_optimizer/    ← Оптимизация
│   ├── refactoring_specialist/   ← Рефакторинг
│   ├── documentation_writer/     ← Документация
│   ├── chain_of_thought/         ← CoT рассуждения
│   ├── deep_reasoning/           ← Глубокий анализ
│   ├── humanizer/                ← Humanizer кода
│   ├── mcp_docs_checker/         ← Проверка MCP
│   ├── mcp_manager/              ← MCP менеджер
│   ├── skill_creator/            ← Создание скиллов
│   ├── skill_orchestrator/       ← Оркестрация скиллов
│   ├── execution_tracker/        ← Трекинг выполнения
│   └── failure_observer/         ← Наблюдение ошибок
│
├── 🆕 ДОП. СКИЛЛЫ (DOPOAGENT/)
│   ├── phantom_browser_expert.md    ← PhantomBrowser разработка
│   └── phantom_browser_integration.md ← PhantomBrowser интеграция
│
├── 🤖 АГЕНТЫ (agents/)
│   └── [агенты для сложных задач]
│
├── 📚 ОТЧЁТЫ
│   ├── AGENT_UPDATE_REPORT.md
│   ├── BACKUP_SYSTEM_REPORT.md
│   ├── RAG_UPDATE_REPORT.md
│   ├── SETUP_UPDATE_REPORT.md
│   └── SETUP_UPDATE_REPORT_V2.md
│
└── 🛠️ УТИЛИТЫ
    ├── backup_system.py        ← Бэкап системы
    ├── setup.py                ← Установка
    ├── bootstrap.ps1           ← Автоустановка (PowerShell)
    ├── bootstrap.sh            ← Автоустановка (Bash)
    ├── create-skill.bat        ← Создание скилла
    └── merge_rag_examples.py   ← Слияние RAG базы
```

---

## 🎯 ТРИГГЕРЫ СКИЛЛОВ

| Твои слова | Скилл | Папка |
|------------|-------|-------|
| `api`, `react`, `next.js`, `fullstack` | fullstack | skills/fullstack/ |
| `android`, `kotlin`, `compose` | android_team | skills/android_team/ |
| `ios`, `swift`, `swiftui` | apple_design_system | skills/apple_design_system/ |
| `проверь код`, `ревью`, `code review` | code_reviewer | skills/code_reviewer/ |
| `безопасность`, `auth`, `security` | security_guardian | skills/security_guardian/ |
| `тест`, `unit`, `e2e` | testing_expert | skills/testing_expert/ |
| `оптимизируй`, `performance` | performance_optimizer | skills/performance_optimizer/ |
| `рефакторинг`, `refactor` | refactoring_specialist | skills/refactoring_specialist/ |
| `документация`, `readme` | documentation_writer | skills/documentation_writer/ |
| `PhantomBrowser`, `антидетект` | phantom_browser_expert | DOPOAGENT/ |

---

## 🧠 КАК РАБОТАЕТ СИСТЕМА

```
1. Твой промпт → Prompt Enhancer (Groq API)
2. RAG поиск → 337+ примеров (3 уровня RAG)
3. Улучшение → XML промпт с <skill>...</skill>
4. Активация скилла → Специализированная генерация
5. Результат → Готовый код

Время улучшения: 1.0-1.6 секунды
```

---

## 🔧 MCP СЕРВЕРЫ (settings.json)

**9 серверов подключено:**

```json
{
  "mcpServers": {
    "context7": {},           // Документация библиотек
    "memory": {},             // Долговременная память
    "sequential-thinking": {}, // Последовательные рассуждения
    // ... ещё 6 серверов
  }
}
```

**⛔ ЗАПРЕЩЕНО:** Удалять серверы из settings.json!

---

## 🚀 КОМАНДЫ

### Запуск системы:
```bash
start.bat              # Главный launcher
start-groq.bat         # Groq launcher
backup.bat             # Бэкап системы
```

### Prompt Enhancer:
```bash
# Интерактивно
python enhancer/prompt_enhancer_groq.py

# Одиночный промпт
python enhancer/prompt_enhancer_groq.py --once "создай api"

# Multi-Agent (3+ файла)
python enhancer/multi_agent.py --task "создай приложение"
```

### Команды в интерактивном режиме:
| Команда | Назначение |
|---------|------------|
| `статус` | Показать настройки |
| `онлайн` | Вкл/выкл CodeAlpaca-20k |
| `семантика` | Вкл/выкл семантический поиск |
| `режим` | XML ↔ TEXT |
| `история` | Показать историю |
| `очистить` | Очистить историю |
| `очистка` | Удалить старые примеры |
| `индекс` | Пересчитать embeddings |

---

## 📊 ТРЁХУРОВНЕВЫЙ RAG

**Уровень 1:** Локальный поиск (SequenceMatcher) — быстро, без сети
**Уровень 2:** CodeAlpaca-20k онлайн (HF Datasets API) — 20,000 примеров
**Уровень 3:** Семантический поиск (HF Embeddings API) — умный RAG

**База:** 337+ примеров
**Таймаут:** 6 секунд на уровень
**Дедупликация:** по short[:80]

---

## ⚠️ КРИТИЧНО ВАЖНО

### При сильных изменениях:
1. **Спроси пользователя** о создании бэкапа
2. **Создай backup_YYYY-MM-DD_HH-MM.zip** ДО изменений
3. **Обнови инструкции** ПОСЛЕ изменений

### При работе с settings.json:
- ⛔ **НЕ УДАЛЯЙ** MCP серверы
- ✅ **МОЖНО** добавлять новые серверы
- ✅ **МОЖНО** исправлять синтаксис JSON

---

## 📚 ДОКУМЕНТАЦИЯ

### Для новых сессий:
1. **SESSION_INITIALIZER.md** (этот файл) — сканирование системы
2. **START_HERE.md** — быстрый старт
3. **AGENT.md** — инструкции агента
4. **QWEN.md** — главный контекст

### Для пользователей:
- **SETUP_INSTRUCTIONS.md** — полная инструкция по установке
- **README.md** — основная документация

### Отчёты:
- **BACKUP_SYSTEM_REPORT.md** — о бэкапе системы
- **RAG_UPDATE_REPORT.md** — о RAG базе
- **AGENT_UPDATE_REPORT.md** — об обновлениях агента

---

## 💡 СОВЕТЫ ДЛЯ НОВОЙ СЕССИИ

### 1. Просканируй систему:
```bash
dir /s /b .
```

### 2. Прочитай core файлы:
- AGENT.md (инструкции)
- QWEN.md (контекст)
- settings.json (MCP серверы)

### 3. Проверь скиллы:
```bash
dir skills /b
dir DOPOAGENT /b
```

### 4. Начни работу:
```bash
# Используй Prompt Enhancer для улучшения промптов
python enhancer/prompt_enhancer_groq.py --once "твой промпт"
```

---

## 🎯 ПРИМЕР СЕССИИ

```
1. Пользователь: "создай REST API для пользователей"
   ↓
2. Prompt Enhancer улучшает промпт (1.4 сек)
   ↓
3. RAG находит 3 релевантных примера
   ↓
4. Активируется скилл <skill>fullstack</skill>
   ↓
5. Генерация кода с учётом best practices
   ↓
6. Результат: готовый REST API с валидацией Zod
```

---

## 🔗 ССЫЛКИ

- **Groq Console:** https://console.groq.com/keys
- **Qwen Code CLI:** https://github.com/qwen-code/qwen-code
- **Ollama:** https://ollama.com

---

**Готово!** Теперь ты знаешь как работает система.

**Начни работу с команды:**
```bash
python enhancer/prompt_enhancer_groq.py --once "твой первый промпт"
```

---

**Версия:** 3.4.0 | **Дата:** Март 2026 г.
