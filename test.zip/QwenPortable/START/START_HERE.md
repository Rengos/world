# ⚡ QWEN PORTABLE — БЫСТРЫЙ СТАРТ

## 🚀 НОВАЯ СЕССИЯ? Начни отсюда!

**Первый файл для чтения:** `SESSION_INITIALIZER.md` ← **ПРОЧТИ ЭТО ПЕРВЫМ!**

Этот файл содержит:
- ✅ Команды для сканирования всей системы
- ✅ Список всех 18+ скиллов с триггерами
- ✅ Структуру проекта с описанием
- ✅ Инструкции как работать с системой

---

## 🔄 Перенёс на другой ПК? 4 шага:

```bash
# 1. Установи Python зависимости
pip install groq sentence-transformers numpy

# 2. Замени API ключ (ОБЯЗАТЕЛЬНО!)
#    Открой: enhancer/.env
#    Замени: GROQ_API_KEY=твой_ключ_с_https://console.groq.com/keys

# 3. Протестируй
python enhancer/prompt_enhancer_groq.py --once "создай api"

# 4. Пользуйся!
start.bat
```

---

## 📁 Что в папке

| Файл | Назначение |
|------|------------|
| **../start.bat** | Главный launcher — двойной клик |
| **../backup.bat** | Бэкап системы — перед изменениями |
| **SETUP_INSTRUCTIONS.md** | Полная инструкция (20KB) |
| **../QWEN.md** | Главный контекст для Qwen |
| **../AGENT.md** | Инструкции агента v3.4.0 |
| **../settings.json** | MCP серверы (9 шт) |
| **../enhancer/** | Prompt Enhancer (Groq API) |
| **../skills/** | 18 скиллов |

---

## 🎯 Как работает

```
Ты: "создай api"
  ↓
Prompt Enhancer (Groq API → Llama 3.3 70B)
  ↓
XML промпт с <skill>fullstack</skill>
  ↓
Qwen Code CLI → генерация кода
```

**Время улучшения:** 1.0-1.6 секунды  
**RAG база:** 320 примеров  
**Лимит Groq:** 100 запросов/день (бесплатно)

---

## 🔧 Зависимости

| Что | Зачем | Где |
|-----|-------|-----|
| Python 3.10+ | Prompt Enhancer | python.org |
| Groq API ключ | Улучшение промптов | console.groq.com |
| Qwen Code CLI | Генерация кода | npm install -g @qwen-code/qwen-code |
| groq (pip) | Groq SDK | pip install groq |
| sentence-transformers | Векторный поиск | pip install sentence-transformers |
| numpy | Семантический RAG | pip install numpy |

---

## 📊 Триггеры скиллов

| Твои слова | Скилл |
|------------|-------|
| `api`, `react`, `next.js` | fullstack |
| `android`, `kotlin` | android_team |
| `ios`, `swift` | apple_design_system |
| `проверь код`, `ревью` | code_reviewer |
| `безопасность`, `auth` | security_guardian |
| `тест`, `e2e` | testing_expert |
| `оптимизируй` | performance_optimizer |
| `рефакторинг` | refactoring_specialist |
| `документация` | documentation_writer |

---

## 🚀 Команды

```bash
# Интерактивный Prompt Enhancer
python ../enhancer/prompt_enhancer_groq.py

# Одиночный промпт
python ../enhancer/prompt_enhancer_groq.py --once "создай api"

# Multi-Agent (большие задачи)
python ../enhancer/multi_agent.py --task "создай приложение"

# Бэкап системы (перед изменениями)
python ../backup_system.py
# или
../backup.bat

# Напрямую в Qwen
qwen
```

### Команды в интерактивном режиме:

| Команда | Назначение |
|---------|------------|
| `статус` | Показать настройки |
| `онлайн` | Вкл/выкл CodeAlpaca-20k |
| `семантика` | Вкл/выкл семантический поиск |
| `режим` | XML ↔ TEXT |
| `история` | Показать историю |
| `очистить` | Очистить историю |
| `очистка` | Удалить старые примеры |
| `индекс` | Пересчитать embeddings |

---

## 🧠 ТРЁХУРОВНЕВЫЙ RAG

**Уровень 1:** Локальный поиск (SequenceMatcher) — быстро, без сети  
**Уровень 2:** CodeAlpaca-20k онлайн (HF Datasets API) — 20,000 примеров  
**Уровень 3:** Семантический поиск (HF Embeddings API) — умный RAG

**По умолчанию:** включены все 3 уровня  
**Таймаут:** 6 секунд на онлайн запрос  
**Дедупликация:** по short[:80]

---

## ⚠️ Troubleshooting

| Ошибка | Решение |
|--------|---------|
| GROQ_API_KEY не найден | Замени в ../enhancer/.env |
| No module named 'groq' | pip install groq |
| qwen: команда не найдена | npm install -g @qwen-code/qwen-code |
| Rate limit exceeded | Подожди 24 часа |
| No module named 'numpy' | pip install numpy |

---

## 📚 Полная документация

→ Читай **SETUP_INSTRUCTIONS.md** (20KB) в этой же папке

---

**Версия:** 3.4.0 | **Обновлено:** Март 2026
