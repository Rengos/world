#!/usr/bin/env python3
"""
System Backup Utility for Qwen Portable
========================================
Создаёт бэкап проекта в backup.zip с timestamp.

Использование:
  python backup_system.py
  python backup_system.py --output my_backup.zip
"""

import os
import sys
import zipfile
import argparse
from pathlib import Path
from datetime import datetime

# ── Конфигурация ─────────────────────────────────────────────────────────────

SCRIPT_DIR = Path(__file__).parent.resolve()

# Что исключать из бэкапа
EXCLUDE_PATTERNS = [
    '__pycache__',
    '*.pyc',
    '*.pyo',
    '*.log',
    'agent_results',
    '.git',
    '.qwen',
    'models',  # Локальные модели (большие файлы)
    '*.zip',   # Старые бэкапы
]

# ── Функции ───────────────────────────────────────────────────────────────────


def should_exclude(path: Path, base_dir: Path) -> bool:
    """Проверить, нужно ли исключить файл/папку из бэкапа."""
    rel_path = path.relative_to(base_dir)
    path_str = str(rel_path)
    
    for pattern in EXCLUDE_PATTERNS:
        # Проверка по имени папки/файла
        if path.name == pattern or path.name.endswith(pattern.lstrip('*')):
            return True
        # Проверка по полному пути
        if pattern in path_str:
            return True
    
    return False


def create_backup(output_path: Path = None) -> Path:
    """Создать бэкап проекта."""
    if output_path is None:
        timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M")
        output_path = SCRIPT_DIR / f"backup_{timestamp}.zip"
    
    # Создаём zip файл
    print(f"\n{'='*60}")
    print(f"  📦 Создание бэкапа Qwen Portable")
    print(f"{'='*60}\n")
    
    files_added = 0
    total_size = 0
    
    with zipfile.ZipFile(output_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
        # Проходим по всем файлам в проекте
        for root, dirs, files in os.walk(SCRIPT_DIR):
            root_path = Path(root)
            
            # Исключаем ненужные папки
            dirs[:] = [d for d in dirs if not should_exclude(root_path / d, SCRIPT_DIR)]
            
            for file in files:
                file_path = root_path / file
                
                # Пропускаем исключённые файлы
                if should_exclude(file_path, SCRIPT_DIR):
                    continue
                
                # Добавляем файл в архив
                try:
                    arcname = file_path.relative_to(SCRIPT_DIR)
                    zipf.write(file_path, arcname)
                    
                    files_added += 1
                    total_size += file_path.stat().st_size
                    
                    # Прогресс каждые 50 файлов
                    if files_added % 50 == 0:
                        print(f"  📝 Добавлено файлов: {files_added}")
                        
                except Exception as e:
                    print(f"  ⚠️  Ошибка добавления {file_path}: {e}")
    
    # Статистика
    size_mb = total_size / (1024 * 1024)
    print(f"\n{'─'*60}")
    print(f"  ✅ Бэкап создан успешно!")
    print(f"  📁 Файл: {output_path.name}")
    print(f"  📊 Файлов: {files_added}")
    print(f"  💾 Размер: {size_mb:.2f} MB")
    print(f"{'─'*60}\n")
    
    return output_path


# ── Main ──────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="Создать бэкап Qwen Portable")
    parser.add_argument("--output", "-o", help="Имя выходного файла (по умолчанию: backup_YYYY-MM-DD_HH-MM.zip)")
    parser.add_argument("--quiet", "-q", action="store_true", help="Тихий режим (минимум вывода)")
    args = parser.parse_args()
    
    if args.quiet:
        import io
        sys.stdout = io.StringIO()
    
    output_path = Path(args.output) if args.output else None
    
    try:
        backup_file = create_backup(output_path)
        
        if not args.quiet:
            print(f"  📍 Путь: {backup_file}")
            print(f"\n{'='*60}\n")
        
        return 0
        
    except Exception as e:
        print(f"\n  ❌ Ошибка создания бэкапа: {e}\n")
        return 1


if __name__ == "__main__":
    sys.exit(main())
