# QwenPortable Bootstrap v1.0 — Windows PowerShell
# Запускать: правой кнопкой → "Запустить с PowerShell"
# Не требует Python, pip, или других зависимостей

$ErrorActionPreference = "Continue"
$SCRIPT_DIR = Split-Path -Parent $MyInvocation.MyCommand.Path
$MODELS_DIR = Join-Path $SCRIPT_DIR "models"

function Log($msg)  { Write-Host "`n== $msg ==" -ForegroundColor Cyan }
function Ok($msg)   { Write-Host "  OK  $msg" -ForegroundColor Green }
function Err($msg)  { Write-Host "  ERR $msg" -ForegroundColor Red }
function Info($msg) { Write-Host "  ... $msg" -ForegroundColor Yellow }

Write-Host @"
==============================================
  QwenPortable Bootstrap — Windows
==============================================
"@ -ForegroundColor Cyan

# ─── Шаг 1: Python ────────────────────────────────────────────────────────────

Log "Шаг 1: Python"

$pythonCmd = $null
foreach ($cmd in @("python", "python3", "py")) {
    try {
        $ver = & $cmd --version 2>&1
        if ($ver -match "Python 3\.(1[0-9]|[2-9]\d)") {
            $pythonCmd = $cmd
            Ok "Найден: $ver"
            break
        }
    } catch {}
}

if (-not $pythonCmd) {
    Info "Python не найден. Устанавливаю через winget..."
    
    # Пробуем winget (Windows 11 / обновлённый Win 10)
    $winget = Get-Command winget -ErrorAction SilentlyContinue
    if ($winget) {
        winget install -e --id Python.Python.3.12 --silent --accept-package-agreements --accept-source-agreements
        $env:PATH = [System.Environment]::GetEnvironmentVariable("PATH", "Machine") + ";" + [System.Environment]::GetEnvironmentVariable("PATH", "User")
        $pythonCmd = "python"
        Ok "Python установлен через winget"
    } else {
        # Скачиваем установщик Python напрямую
        Info "Скачиваю Python 3.12 установщик..."
        $pythonUrl = "https://www.python.org/ftp/python/3.12.0/python-3.12.0-amd64.exe"
        $pythonInstaller = Join-Path $env:TEMP "python_installer.exe"
        
        Invoke-WebRequest -Uri $pythonUrl -OutFile $pythonInstaller -UseBasicParsing
        Info "Устанавливаю Python (тихая установка)..."
        Start-Process -FilePath $pythonInstaller -ArgumentList "/quiet InstallAllUsers=1 PrependPath=1" -Wait
        Remove-Item $pythonInstaller -Force -ErrorAction SilentlyContinue
        
        # Обновляем PATH
        $env:PATH = [System.Environment]::GetEnvironmentVariable("PATH", "Machine") + ";" + [System.Environment]::GetEnvironmentVariable("PATH", "User")
        $pythonCmd = "python"
        Ok "Python установлен"
    }
}

# ─── Шаг 2: Ollama ────────────────────────────────────────────────────────────

Log "Шаг 2: Ollama"

$ollamaExists = Get-Command ollama -ErrorAction SilentlyContinue
if ($ollamaExists) {
    Ok "Ollama уже установлена"
} else {
    Info "Скачиваю Ollama..."
    $ollamaUrl = "https://ollama.com/download/OllamaSetup.exe"
    $ollamaInstaller = Join-Path $env:TEMP "OllamaSetup.exe"
    
    Invoke-WebRequest -Uri $ollamaUrl -OutFile $ollamaInstaller -UseBasicParsing
    Info "Устанавливаю Ollama..."
    Start-Process -FilePath $ollamaInstaller -ArgumentList "/S" -Wait
    Remove-Item $ollamaInstaller -Force -ErrorAction SilentlyContinue
    
    $env:PATH = [System.Environment]::GetEnvironmentVariable("PATH", "Machine") + ";" + [System.Environment]::GetEnvironmentVariable("PATH", "User")
    Ok "Ollama установлена"
}

# ─── Шаг 3: Запуск Ollama ─────────────────────────────────────────────────────

Log "Шаг 3: Запуск Ollama"

$env:OLLAMA_MODELS = $MODELS_DIR
if (-not (Test-Path $MODELS_DIR)) { New-Item -ItemType Directory -Path $MODELS_DIR | Out-Null }

$ollamaRunning = Get-Process -Name "ollama" -ErrorAction SilentlyContinue
if ($ollamaRunning) {
    Ok "Ollama уже запущена"
} else {
    Info "Запускаю Ollama..."
    Start-Process -FilePath "ollama" -ArgumentList "serve" -WindowStyle Minimized
    Start-Sleep -Seconds 4
    Ok "Ollama запущена"
}

# ─── Шаг 4: Модель ────────────────────────────────────────────────────────────

Log "Шаг 4: Модель qwen2.5:1.5b"

$modelExists = & ollama list 2>&1 | Select-String "qwen2.5"
if ($modelExists) {
    Ok "Модель уже скачана"
} elseif ((Test-Path $MODELS_DIR) -and (Get-ChildItem $MODELS_DIR -Recurse -File | Measure-Object).Count -gt 0) {
    Ok "Модели найдены локально"
} else {
    Info "Скачиваю qwen2.5:1.5b (~1GB)..."
    $env:OLLAMA_MODELS = $MODELS_DIR
    & ollama pull qwen2.5:1.5b
    Ok "Модель скачана"
}

# ─── Шаг 5: pip + ollama пакет ────────────────────────────────────────────────

Log "Шаг 5: pip зависимости"

& $pythonCmd -m pip install ollama anthropic --quiet 2>&1 | Out-Null
Ok "ollama + anthropic (pip) установлены"

# ─── Шаг 6: Node.js + Qwen Code CLI ──────────────────────────────────────────

Log "Шаг 6: Qwen Code CLI"

$nodeExists = Get-Command node -ErrorAction SilentlyContinue
if (-not $nodeExists) {
    Info "Node.js не найден. Устанавливаю..."
    $winget2 = Get-Command winget -ErrorAction SilentlyContinue
    if ($winget2) {
        winget install -e --id OpenJS.NodeJS.LTS --silent --accept-package-agreements --accept-source-agreements
        $env:PATH = [System.Environment]::GetEnvironmentVariable("PATH", "Machine") + ";" + [System.Environment]::GetEnvironmentVariable("PATH", "User")
        Ok "Node.js установлен"
    } else {
        Err "Установи Node.js вручную: https://nodejs.org"
    }
}

$qwenExists = Get-Command qwen -ErrorAction SilentlyContinue
if ($qwenExists) {
    Ok "Qwen Code CLI уже установлен"
} else {
    Info "Устанавливаю Qwen Code CLI..."
    & npm install -g "@qwen-code/qwen-code" 2>&1 | Out-Null
    Ok "Qwen Code CLI установлен"
}

# ─── Шаг 7: Финальный start.bat ───────────────────────────────────────────────

Log "Шаг 7: Создаю start.bat"

$batContent = @"
@echo off
chcp 65001 > nul
set OLLAMA_MODELS=$MODELS_DIR
tasklist /fi "imagename eq ollama.exe" | find /i "ollama.exe" > nul 2>&1
if errorlevel 1 (
    start /min "" ollama serve
    timeout /t 3 /nobreak > nul
)
$pythonCmd "$SCRIPT_DIR\enhancer\prompt_enhancer.py" %*
"@

$batContent | Out-File -FilePath (Join-Path $SCRIPT_DIR "start.bat") -Encoding UTF8
Ok "start.bat создан"

# ─── Готово ───────────────────────────────────────────────────────────────────

Write-Host @"

==============================================
  ГОТОВО!

  Папка:    $SCRIPT_DIR
  Модели:   $MODELS_DIR
  Python:   $pythonCmd

  Запуск:   start.bat (двойной клик)

  Или Qwen Code CLI напрямую:
  cd $SCRIPT_DIR
  qwen
==============================================
"@ -ForegroundColor Green

Read-Host "Нажми Enter для выхода"
