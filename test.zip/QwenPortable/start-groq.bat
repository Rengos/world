@echo off
chcp 65001 >nul
title Prompt Enhancer — Groq Llama 3.3 70B

:: Читаем API ключ из .env
if exist "%~dp0enhancer\.env" (
    for /f "tokens=1,* delims==" %%a in ('type "%~dp0enhancer\.env"') do (
        if "%%a"=="GROQ_API_KEY" set GROQ_API_KEY=%%b
    )
)

:: Проверка Python
where python >nul 2>&1
if errorlevel 1 (
    echo ❌ Python не найден!
    echo Скачай: https://python.org/downloads
    pause
    exit /b 1
)

:: Запуск Prompt Enhancer с Groq
echo.
echo 🚀 Prompt Enhancer — Groq Llama 3.3 70B
echo.
python "%~dp0enhancer\prompt_enhancer_groq.py" %*

pause
