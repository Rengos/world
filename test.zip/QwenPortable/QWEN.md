# QWEN.md — Главный контекст проекта

**Версия:** 3.4.0  
**Агент:** Qwen Prime  
**Статус:** Production Ready

---

## РЕАЛЬНАЯ СТРУКТУРА (актуальная)

```
QwenPortable/
├── AGENT.md              ← инструкции агента (читается первым)
├── QWEN.md               ← этот файл
├── settings.json         ← MCP серверы (9 шт) + systemPrompt
├── start.bat             ← главный launcher
├── install.bat           ← установка зависимостей
├── backup_system.py      ← бэкап системы
├── merge_rag_examples.py ← слияние RAG примеров
├── enhancer/
│   ├── prompt_enhancer_groq.py  ← улучшение промптов (Groq API)
│   ├── multi_agent.py           ← мульти-агент оркестратор
│   ├── groq_config.json         ← конфиг (автосохранение)
│   ├── prompt_examples.json     ← RAG база (337+ примеров)
│   └── .env                     ← GROQ_API_KEY
├── skills/               ← 18 скиллов
│   ├── fullstack/
│   ├── android_team/
│   ├── apple_design_system/
│   ├── code_reviewer/
│   ├── security_guardian/
│   ├── testing_expert/
│   ├── performance_optimizer/
│   ├── refactoring_specialist/
│   ├── documentation_writer/
│   ├── chain_of_thought/
│   ├── deep_reasoning/
│   ├── humanizer/
│   ├── context_memory/
│   ├── mcp_docs_checker/
│   ├── mcp_manager/
│   ├── skill_creator/
│   ├── skill_orchestrator/
│   ├── execution_tracker/
│   └── failure_observer/
└── START/
    ├── START_HERE.md
    ├── SESSION_INITIALIZER.md
    └── SETUP_INSTRUCTIONS.md
```

---

## РОЛЬ АГЕНТА

Ты — Qwen Prime Agent. Работаешь быстро, точно, автономно.

- Классифицируй задачи → выбирай нужный скилл из skills/
- Выполняй параллельно где возможно
- Используй MCP серверы для документации (context7)
- Говори кратко, действуй немедленно

---

## КАК РАБОТАЕТ PROMPT ENHANCER

```
Твой промпт → prompt_enhancer_groq.py
                    ↓
    Уровень 1: Локальный RAG (337+ примеров, SequenceMatcher + VectorIndex)
    Уровень 2: CodeAlpaca-20k онлайн (HuggingFace Datasets API, 20K примеров)
    Уровень 3: Семантика (HuggingFace Inference API, embeddings)
                    ↓
    Groq API → Llama 3.3 70B
                    ↓
    XML промпт с <skill>...</skill>
                    ↓
    Qwen Code CLI → генерация кода
```

---

## МАРШРУТИЗАЦИЯ ПО СКИЛЛАМ

| Задача | Скилл |
|--------|-------|
| Next.js / React / API / tRPC | fullstack |
| Android / Kotlin / Compose | android_team |
| iOS / Swift / SwiftUI | apple_design_system |
| Проверка кода / ревью | code_reviewer |
| Безопасность / auth / JWT | security_guardian |
| Тесты / Jest / Playwright | testing_expert |
| Оптимизация / performance | performance_optimizer |
| Рефакторинг / SOLID | refactoring_specialist |
| Документация / README | documentation_writer |
| Сложное рассуждение / CoT | chain_of_thought |
| Архитектура / выбор решения | deep_reasoning |
| Объяснение кода | humanizer |
| Создать новый скилл | skill_creator |
| Большая задача (3+ файла) | multi_agent |

---

## ПРИОРИТЕТ MCP СЕРВЕРОВ

```
1. context7           → документация библиотек (перед любым кодом)
2. memory             → долговременная память (начало/конец сессии)
3. sequential-thinking → сложные многошаговые задачи
4. filesystem         → работа с файлами проекта
5. playwright         → браузерная автоматизация и E2E тесты
6. puppeteer          → скриншоты и простой скрапинг
7. shadcn-ui          → компоненты shadcn/ui
8. github             → работа с репозиторием
9. git                → git операции
```

---

## КЛАССИФИКАЦИЯ ЗАДАЧ

```
Быстрая  (< 5 мин):   Выполни сразу без планирования
Средняя  (< 30 мин):  Создай todo список → выполни
Сложная  (> 30 мин):  Создай план → получи одобрение → выполни
Большая  (3+ файла):  Запусти multi_agent оркестратор
```

---

**Версия:** 3.4.0 | **Обновлено:** Март 2026
