#!/usr/bin/env python3
"""
Merge prompt examples from folder 1/ into enhancer/prompt_examples.json
Compares by ID and adds missing examples.
"""

import json
from pathlib import Path

SCRIPT_DIR = Path(__file__).parent.resolve()
FOLDER_1 = SCRIPT_DIR / "1"
RAG_FILE = SCRIPT_DIR / "enhancer" / "prompt_examples.json"

def load_json_file(path: Path) -> list:
    """Load JSON file."""
    with open(path, 'r', encoding='utf-8') as f:
        return json.load(f)

def save_json_file(path: Path, data: list):
    """Save JSON file."""
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def main():
    print("\n" + "="*60)
    print("  📚 Merge Prompt Examples")
    print("="*60 + "\n")
    
    # Load current RAG
    if not RAG_FILE.exists():
        print(f"❌ RAG file not found: {RAG_FILE}")
        return
    
    rag_examples = load_json_file(RAG_FILE)
    print(f"📖 Current RAG: {len(rag_examples)} examples")
    
    # Create ID set for quick lookup
    rag_ids = {ex.get('id', '') for ex in rag_examples}
    print(f"📋 Existing IDs: {len(rag_ids)} unique")
    
    # Find all files in folder 1/
    if not FOLDER_1.exists():
        print(f"❌ Folder not found: {FOLDER_1}")
        return
    
    example_files = sorted(FOLDER_1.glob("prompt_examples_*.json"))
    print(f"📁 Found {len(example_files)} files in folder 1/\n")
    
    # Merge examples
    added_count = 0
    skipped_count = 0
    
    for file_path in example_files:
        print(f"  Processing: {file_path.name}")
        try:
            examples = load_json_file(file_path)
            
            for ex in examples:
                ex_id = ex.get('id', '')
                
                if ex_id in rag_ids:
                    skipped_count += 1
                    continue
                
                # Add new fields if missing
                if 'approved' not in ex:
                    ex['approved'] = True
                if 'uses' not in ex:
                    ex['uses'] = 0
                if 'created_at' not in ex:
                    ex['created_at'] = '2026-03-22T00:00:00'
                if 'embedding' not in ex:
                    ex['embedding'] = []
                
                rag_examples.append(ex)
                rag_ids.add(ex_id)
                added_count += 1
                
        except Exception as e:
            print(f"    ⚠️  Error: {e}")
    
    print(f"\n{'─'*60}")
    print(f"  📊 Results:")
    print(f"    Added:   {added_count} examples")
    print(f"    Skipped: {skipped_count} (already exist)")
    print(f"    Total:   {len(rag_examples)} examples")
    print(f"{'─'*60}\n")
    
    if added_count > 0:
        # Save updated RAG
        save_json_file(RAG_FILE, rag_examples)
        print(f"  ✅ RAG updated: {RAG_FILE}")
        print(f"  💾 Backup created automatically (if backup enabled)\n")
    else:
        print(f"  ℹ️  No new examples to add\n")
    
    print("="*60 + "\n")

if __name__ == "__main__":
    main()
