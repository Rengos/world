# 🚀 Qwen Portable v3.0

Полный портативный пакет для Qwen Code CLI.  
Скиллы + Агенты + Prompt Enhancer — всё в одной папке.

---

## 📁 Структура

```
QwenPortable/
├── QWEN.md              ← главный контекст (Qwen читает первым)
├── AGENT.md             ← инструкции агента
├── settings.json        ← MCP серверы
├── start.bat            ← запуск (двойной клик)
├── install.bat          ← первый запуск на новом ПК
│
├── skills/              ← 18 навыков
│   ├── fullstack/       skill.json + SKILL.md
│   ├── code_reviewer/   skill.json + SKILL.md
│   ├── chain_of_thought/ skill.json + AGENT.md
│   ├── deep_reasoning/  skill.json + AGENT.md
│   ├── security_guardian/
│   ├── testing_expert/
│   ├── performance_optimizer/
│   ├── refactoring_specialist/
│   ├── documentation_writer/
│   ├── humanizer/
│   ├── android_team/
│   ├── apple_design_system/
│   ├── context_memory/
│   ├── failure_observer/
│   ├── execution_tracker/
│   ├── mcp_manager/
│   ├── mcp_docs_checker/
│   └── skill_orchestrator/
│
├── enhancer/            ← Prompt Enhancer (Ollama)
│   ├── prompt_enhancer.py
│   ├── start.bat
│   └── install.bat
│
└── models/              ← AI модели (переносятся с папкой)
```

---

## 🖥️ Первый запуск

1. Установи [Ollama](https://ollama.com/download/windows)
2. Установи [Python](https://python.org/downloads) — галочка **"Add Python to PATH"**
3. Установи Qwen Code CLI:
   ```
   npm install -g @qwen-code/qwen-code
   ```
4. Запусти **`install.bat`** — скачает модель (~1GB)
5. Готово!

---

## 🔄 Как использовать каждый день

### Вариант А — Prompt Enhancer (рекомендуется)
Двойной клик на **`start.bat`** → вводи короткий промпт → получай улучшенный → отправляй в Qwen

### Вариант Б — Напрямую в Qwen
```bash
cd C:\путь\к\QwenPortable
qwen
```
Qwen автоматически прочитает `QWEN.md`, `AGENT.md`, `settings.json` и все скиллы.

---

## 🎯 Скиллы и триггеры

| Слова в промпте | Скилл активируется |
|----------------|-------------------|
| next.js, react, api | `fullstack` |
| android, kotlin | `android_team` |
| ios, swift | `apple_design_system` |
| проверь код, ревью | `code_reviewer` |
| безопасность, auth | `security_guardian` |
| документация, readme | `documentation_writer` |
| пошагово, объясни | `chain_of_thought` |
| архитектура, спроектируй | `deep_reasoning` |
| оптимизируй | `performance_optimizer` |
| рефакторинг | `refactoring_specialist` |
| тест, e2e | `testing_expert` |

---

## 🔄 Перенос на другой ПК

1. Скопируй всю папку `QwenPortable` (включая `models/`)
2. Установи Ollama и Python
3. Запусти `install.bat` — модель **не скачивается** заново
4. Пользуйся `start.bat`
