@echo off
chcp 65001 > nul
title Skill Creator

set OLLAMA_MODELS=%~dp0models

:: Запускаем Ollama если не запущена
tasklist /fi "imagename eq ollama.exe" | find /i "ollama.exe" > nul 2>&1
if errorlevel 1 (
    echo ⏳ Запускаю Ollama...
    start /min "" ollama serve
    timeout /t 3 /nobreak > nul
)

python "%~dp0skills\skill_creator\skill_creator.py" %*
pause
