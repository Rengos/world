#!/bin/bash
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export OLLAMA_MODELS="$SCRIPT_DIR/models"

if ! pgrep -x "ollama" > /dev/null; then
    echo "⏳ Запускаю Ollama..."
    ollama serve &>/dev/null &
    sleep 3
fi

python3 "$SCRIPT_DIR/skills/skill_creator/skill_creator.py" "$@"
