"""
QwenPortable Setup Script v1.0
Кросс-платформенный автоустановщик (Windows + Ubuntu)
Запускается Qwen Code CLI в YOLO режиме.
"""

import os
import sys
import platform
import subprocess
import shutil
import urllib.request
import json
from pathlib import Path

# ─── Определяем платформу ────────────────────────────────────────────────────

IS_WINDOWS = platform.system() == "Windows"
IS_LINUX   = platform.system() == "Linux"
SCRIPT_DIR = Path(__file__).parent.resolve()
MODELS_DIR = SCRIPT_DIR / "models"

def run(cmd, check=True, shell=True, capture=False):
    """Запускает команду и возвращает результат."""
    print(f"  → {cmd}")
    result = subprocess.run(cmd, shell=shell, capture_output=capture, text=True)
    if check and result.returncode != 0:
        print(f"  ⚠️  Команда завершилась с кодом {result.returncode}")
    return result

def log(msg): print(f"\n{'='*55}\n  {msg}\n{'='*55}")
def ok(msg):  print(f"  ✅ {msg}")
def err(msg): print(f"  ❌ {msg}")
def info(msg):print(f"  ℹ️  {msg}")

# ─── Шаг 1: Проверка Python ──────────────────────────────────────────────────

def check_python():
    log("Шаг 1: Python")
    v = sys.version_info
    if v.major < 3 or (v.major == 3 and v.minor < 10):
        err(f"Python 3.10+ нужен. Установлен: {v.major}.{v.minor}")
        sys.exit(1)
    ok(f"Python {v.major}.{v.minor}.{v.micro}")

# ─── Шаг 2: pip зависимости ──────────────────────────────────────────────────

def install_pip_deps():
    log("Шаг 2: pip зависимости")
    deps = ["ollama"]
    for dep in deps:
        result = run(f'pip install {dep} --quiet', check=False)
        if result.returncode == 0:
            ok(dep)
        else:
            run(f'pip install {dep} --quiet --break-system-packages', check=False)
            ok(f"{dep} (с --break-system-packages)")

# ─── Шаг 3: Установка Ollama ─────────────────────────────────────────────────

def install_ollama():
    log("Шаг 3: Ollama")

    if shutil.which("ollama"):
        ok("Ollama уже установлена")
        return

    if IS_WINDOWS:
        installer_url = "https://ollama.com/download/OllamaSetup.exe"
        installer_path = SCRIPT_DIR / "OllamaSetup.exe"
        info("Скачиваю Ollama для Windows...")
        urllib.request.urlretrieve(installer_url, installer_path)
        info("Запускаю установщик (потребуется подтверждение)...")
        run(f'"{installer_path}" /S', check=False)  # Silent install
        os.remove(installer_path)
        ok("Ollama установлена")

    elif IS_LINUX:
        info("Устанавливаю Ollama для Linux...")
        run("curl -fsSL https://ollama.com/install.sh | sh")
        ok("Ollama установлена")

    else:
        err(f"Платформа {platform.system()} не поддерживается")
        sys.exit(1)

# ─── Шаг 4: Запуск Ollama сервиса ───────────────────────────────────────────

def start_ollama():
    log("Шаг 4: Запуск Ollama сервиса")

    # Проверяем запущена ли уже
    result = run("ollama list", check=False, capture=True)
    if result.returncode == 0:
        ok("Ollama уже запущена")
        return

    # Устанавливаем путь к моделям
    env = os.environ.copy()
    env["OLLAMA_MODELS"] = str(MODELS_DIR)
    MODELS_DIR.mkdir(exist_ok=True)

    if IS_WINDOWS:
        subprocess.Popen(
            ["ollama", "serve"],
            env=env,
            creationflags=subprocess.CREATE_NEW_CONSOLE
        )
    elif IS_LINUX:
        subprocess.Popen(
            ["ollama", "serve"],
            env=env,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )

    # Ждём запуска
    import time
    for i in range(10):
        time.sleep(1)
        result = run("ollama list", check=False, capture=True)
        if result.returncode == 0:
            ok("Ollama сервис запущен")
            return
        print(f"  ⏳ Ожидание... ({i+1}/10)")

    err("Ollama не запустилась за 10 секунд")

# ─── Шаг 5: Скачать модель ───────────────────────────────────────────────────

MODEL_NAME = "qwen2.5:1.5b"

def pull_model():
    log(f"Шаг 5: Модель {MODEL_NAME}")

    # Проверяем есть ли модель
    result = run("ollama list", check=False, capture=True)
    if MODEL_NAME.split(":")[0] in (result.stdout or ""):
        ok(f"Модель {MODEL_NAME} уже скачана")
        return

    # Проверяем есть ли файлы модели локально
    if MODELS_DIR.exists() and any(MODELS_DIR.iterdir()):
        ok(f"Модели найдены локально в {MODELS_DIR}")
        return

    info(f"Скачиваю {MODEL_NAME} (~1GB)...")
    env = os.environ.copy()
    env["OLLAMA_MODELS"] = str(MODELS_DIR)
    subprocess.run(f"ollama pull {MODEL_NAME}", shell=True, env=env)
    ok(f"Модель {MODEL_NAME} скачана")

# ─── Шаг 6: Проверка Qwen Code CLI ──────────────────────────────────────────

def check_qwen_cli():
    log("Шаг 6: Qwen Code CLI")

    if shutil.which("qwen"):
        ok("Qwen Code CLI найден")
        return

    info("Qwen Code CLI не найден. Устанавливаю...")
    result = run("npm install -g @qwen-code/qwen-code", check=False)
    if result.returncode == 0:
        ok("Qwen Code CLI установлен")
    else:
        err("Не удалось установить. Установи вручную:")
        info("npm install -g @qwen-code/qwen-code")

# ─── Шаг 7: Создать launcher скрипты ────────────────────────────────────────

def create_launchers():
    log("Шаг 7: Создаю launcher скрипты")

    # Windows .bat
    bat_content = f"""@echo off
chcp 65001 > nul
set OLLAMA_MODELS={MODELS_DIR}
tasklist /fi "imagename eq ollama.exe" | find /i "ollama.exe" > nul 2>&1
if errorlevel 1 (
    start /min "" ollama serve
    timeout /t 3 /nobreak > nul
)
python "{SCRIPT_DIR}\\enhancer\\prompt_enhancer.py" %*
"""
    (SCRIPT_DIR / "start.bat").write_text(bat_content, encoding="utf-8")
    ok("start.bat создан")

    # Linux/macOS .sh
    sh_content = f"""#!/bin/bash
export OLLAMA_MODELS="{MODELS_DIR}"
if ! pgrep -x "ollama" > /dev/null; then
    ollama serve &
    sleep 3
fi
python3 "{SCRIPT_DIR}/enhancer/prompt_enhancer.py" "$@"
"""
    sh_path = SCRIPT_DIR / "start.sh"
    sh_path.write_text(sh_content, encoding="utf-8")
    sh_path.chmod(0o755)
    ok("start.sh создан")

# ─── Шаг 8: Записать конфиг с путями ─────────────────────────────────────────

def write_config():
    log("Шаг 8: Конфиг")

    config = {
        "ollama_models_path": str(MODELS_DIR),
        "model": MODEL_NAME,
        "platform": platform.system(),
        "script_dir": str(SCRIPT_DIR),
        "installed": True
    }

    config_path = SCRIPT_DIR / "setup_config.json"
    with open(config_path, "w", encoding="utf-8") as f:
        json.dump(config, f, indent=2, ensure_ascii=False)
    ok(f"Конфиг сохранён: {config_path}")

# ─── Финальный отчёт ─────────────────────────────────────────────────────────

def final_report():
    print(f"""
{'='*55}
  ✅ Установка завершена!

  Платформа:  {platform.system()}
  Папка:      {SCRIPT_DIR}
  Модели:     {MODELS_DIR}
  Модель:     {MODEL_NAME}

  Как запускать:
  {'start.bat (двойной клик)' if IS_WINDOWS else 'bash start.sh'}

  Или напрямую через Qwen Code CLI:
  cd {SCRIPT_DIR}
  qwen
{'='*55}
""")

# ─── Главная функция ──────────────────────────────────────────────────────────

def main():
    print(f"""
{'='*55}
  🚀 QwenPortable Setup v1.0
  Платформа: {platform.system()} {platform.machine()}
{'='*55}
""")

    check_python()
    install_pip_deps()
    install_ollama()
    start_ollama()
    pull_model()
    check_qwen_cli()
    create_launchers()
    write_config()
    final_report()

if __name__ == "__main__":
    main()
