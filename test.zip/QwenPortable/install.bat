@echo off
chcp 65001 > nul
title Установка QwenPortable v3.4

echo ═══════════════════════════════════════════════════
echo   Установка QwenPortable v3.4
echo ═══════════════════════════════════════════════════
echo.

:: Python
where python > nul 2>&1
if errorlevel 1 (
    echo ❌ Python не найден!
    echo    Скачай: https://python.org/downloads
    echo    Галочка: "Add Python to PATH"
    pause
    exit /b 1
)
echo ✅ Python найден

:: pip зависимости
echo.
echo ⏳ Устанавливаю зависимости...
pip install groq numpy sentence-transformers --quiet
echo ✅ groq + numpy + sentence-transformers установлены

:: Node.js / npm
where npm > nul 2>&1
if errorlevel 1 (
    echo.
    echo ⚠️  Node.js не найден!
    echo    Скачай: https://nodejs.org (LTS версия)
) else (
    echo ✅ Node.js найден
)

:: Qwen Code CLI
where qwen > nul 2>&1
if errorlevel 1 (
    echo.
    echo ⏳ Устанавливаю Qwen Code CLI...
    npm install -g @qwen-code/qwen-code
) else (
    echo ✅ Qwen Code CLI найден
)

:: Проверка .env
if not exist "%~dp0enhancer\.env" (
    echo.
    echo ⚠️  Файл enhancer\.env не найден!
    echo    Создай файл enhancer\.env со строкой:
    echo    GROQ_API_KEY=твой_ключ_с_console.groq.com
) else (
    echo ✅ enhancer\.env найден
)

echo.
echo ═══════════════════════════════════════════════════
echo   ✅ Установка завершена!
echo   👉 Запускай: start.bat
echo ═══════════════════════════════════════════════════
pause
