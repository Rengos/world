@echo off
chcp 65001 > nul
title Qwen Portable — System Backup

echo ════════════════════════════════════════════════════════════
echo   💾 Создание бэкапа системы
echo ════════════════════════════════════════════════════════════
echo.

:: Проверяем Python
where python > nul 2>&1
if errorlevel 1 (
    echo ❌ Python не найден!
    echo    Скачай: https://python.org/downloads
    pause
    exit /b 1
)

:: Создаём бэкап
python "%~dp0backup_system.py"

if errorlevel 1 (
    echo.
    echo ⚠️  Ошибка создания бэкапа
    pause
) else (
    echo ✅ Бэкап готов!
    echo.
    pause
)
