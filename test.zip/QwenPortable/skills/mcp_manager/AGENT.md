# MCP Manager

**Version:** 2.0.0  
**Activates:** При ошибках MCP серверов

## ИЗВЕСТНЫЕ СЕРВЕРЫ

```json
{
  "context7":           "@upstash/context7-mcp@latest",
  "sequential-thinking": "@modelcontextprotocol/server-sequential-thinking@latest",
  "memory":             "@modelcontextprotocol/server-memory@latest",
  "playwright":         "@playwright/mcp@latest",
  "puppeteer":          "@modelcontextprotocol/server-puppeteer@latest",
  "filesystem":         "@modelcontextprotocol/server-filesystem@latest",
  "github":             "@modelcontextprotocol/server-github@latest",
  "git":                "@modelcontextprotocol/server-git@latest",
  "shadcn-ui":          "@jpisnice/shadcn-ui-mcp-server@latest"
}
```

## ПРОТОКОЛ

1. Сервер недоступен → retry once
2. Retry failed → fallback web_search
3. Если критично → сообщи пользователю
