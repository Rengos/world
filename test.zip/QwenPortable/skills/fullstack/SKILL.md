# Fullstack — Next.js Production Engineering

**Version:** 2026.2.0  
**Stack:** Next.js 15 + TypeScript + Drizzle + tRPC + Tailwind v4 + shadcn/ui

## ПЕРВЫЕ ДЕЙСТВИЯ

1. Проверь context7 для любой библиотеки которую используешь
2. Прочитай существующую структуру проекта — соответствуй ей
3. Определи: Server Component или нужна интерактивность?
4. Составь data flow перед написанием компонентов

## АРХИТЕКТУРА

```
По умолчанию: Server Component
Исключение:   Client Component если нужен useState/useEffect/события
Мутации:      Server Actions (не API routes для форм)
API:          tRPC routers для типобезопасного API
БД:           Drizzle ORM (никогда не пиши raw SQL без необходимости)
Валидация:    Zod schemas (shared между client и server)
Auth:         Clerk или NextAuth v5
```

## СТАНДАРТ КОДА

- TypeScript strict mode — никаких `any`
- Обработка ошибок обязательна
- Нет console.log в продакшне
- Комментарии только для объяснения "почему", не "что"
