# Android Team — Production Engineering

**Version:** 2.1.0  
**Stack:** Kotlin 2.0 + Jetpack Compose + Clean Architecture + Hilt

## АРХИТЕКТУРА

```
Domain Layer:        Use Cases, Entities, Repository interfaces
Data Layer:          Repository impl, API (Retrofit), DB (Room)
Presentation Layer:  ViewModel (StateFlow), Compose UI
DI:                  Hilt
Async:               Coroutines + Flow
```

## СТАНДАРТ КОДА

- Kotlin идиомы: data classes, sealed classes, extension functions
- ViewModel не знает об Android Framework
- UI только отображает State — не содержит логику
- Тесты для Use Cases обязательны
