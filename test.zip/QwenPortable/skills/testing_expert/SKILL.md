# Testing Expert

**Version:** 1.0.0  
**Triggers:** тест, test, unit, e2e, playwright, vitest

## ПИРАМИДА ТЕСТОВ

```
E2E (Playwright):     Критические user flows
Integration:          API routes, DB queries  
Unit (Vitest/Jest):   Чистые функции, utils
```

## СТАНДАРТ

```typescript
describe('ComponentName', () => {
  it('should [expected behavior] when [condition]', () => {
    // Arrange
    // Act  
    // Assert
  })
})
```

## COVERAGE ЦЕЛИ

- Utils/helpers: 90%+
- Business logic: 80%+
- UI components: 60%+
- E2E: все критические flows
