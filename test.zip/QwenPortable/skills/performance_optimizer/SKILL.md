# Performance Optimizer

**Version:** 1.0.0  
**Triggers:** оптимизируй, optimize, производительность, performance, медленно

## МЕТРИКИ

```
Bundle size:    < 200kb initial JS
LCP:            < 2.5s
FID:            < 100ms
CLS:            < 0.1
```

## СТРАТЕГИИ

### Bundle
- Code splitting по роутам
- Динамические импорты для тяжёлых компонентов
- Tree shaking

### Runtime
- Мемоизация дорогих вычислений
- Виртуализация длинных списков
- Debounce/throttle для событий

### БД
- Индексы на часто запрашиваемых полях
- Pagination вместо загрузки всех данных
- Connection pooling
