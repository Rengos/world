# Skill Orchestrator

**Version:** 1.0.0  
**Activates:** Задачи требующие нескольких навыков

## ПРОЦЕСС

1. Определи какие скиллы нужны для задачи
2. Определи порядок: параллельно или последовательно
3. Запусти скиллы
4. Синтезируй результаты

## ПРИМЕР

Задача: "Создай authenticated fullstack app с тестами"
```
Параллельно: fullstack + security_guardian
Затем:       testing_expert
Затем:       documentation_writer
```
