# Documentation Writer

**Version:** 1.0.0  
**Triggers:** документация, readme, docs, changelog, гайд

## README СТРУКТУРА

```markdown
# Project Name
Одно предложение что это делает.

## Quick Start
Минимум шагов для запуска.

## Features
Список ключевых возможностей.

## Installation
Точные команды.

## Configuration
Переменные окружения.

## API Reference
Если применимо.
```

## ПРИНЦИПЫ

- Пиши для нового разработчика который ничего не знает
- Конкретные команды, не абстрактные описания
- Обновляй при каждом изменении API
