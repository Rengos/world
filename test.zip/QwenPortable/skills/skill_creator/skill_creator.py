"""
Skill Creator v1.0 — Qwen Code + Ollama
Адаптация FrancyJGLisboa/agent-skill-creator

Принимает описание воркфлоу → генерирует skill.json + SKILL.md
→ устанавливает в skills/ папку автоматически.
"""

import ollama
import json
import sys
import os
import re
from pathlib import Path

# ─── Пути ────────────────────────────────────────────────────────────────────

SCRIPT_DIR  = Path(__file__).parent.parent.resolve()  # QwenPortable/
SKILLS_DIR  = SCRIPT_DIR / "skills"
MODEL       = "qwen2.5:1.5b"

# ─── Системный промпт для Ollama ─────────────────────────────────────────────

SYSTEM_PROMPT = """You are an expert AI skill architect for Qwen Code CLI.

Your job: take any workflow description and produce a complete skill definition.

OUTPUT FORMAT — respond with ONLY valid JSON, no markdown, no explanation:
{
  "name": "skill-name-kebab",
  "name_underscore": "skill_name_underscore",
  "folder": "skill-name-kebab",
  "type": "skill",
  "description": "One sentence describing what triggers this skill and what it does.",
  "triggers_ru": ["русский триггер1", "русский триггер2"],
  "triggers_en": ["english trigger1", "english trigger2"],
  "autoActivate": false,
  "integrations": [],
  "skill_md": "# Skill Title\\n\\n**Version:** 1.0.0\\n\\n## РОЛЬ\\n[role]\\n\\n## КОГДА АКТИВИРОВАТЬСЯ\\n[when]\\n\\n## ПРОЦЕСС\\n[steps]\\n\\n## ФОРМАТ ВЫВОДА\\n[output format]"
}

Rules:
- name: lowercase, hyphens only, 1-64 chars
- name_underscore: same but with underscores (for skill.json "name" field)
- type: skill | agent | cognitive-agent | monitoring-agent
- description: must contain keywords for auto-detection
- triggers: minimum 3 in Russian + 3 in English
- skill_md: complete SKILL.md content with real instructions, not placeholders
- integrations: only from [context7, memory, sequential-thinking, playwright, puppeteer]
- autoActivate: true only for background/monitoring skills
- Keep skill_md instructions concrete and actionable
- Respond ONLY with JSON — no preamble, no explanation"""

# ─── Валидация ────────────────────────────────────────────────────────────────

def validate_skill(data: dict) -> list[str]:
    errors = []
    name = data.get("name", "")
    if not re.match(r'^[a-z][a-z0-9-]{0,63}$', name):
        errors.append(f"name '{name}' должен быть lowercase kebab-case, 1-64 символа")
    if len(data.get("description", "")) < 20:
        errors.append("description слишком короткий (минимум 20 символов)")
    triggers = data.get("triggers_ru", []) + data.get("triggers_en", [])
    if len(triggers) < 3:
        errors.append("нужно минимум 3 триггера")
    if not data.get("skill_md", "").strip():
        errors.append("skill_md не может быть пустым")
    bad_keys = ["api_key", "password", "secret", "token=", "passwd"]
    skill_md = data.get("skill_md", "").lower()
    for key in bad_keys:
        if key in skill_md:
            errors.append(f"Обнаружен потенциально опасный паттерн: '{key}'")
    return errors

# ─── Генерация через Ollama ───────────────────────────────────────────────────

def generate_skill(description: str) -> dict:
    print("⏳ Анализирую воркфлоу...\n")
    response = ollama.chat(
        model=MODEL,
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": f"Create a skill for this workflow:\n\n{description}"}
        ],
        options={"temperature": 0.2}
    )
    raw = response["message"]["content"].strip()

    # Убираем markdown если модель всё же добавила
    raw = re.sub(r'^```json\s*', '', raw)
    raw = re.sub(r'\s*```$', '', raw)
    raw = raw.strip()

    try:
        return json.loads(raw)
    except json.JSONDecodeError as e:
        # Пробуем найти JSON в тексте
        match = re.search(r'\{.*\}', raw, re.DOTALL)
        if match:
            return json.loads(match.group())
        raise ValueError(f"Модель вернула невалидный JSON: {e}\n\nОтвет: {raw[:300]}")

# ─── Установка скилла ─────────────────────────────────────────────────────────

def install_skill(data: dict) -> Path:
    folder = SKILLS_DIR / data["folder"]
    folder.mkdir(parents=True, exist_ok=True)

    # skill.json
    skill_json = {
        "name": data["name_underscore"],
        "version": "1.0.0",
        "description": data["description"],
        "type": data.get("type", "skill"),
        "autoActivate": data.get("autoActivate", False),
        "triggers": data.get("triggers_ru", []) + data.get("triggers_en", []),
        "integrations": data.get("integrations", []),
        "entry": "SKILL.md"
    }
    with open(folder / "skill.json", "w", encoding="utf-8") as f:
        json.dump(skill_json, f, ensure_ascii=False, indent=2)

    # SKILL.md
    with open(folder / "SKILL.md", "w", encoding="utf-8") as f:
        f.write(data["skill_md"])

    return folder

# ─── Показать превью ──────────────────────────────────────────────────────────

def show_preview(data: dict):
    print("─" * 55)
    print(f"  📦 Скилл: {data['name']}")
    print(f"  📁 Папка: skills/{data['folder']}/")
    print(f"  🔧 Тип:   {data.get('type', 'skill')}")
    print(f"  📝 Описание: {data['description'][:80]}...")
    triggers = data.get("triggers_ru", [])[:3] + data.get("triggers_en", [])[:2]
    print(f"  🎯 Триггеры: {', '.join(triggers)}")
    print("─" * 55)
    print()
    print("  SKILL.md превью:")
    print("  " + "\n  ".join(data["skill_md"].split("\n")[:15]))
    print("─" * 55)

# ─── Главная функция ──────────────────────────────────────────────────────────

def main():
    # --auto флаг: главный агент вызывает без интерактивности
    auto_mode = "--auto" in sys.argv
    args = [a for a in sys.argv[1:] if a != "--auto"]

    if not auto_mode:
        print("=" * 55)
        print("  🛠️  Skill Creator v1.0")
        print("  Создаёт скиллы для Qwen Code CLI через Ollama")
        print("=" * 55)

    # Получаем описание
    if args:
        description = " ".join(args).strip()
        if not auto_mode:
            print(f"\n📋 Воркфлоу: {description}\n")
    elif auto_mode:
        print("❌ --auto требует описание: skill_creator.py --auto 'описание'")
        sys.exit(1)
    else:
        print("\nОпиши воркфлоу который хочешь превратить в скилл.")
        print("Можно на русском или английском. Чем подробнее — тем лучше.\n")
        description = input("📋 Описание: ").strip()

    if not description:
        print("❌ Описание пустое!")
        sys.exit(1)

    # Проверяем — нет ли уже похожего скилла
    if SKILLS_DIR.exists():
        existing = [d.name for d in SKILLS_DIR.iterdir() if d.is_dir()]
        desc_words = set(description.lower().split())
        for existing_name in existing:
            name_words = set(existing_name.replace("_", " ").replace("-", " ").split())
            if len(desc_words & name_words) >= 2:
                print(f"⚠️  Похожий скилл уже существует: {existing_name}")
                if auto_mode:
                    sys.exit(0)
                confirm = input("Всё равно создать? (y/n): ").strip()
                if confirm.lower() != "y":
                    return

    # Генерируем
    try:
        if not auto_mode:
            print("⏳ Генерирую скилл через Ollama...\n")
        data = generate_skill(description)
    except Exception as e:
        print(f"❌ Ошибка генерации: {e}")
        print("💡 Убедись что Ollama запущена: ollama serve")
        sys.exit(1)

    # Валидируем
    errors = validate_skill(data)
    if errors:
        print("⚠️  Предупреждения:")
        for err in errors:
            print(f"  - {err}")

    # Авторежим — устанавливаем без вопросов
    if auto_mode:
        folder = install_skill(data)
        triggers = data.get("triggers_ru", [])[:2]
        print(f"✅ Скилл создан автоматически: {data['name']}")
        print(f"   📁 {folder}")
        print(f"   🎯 Триггеры: {', '.join(triggers)}")
        return

    # Интерактивный режим
    show_preview(data)

    print("\nЧто делаем?")
    print("  1 — Установить скилл")
    print("  2 — Сгенерировать снова")
    print("  0 — Отмена")
    choice = input("\nВыбор: ").strip()

    if choice == "1":
        folder = install_skill(data)
        triggers_sample = data.get("triggers_ru", ["..."])[:2]
        print(f"""
✅ Скилл установлен!

  📁 {folder}
  ├── skill.json
  └── SKILL.md

  Активация в Qwen:
  {triggers_sample[0] if triggers_sample else data['name']}
""")
    elif choice == "2":
        main()
    else:
        print("Отмена.")

if __name__ == "__main__":
    main()
