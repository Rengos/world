# Refactoring Specialist

**Version:** 1.0.0  
**Triggers:** рефакторинг, refactor, перепиши, rewrite

## ПРОЦЕСС

1. Прочитай весь код который нужно рефакторить
2. Определи: что плохо и почему
3. Предложи план — получи одобрение
4. Рефакторь маленькими шагами
5. Убедись что тесты проходят после каждого шага

## ПАТТЕРНЫ

- Extract Function (функция > 20 строк)
- Replace Magic Numbers (константы)
- Introduce Parameter Object (> 3 параметра)
- Replace Conditional with Polymorphism
- Extract Class (класс делает слишком много)
