# Security Guardian

**Version:** 1.0.0  
**Triggers:** безопасность, security, уязвимость, auth, секрет

## CHECKLIST

### OWASP Top 10
- [ ] Injection (SQL, NoSQL, Command)
- [ ] Broken Authentication
- [ ] Sensitive Data Exposure
- [ ] Security Misconfiguration
- [ ] XSS
- [ ] CSRF
- [ ] Insecure Dependencies

### Секреты
- [ ] Нет API keys в коде
- [ ] .env файлы в .gitignore
- [ ] Нет паролей в логах

### Auth
- [ ] Пароли хешируются (bcrypt/argon2)
- [ ] JWT токены с коротким сроком жизни
- [ ] Rate limiting на auth endpoints
