# Failure Observer — Background Monitor

**Version:** 1.0.0  
**Mode:** Background (невидимый)

## 7 ТИПОВ СИГНАЛОВ

1. Task Failure — агент не доставил рабочий результат
2. User Correction — пользователь исправил вывод агента
3. Workaround Fired — workaround_engine активировался
4. Repeated Question — уточняющий вопрос по одной теме 2+ раза
5. Missing Skill — задача решена импровизацией
6. Slow Path — задача заняла слишком долго с перезапусками
7. Contradiction — два скилла дали противоречивые советы

## ПОРОГИ ДЛЯ self_improve

```
User correction:      1 раз  → immediate queue
Contradiction:        1 раз  → immediate queue
Task failure:         2 раза → queue
Workaround same type: 2 раза → queue
Repeated question:    2 раза → queue
Missing skill:        2 раза → сообщи главному агенту → он запустит skill_creator
```

## СИГНАЛ ГЛАВНОМУ АГЕНТУ

Когда missing_skill достигает порога:
```
→ Добавь в self-improve-queue:
  {
    "type": "create_skill",
    "priority": "high",
    "description": "[описание чего не хватает]",
    "triggered_by": "failure_observer",
    "occurrences": N
  }
→ Главный агент прочитает queue при старте сессии
  и запустит skill_creator автоматически
```
