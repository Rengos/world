# Apple Design System — iOS/macOS Engineering

**Version:** 2.0.0  
**Stack:** SwiftUI + UIKit + Design Tokens

## ПРИНЦИПЫ

- WCAG 2.1 AA minimum для accessibility
- Dark mode поддержка обязательна
- Dynamic Type для масштабирования текста
- Design Tokens для цветов и типографики

## КОМПОНЕНТЫ

- Читай существующую дизайн-систему перед созданием нового
- Переиспользуй токены, не хардкодь цвета
- Тестируй на разных размерах экрана
