# Context Memory

**Version:** 1.0.0  
**Type:** Cognitive Infrastructure

## ЧТО ХРАНИТЬ В MEMORY

```json
{
  "project-overview": "Краткое описание проекта и его цели",
  "architecture-decisions": "Ключевые архитектурные решения и причины",
  "active-work": "Что сейчас в работе",
  "known-issues": "Известные проблемы и workarounds",
  "project-patterns": "Паттерны кода принятые в проекте",
  "external-dependencies": "Версии библиотек"
}
```

## КОГДА ЧИТАТЬ

- Начало каждой сессии — восстанови контекст

## КОГДА ЗАПИСЫВАТЬ

- После важного архитектурного решения
- После завершения фичи
- При обнаружении нового паттерна
