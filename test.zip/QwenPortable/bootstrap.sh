#!/bin/bash
# QwenPortable Bootstrap v1.0 — Linux/Ubuntu
# Не требует Python заранее — установит сам
# Запуск: bash bootstrap.sh

set -e
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MODELS_DIR="$SCRIPT_DIR/models"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

log()  { echo -e "\n${CYAN}== $1 ==${NC}"; }
ok()   { echo -e "  ${GREEN}✅ $1${NC}"; }
err()  { echo -e "  ${RED}❌ $1${NC}"; }
info() { echo -e "  ${YELLOW}... $1${NC}"; }

echo -e "${CYAN}
==============================================
  QwenPortable Bootstrap — Linux/Ubuntu
==============================================${NC}"

# ─── Шаг 1: Python ────────────────────────────────────────────────────────────

log "Шаг 1: Python"

PYTHON_CMD=""
for cmd in python3 python; do
    if command -v "$cmd" &>/dev/null; then
        VER=$("$cmd" --version 2>&1 | grep -oP '3\.\K\d+')
        if [ -n "$VER" ] && [ "$VER" -ge 10 ]; then
            PYTHON_CMD="$cmd"
            ok "Найден: $($cmd --version)"
            break
        fi
    fi
done

if [ -z "$PYTHON_CMD" ]; then
    info "Python 3.10+ не найден. Устанавливаю..."
    
    # Определяем пакетный менеджер
    if command -v apt-get &>/dev/null; then
        sudo apt-get update -qq
        sudo apt-get install -y python3 python3-pip
    elif command -v dnf &>/dev/null; then
        sudo dnf install -y python3 python3-pip
    elif command -v pacman &>/dev/null; then
        sudo pacman -S --noconfirm python python-pip
    else
        err "Не удалось определить пакетный менеджер. Установи Python вручную."
        exit 1
    fi
    
    PYTHON_CMD="python3"
    ok "Python установлен"
fi

# ─── Шаг 2: pip ───────────────────────────────────────────────────────────────

log "Шаг 2: pip"

if ! $PYTHON_CMD -m pip --version &>/dev/null; then
    info "pip не найден. Устанавливаю..."
    if command -v apt-get &>/dev/null; then
        sudo apt-get install -y python3-pip -qq
    else
        curl -fsSL https://bootstrap.pypa.io/get-pip.py | $PYTHON_CMD
    fi
fi

# Устанавливаем ollama пакет
$PYTHON_CMD -m pip install ollama anthropic --quiet 2>/dev/null || \
$PYTHON_CMD -m pip install ollama anthropic --quiet --break-system-packages 2>/dev/null
ok "ollama + anthropic (pip) установлены"

# ─── Шаг 3: Ollama ────────────────────────────────────────────────────────────

log "Шаг 3: Ollama"

if command -v ollama &>/dev/null; then
    ok "Ollama уже установлена"
else
    info "Устанавливаю Ollama..."
    curl -fsSL https://ollama.com/install.sh | sh
    ok "Ollama установлена"
fi

# ─── Шаг 4: Запуск Ollama ─────────────────────────────────────────────────────

log "Шаг 4: Запуск Ollama"

mkdir -p "$MODELS_DIR"
export OLLAMA_MODELS="$MODELS_DIR"

if pgrep -x "ollama" > /dev/null; then
    ok "Ollama уже запущена"
else
    info "Запускаю Ollama в фоне..."
    OLLAMA_MODELS="$MODELS_DIR" ollama serve &>/dev/null &
    sleep 4
    ok "Ollama запущена (PID: $!)"
fi

# ─── Шаг 5: Модель ────────────────────────────────────────────────────────────

log "Шаг 5: Модель qwen2.5:1.5b"

if ollama list 2>/dev/null | grep -q "qwen2.5"; then
    ok "Модель уже скачана"
elif [ -d "$MODELS_DIR" ] && [ "$(ls -A $MODELS_DIR 2>/dev/null)" ]; then
    ok "Модели найдены локально в $MODELS_DIR"
else
    info "Скачиваю qwen2.5:1.5b (~1GB)..."
    OLLAMA_MODELS="$MODELS_DIR" ollama pull qwen2.5:1.5b
    ok "Модель скачана"
fi

# ─── Шаг 6: Node.js + Qwen Code CLI ──────────────────────────────────────────

log "Шаг 6: Node.js + Qwen Code CLI"

if ! command -v node &>/dev/null; then
    info "Node.js не найден. Устанавливаю..."
    if command -v apt-get &>/dev/null; then
        curl -fsSL https://deb.nodesource.com/setup_lts.x | sudo -E bash -
        sudo apt-get install -y nodejs -qq
    elif command -v dnf &>/dev/null; then
        sudo dnf install -y nodejs
    fi
    ok "Node.js установлен"
fi

if command -v qwen &>/dev/null; then
    ok "Qwen Code CLI уже установлен"
else
    info "Устанавливаю Qwen Code CLI..."
    npm install -g @qwen-code/qwen-code 2>/dev/null
    ok "Qwen Code CLI установлен"
fi

# ─── Шаг 7: start.sh ──────────────────────────────────────────────────────────

log "Шаг 7: Создаю start.sh"

cat > "$SCRIPT_DIR/start.sh" << EOF
#!/bin/bash
export OLLAMA_MODELS="$MODELS_DIR"
if ! pgrep -x "ollama" > /dev/null; then
    ollama serve &>/dev/null &
    sleep 3
fi
$PYTHON_CMD "$SCRIPT_DIR/enhancer/prompt_enhancer.py" "\$@"
EOF

chmod +x "$SCRIPT_DIR/start.sh"
ok "start.sh создан"

# ─── Готово ───────────────────────────────────────────────────────────────────

echo -e "${GREEN}
==============================================
  ✅ ГОТОВО!

  Папка:    $SCRIPT_DIR
  Модели:   $MODELS_DIR
  Python:   $PYTHON_CMD

  Запуск:   bash start.sh

  Или Qwen Code CLI напрямую:
  cd $SCRIPT_DIR && qwen
==============================================${NC}"
