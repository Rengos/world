# 🎯 Skill: phantom_browser_expert

**Версия:** 1.0.0  
**Дата:** 22 марта 2026 г.  
**Тип:** Domain Expert  
**Статус:** ✅ Готов к использованию

---

## 📋 ОПИСАНИЕ

Скилл для разработки, тестирования и интеграции **PhantomBrowser v3.0** — антидетект браузера с реальной эмуляцией окружения.

---

## 🎯 ТРИГГЕРЫ

### Активация скилла:
```
Триггеры:
- "PhantomBrowser"
- "антидетект браузер"
- "anti-detect browser"
- "эмуляция fingerprint"
- "fingerprint spoofing"
- "Canvas fingerprint"
- "WebGL fingerprint"
- "WebRTC защита"
- "эмуляция устройства"
- "эмуляция провайдера"
- "создай профиль"
- "Detection тесты"
- "CreepJS тест"
- "PixelScan тест"
- "Cloudflare Turnstile"
- "Akamai Bot Manager"
- "DataDome тест"
```

---

## 🧠 ЭКСПЕРТИЗА

### Область знаний:
1. **Electron 30+** — разработка десктопных приложений
2. **TypeScript 5.x** — строгая типизация
3. **React 18** — UI компоненты
4. **Vite 5.x** — сборка проекта
5. **Chromium 131+** — браузерное ядро
6. **Fingerprinting** — техники эмуляции:
   - Canvas fingerprint
   - WebGL fingerprint
   - Audio context fingerprint
   - Font enumeration
   - Timezone/locale spoofing
   - Connection API emulation
   - WebRTC protection
7. **Тестирование:**
   - Detection тесты (CreepJS, PixelScan, BrowserLeaks)
   - E2E тесты (Playwright)
   - Unit тесты (Vitest)
8. **Антидетект сервисы:**
   - CreepJS
   - PixelScan
   - BrowserLeaks
   - Cloudflare Turnstile
   - Akamai Bot Manager
   - DataDome

---

## 🛠️ ВОЗМОЖНОСТИ

### Что умеет скилл:

#### 1. Разработка ядра эмуляции
```
- applyDevice() — эмуляция 6 устройств
- applyConnection() — эмуляция 9 провайдеров
- seeded RNG — детерминированная генерация
- IP generator — генерация IP для провайдеров
- WebGL spoofing — подмена GPU
- Canvas noise — детерминированный шум
- Audio fingerprint — эмуляция audio context
```

#### 2. IPC коммуникация
```
- emulation:getConfig — получение конфигурации
- emulation:apply — применение эмуляции
- emulation:getSeed — получение seed
- emulation:generateIP — генерация IP
- emulation:test — тестирование эмуляции
- Валидация и авторизация IPC запросов
```

#### 3. React компоненты
```
- EnvironmentSelector — выбор устройства/провайдера
- DeviceCard — карточка устройства
- ProviderSelector — выбор провайдера
- SeedGenerator — генерация seed (3 режима)
- ConfigSummary — сводка с Risk Score
```

#### 4. Тестирование
```
Detection тесты:
- test-creepjs.ts (4 теста)
- test-pixelscan.ts (5 тестов)
- test-browserleaks.ts (6 тестов)
- test-cloudflare.ts (5 тестов)
- test-akamai.ts (6 тестов)
- test-datadome.ts (6 тестов)

E2E тесты:
- profile-management.spec.ts (15 тестов)
- environment-emulation.spec.ts (24 теста)
- fingerprint-injection.spec.ts (18 тестов)
- webrtc-protection.spec.ts (16 тестов)
- connection-api.spec.ts (35 тестов)

Unit тесты:
- environment-emulator.test.ts (40+ тестов)
- emulation-manager.test.ts (30+ тестов)
- fingerprint-generator.test.ts (35+ тестов)
- seed-random.test.ts (50+ тестов)
- ip-generator.test.ts (45+ тестов)
```

#### 5. Безопасность
```
- Прототипная изоляция (Proxy вместо модификации прототипов)
- IPC валидация и авторизация
- XSS санитизация (userAgent)
- Retry логика с timeout
- Инкапсуляция через Module Pattern
- Логирование с уровнями
```

---

## 📊 БАЗА УСТРОЙСТВ

### 6 устройств:
| Устройство | CPU | GPU | RAM | Screen |
|------------|-----|-----|-----|--------|
| 🎮 Gaming | i9-13900K (24c) | RTX 4090 (24GB) | 64GB | 2560x1440 @ 144Hz |
| 🐌 Weak | i3-8100 (4c) | UHD 630 | 8GB | 1366x768 @ 60Hz |
| 📱 iPhone 14 Pro | A16 Bionic (6c) | Apple GPU | 6GB | 1179x2556 @ 60Hz |
| 📱 Samsung S23 | SD 8 Gen 2 (8c) | Adreno 740 | 12GB | 1440x3088 @ 120Hz |
| 💼 Office | i5-10400 (12c) | UHD 630 | 16GB | 1920x1080 @ 60Hz |
| 💻 MacBook M2 | M2 (10c) | M2 GPU | 16GB | 3024x1964 @ 60Hz |

---

## 📡 БАЗА ПРОВАЙДЕРОВ

### Mobile (3):
| Провайдер | Type | ASN | RTT | Downlink |
|-----------|------|-----|-----|----------|
| 📶 T-Mobile | 5G/4G | AS21928 | 45ms | 50 Mbps |
| 📶 Verizon | 5G/4G | AS6167 | 35ms | 100 Mbps |
| 📶 AT&T | 5G/4G | AS20057 | 40ms | 80 Mbps |

### WiFi (6):
| Провайдер | Type | ASN | RTT | Downlink |
|-----------|------|-----|-----|----------|
| 🔌 Comcast | Cable | AS7922 | 20ms | 300 Mbps |
| 🔌 Spectrum | Cable | AS11351 | 18ms | 400 Mbps |
| ✨ Verizon Fios | Fiber | AS701 | 10ms | 940 Mbps |
| ✨ AT&T Fiber | Fiber | AS20115 | 12ms | 1000 Mbps |
| 🛰️ Starlink | Satellite | AS14618 | 80ms | 150 Mbps |

---

## 🎯 СЦЕНАРИИ ИСПОЛЬЗОВАНИЯ

### Сценарий 1: Создание профиля
```
Пользователь: "создай профиль для Facebook"

Действия:
1. Выбрать устройство (iPhone 14 Pro для мобильного трафика)
2. Выбрать провайдера (T-Mobile 5G)
3. Сгенерировать seed (детерминированный fingerprint)
4. Применить эмуляцию
5. Сохранить конфигурацию
```

### Сценарий 2: Тестирование на детектирование
```
Пользователь: "протестируй на CreepJS"

Действия:
1. Запустить test-creepjs.ts
2. Посетить https://abrahamjuliot.github.io/creepjs/
3. Собрать метрики (botScore, consistencyScore)
4. Сохранить отчёт в reports/detection/
5. Верифицировать botScore < 20%
```

### Сценарий 3: Исправление безопасности
```
Пользователь: "исправь уязвимость XSS"

Действия:
1. Найти источник уязвимости (userAgent)
2. Добавить санитизацию в utils/security.ts
3. Применить safeDefineProperty
4. Протестировать исправление
5. Обновить SECURITY_FIXES.md
```

---

## 🔧 КОМАНДЫ

### Запуск тестов:
```bash
# Все тесты
npm test

# Detection тесты
npm run test:detection
npm run test:detection:creepjs
npm run test:detection:pixelscan
npm run test:detection:cloudflare

# E2E тесты
npm run test:e2e
npm run test:e2e:profile-management
npm run test:e2e:environment-emulation

# Unit тесты
npm run test:unit
npm run test:unit:coverage

# С отчётом
npm run test:e2e -- --reporter=html
npm run test:unit:coverage -- --reporter=html
```

### Сборка:
```bash
# Полная сборка
npm run build

# Только main процесс
npm run build:main

# Только renderer
npm run build:renderer

# Development режим
npm run dev
```

### Линтинг:
```bash
# Проверка
npm run lint

# Авто-исправление
npm run lint:fix

# Проверка типов
npm run typecheck
```

---

## 📁 СТРУКТУРА ПРОЕКТА

```
antidetect2/
├── src/
│   ├── main/
│   │   ├── configs/
│   │   │   ├── device-configs.ts
│   │   │   └── index.ts
│   │   ├── utils/
│   │   │   ├── logger.ts
│   │   │   ├── security.ts
│   │   │   └── index.ts
│   │   ├── environment-emulator.ts
│   │   └── emulation-manager.ts
│   ├── preload/
│   │   └── emulation-preload.ts
│   └── renderer/
│       ├── types/emulation.ts
│       ├── configs/
│       ├── components/
│       ├── hooks/
│       ├── App.tsx
│       └── index.ts
├── tests/
│   ├── detection/
│   ├── e2e/
│   └── unit/
├── reports/
│   ├── detection/
│   └── test/
├── docs/
├── package.json
├── tsconfig.json
├── vite.config.ts
├── playwright.config.ts
└── .env.example
```

---

## 🎯 МЕТРИКИ КАЧЕСТВА

### Целевые показатели:
```
✅ Code Quality: > 85/100
✅ Безопасность: > 8/10
✅ Test Coverage: > 90%
✅ Detection Pass Rate: > 95%
✅ Risk Score: < 10%
✅ False Positive: < 5%
✅ False Negative: < 1%
```

---

## 📚 ДОКУМЕНТАЦИЯ

### Основные файлы:
- `README.md` — главная документация
- `FINAL_REPORT.md` — финальный отчёт разработки
- `SECURITY_FIXES.md` — исправления безопасности
- `CHANGELOG.md` — история изменений
- `DEVELOPMENT_REPORT.md` — отчёт о разработке

### Тесты:
- `tests/detection/README.md` — Detection тесты
- `tests/e2e/README.md` — E2E тесты
- `tests/unit/README.md` — Unit тесты

### Отчёты:
- `reports/detection/summary.md` — сводка detection
- `reports/test/test-report-template.md` — шаблон тестирования
- `reports/test/coverage-report-template.md` — шаблон coverage

---

## 🚀 БЫСТРЫЙ СТАРТ

### 1. Установка зависимостей:
```bash
npm install
```

### 2. Запуск тестов:
```bash
npm test
```

### 3. Сборка:
```bash
npm run build
```

### 4. Интеграция:
```bash
# Скопировать в основной проект
cp -r src/main/* ../antidetect/src/main/
cp -r src/preload/* ../antidetect/src/preload/
cp -r src/renderer/* ../antidetect/src/renderer/
```

---

## 💡 СОВЕТЫ

### Для лучших результатов:
1. **Всегда запускай тесты** перед интеграцией
2. **Проверяй Risk Score** после изменений конфигурации
3. **Используй детерминированный seed** для воспроизводимости
4. **Валидируй IPC запросы** для безопасности
5. **Логируй ошибки** через logger.ts вместо console.log

---

## ⚠️ ИЗВЕСТНЫЕ ОГРАНИЧЕНИЯ

1. **Сборка Chromium** требует 12-24 часа
2. **WebRTC защита** требует патчей на уровне браузера
3. **Canvas fingerprint** может детектироваться на PixelScan
4. **TLS fingerprint** требует дополнительных патчей

---

## 🔗 ССЫЛКИ

### Тесты:
- [CreepJS](https://abrahamjuliot.github.io/creepjs/)
- [PixelScan](https://pixelscan.net/)
- [BrowserLeaks](https://browserleaks.com/)
- [Cloudflare Turnstile](https://www.cloudflare.com/products/turnstile/)

### Документация:
- [Electron](https://www.electronjs.org/docs)
- [Playwright](https://playwright.dev/)
- [Vitest](https://vitest.dev/)
- [Rebrowser Patches](https://github.com/rebrowser/rebrowser-patches)

---

**Скилл готов к использованию!** ✅

**Версия:** 1.0.0  
**Дата:** 22 марта 2026 г.
