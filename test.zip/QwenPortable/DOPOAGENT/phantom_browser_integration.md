# 🎯 Skill: phantom_browser_integration

**Версия:** 1.0.0  
**Дата:** 22 марта 2026 г.  
**Тип:** Integration Expert  
**Статус:** ✅ Готов к использованию

---

## 📋 ОПИСАНИЕ

Скилл для **интеграции PhantomBrowser v3.0** в основной проект antidetect.

---

## 🎯 ТРИГГЕРЫ

```
Триггеры активации:
- "интегрируй PhantomBrowser"
- "скопируй файлы в antidetect"
- "подключи эмуляцию"
- "настрой IPC handlers"
- "интегрируй React компоненты"
- "объедини проекты"
```

---

## 🛠️ ПРОТОКОЛ ИНТЕГРАЦИИ

### Шаг 1: Подготовка
```bash
# Проверка основного проекта
cd C:\.qwen\antidetect
ls -la

# Резервное копирование
npm run backup || python backup_system.py
```

### Шаг 2: Копирование файлов
```bash
# Main процесс
cp -r C:\Users\Alex\Desktop\Project\antidetect2\src\main\configs\ C:\.qwen\antidetect\src\main\
cp -r C:\Users\Alex\Desktop\Project\antidetect2\src\main\utils\ C:\.qwen\antidetect\src\main\
cp C:\Users\Alex\Desktop\Project\antidetect2\src\main\environment-emulator.ts C:\.qwen\antidetect\src\main\
cp C:\Users\Alex\Desktop\Project\antidetect2\src\main\emulation-manager.ts C:\.qwen\antidetect\src\main\

# Preload
cp C:\Users\Alex\Desktop\Project\antidetect2\src\preload\emulation-preload.ts C:\.qwen\antidetect\src\preload\

# Renderer
cp -r C:\Users\Alex\Desktop\Project\antidetect2\src\renderer\ C:\.qwen\antidetect\src\
```

### Шаг 3: Обновление зависимостей
```bash
cd C:\.qwen\antidetect

# Обновление package.json
npm install electron@30 typescript@5 react@18 vite@5 @playwright/test@1.42 vitest@1.3
```

### Шаг 4: Обновление конфигурации
```bash
# Обновление vite.config.ts
# Обновление tsconfig.json
# Обновление playwright.config.ts
```

### Шаг 5: Тестирование
```bash
# Запуск тестов
npm run test:unit
npm run test:e2e
npm run test:detection

# Проверка IPC
npm run test:ipc
```

---

## ✅ ЧЕК-ЛИСТ ИНТЕГРАЦИИ

```
□ 1. Резервная копия создана
□ 2. Файлы main скопированы
□ 3. Файлы preload скопированы
□ 4. Файлы renderer скопированы
□ 5. Зависимости обновлены
□ 6. Конфигурация обновлена
□ 7. IPC handlers работают
□ 8. Тесты проходят
□ 9. Сборка успешна
□ 10. Документация обновлена
```

---

## 🔧 КОМАНДЫ

```bash
# Полная интеграция
python skills/phantom_browser_integration/integrate.py

# Только копирование
python skills/phantom_browser_integration/copy_files.py

# Только тесты
python skills/phantom_browser_integration/run_tests.py

# Проверка статуса
python skills/phantom_browser_integration/status.py
```

---

## ⚠️ ИЗВЕСТНЫЕ ПРОБЛЕМЫ

1. **Конфликты версий** — проверить совместимость Electron
2. **Пути к файлам** — использовать абсолютные пути
3. **Зависимости** — могут потребоваться дополнительные пакеты

---

**Скилл готов!** ✅
