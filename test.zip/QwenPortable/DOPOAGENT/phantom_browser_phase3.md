# 🎯 Skill: phantom_browser_phase3

**Версия:** 1.0.0  
**Дата:** 23 марта 2026 г.  
**Тип:** Phase Execution Expert  
**Статус:** ✅ Готов к использованию

---

## 📋 ОПИСАНИЕ

Скилл для выполнения **ФАЗЫ 3** разработки PhantomBrowser v3.0.

---

## 🎯 ТРИГГЕРЫ

```
Триггеры активации:
- "начни ФАЗУ 3"
- "интеграция в основной проект"
- "скопируй файлы в antidetect"
- "запусти тесты"
- "сборка Chromium"
- "настрой CI/CD"
- "Reporting System"
```

---

## 🛠️ ПРОТОКОЛ ФАЗЫ 3

### Этап 1: Интеграция (4-6 часов)
```bash
# 1. Копирование файлов
cp -r src/main/* C:\.qwen\antidetect\src\main\
cp -r src/preload/* C:\.qwen\antidetect\src\preload\
cp -r src/renderer/* C:\.qwen\antidetect\src\renderer\

# 2. Обновление зависимостей
cd C:\.qwen\antidetect
npm install

# 3. Проверка IPC
npm run typecheck
```

### Этап 2: Тесты (1-2 часа)
```bash
# Unit тесты
npm run test:unit
npm run test:unit:coverage

# E2E тесты
npm run test:e2e

# Detection тесты
npm run test:detection
```

### Этап 3: Сборка Chromium (12-24 часа)
```bash
# 1. Скачать ungoogled-chromium-windows
# 2. Применить rebrowser-patches
# 3. Применить кастомные патчи
# 4. Собрать
# 5. Протестировать
```

---

## ✅ ЧЕК-ЛИСТ

```
□ Файлы main скопированы
□ Файлы preload скопированы
□ Файлы renderer скопированы
□ Зависимости установлены
□ IPC работают
□ Unit тесты проходят (>90% coverage)
□ E2E тесты проходят
□ Detection тесты проходят
□ Chromium собран
```

---

**Скилл готов!** ✅
