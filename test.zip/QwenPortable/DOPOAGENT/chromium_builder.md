# 🎯 Skill: chromium_builder

**Версия:** 1.0.0  
**Дата:** 23 марта 2026 г.  
**Тип:** Build Expert  
**Статус:** ✅ Готов к использованию

---

## 📋 ОПИСАНИЕ

Скилл для **сборки Chromium** с патчами для PhantomBrowser v3.0.

---

## 🎯 ТРИГГЕРЫ

```
Триггеры активации:
- "собери Chromium"
- "build Chromium"
- "примени rebrowser-patches"
- "создай антидетект браузер"
- "патчи для Chromium"
```

---

## 🛠️ ПРОТОКОЛ СБОРКИ

### Шаг 1: Подготовка
```bash
# Создать папку для сборки
mkdir C:\.qwen\chromium-build
cd C:\.qwen\chromium-build

# Скачать ungoogled-chromium-windows
# https://github.com/ungoogled-software/ungoogled-chromium-windows/releases
```

### Шаг 2: Применить rebrowser-patches
```bash
# Клонировать патчи
git clone https://github.com/rebrowser/rebrowser-patches.git

# Применить патчи
cd rebrowser-patches
./apply.sh ../ungoogled-chromium
```

### Шаг 3: Кастомные патчи
```bash
# Canvas fingerprint patch
# WebGL spoofing patch
# WebRTC protection patch
# Connection API patch
```

### Шаг 4: Сборка
```bash
# Настроить сборку
gn gen out/Default --args="is_debug=false"

# Собрать
ninja -C out/Default chrome
```

### Шаг 5: Тестирование
```bash
# Запустить тесты
./out/Default/chrome --version

# Проверить эмуляцию
./out/Default/chrome --user-data-dir=C:\test-profile
```

---

## ✅ ЧЕК-ЛИСТ

```
□ ungoogled-chromium скачан
□ rebrowser-patches применены
□ Кастомные патчи применены
□ Сборка успешна
□ Тесты проходят
□ Браузер запускается
□ Эмуляция работает
```

---

## ⚠️ ИЗВЕСТНЫЕ ПРОБЛЕМЫ

1. **Время сборки:** 12-24 часа
2. **Требования:** 8GB+ RAM, 50GB+ места
3. **Зависимости:** Python 3.x, depot_tools

---

**Скилл готов!** ✅
