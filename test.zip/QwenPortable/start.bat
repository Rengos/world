@echo off
chcp 65001 > nul
title Qwen Portable — Groq Llama 3.3 70B

echo ════════════════════════════════════════════════════════════
echo   🚀 Qwen Portable v3.1.0 — Prompt Enhancer + 18 скиллов
echo ════════════════════════════════════════════════════════════
echo.

:: Проверяем Python
where python > nul 2>&1
if errorlevel 1 (
    echo ❌ Python не найден!
    echo    Скачай: https://python.org/downloads
    echo    ✅ Галочка: "Add Python to PATH"
    pause
    exit /b 1
)
echo ✅ Python найден

:: Загружаем API ключ из .env если есть
if exist "%~dp0enhancer\.env" (
    for /f "tokens=1,* delims==" %%a in ('type "%~dp0enhancer\.env"') do (
        if "%%a"=="GROQ_API_KEY" set GROQ_API_KEY=%%b
    )
)

:: Проверяем Groq API ключ
if "%GROQ_API_KEY%"=="" (
    echo.
    echo ⚠️  GROQ_API_KEY не найден!
    echo.
    echo    🔑 Получи бесплатно: https://console.groq.com/keys
    echo    📝 Открой: enhancer\.env
    echo    💾 Замени: GROQ_API_KEY=твой_ключ
    echo.
    echo    📚 Или читай: START_HERE.md
    echo.
    pause
    exit /b 1
)
echo ✅ API ключ загружен

:: Проверяем qwen
where qwen > nul 2>&1
if errorlevel 1 (
    echo.
    echo ⚠️  Qwen Code CLI не найден
    echo    Установи: npm install -g @qwen-code/qwen-code
    echo.
) else (
    echo ✅ Qwen Code CLI найден
)

:: Запускаем Prompt Enhancer с Groq
echo.
echo ════════════════════════════════════════════════════════════
echo   🧠 Запуск Prompt Enhancer (Groq Llama 3.3 70B)
echo ════════════════════════════════════════════════════════════
echo.

python "%~dp0enhancer\prompt_enhancer_groq.py" %*

if errorlevel 1 (
    echo.
    echo ⚠️  Ошибка выполнения
    echo    📚 Проверь: START_HERE.md или SETUP_INSTRUCTIONS.md
    echo.
    pause
)
