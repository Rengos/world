"""
udp_engine.py — NFQueue-based UDP packet interception engine.

Equivalent to Geneva's engine.py but for UDP traffic.
Intercepts UDP packets via netfilter, runs them through a UDPStrategy,
and sends the modified packets.

Requirements:
    pip install scapy netfilterqueue
    iptables / nftables must be available
"""

import argparse
import logging
import os
import signal
import socket
import subprocess
import sys
import threading
import time

logging.getLogger("scapy.runtime").setLevel(logging.ERROR)

try:
    import netfilterqueue
    NFQ_AVAILABLE = True
except ImportError:
    NFQ_AVAILABLE = False
    print("WARNING: netfilterqueue not available. Install with: pip install netfilterqueue")

from scapy.layers.inet import IP, UDP
from scapy.all import Raw, conf, send

from udp_transport import UDPPacket, UDPStrategy

BASEPATH = os.path.dirname(os.path.abspath(__file__))
logger = logging.getLogger("udp_engine")


class UDPEngine:
    """
    Intercepts UDP traffic on specified port(s) via NFQueue,
    runs packets through a UDPStrategy, and re-injects them.

    Usage as context manager:
        strategy = UDPStrategy(...)
        with UDPEngine(port=51820, strategy=strategy) as eng:
            # your VPN runs here
            pass

    Usage standalone:
        eng = UDPEngine(port=51820, strategy=strategy)
        eng.start()
        # ...
        eng.stop()
    """

    def __init__(self, port, strategy,
                 environment_id=None,
                 in_queue_num=3,
                 out_queue_num=4,
                 log_level="info",
                 save_packets=False,
                 output_dir="trials"):

        self.port = str(port)
        self.strategy = strategy
        self.environment_id = environment_id or _rand_id()
        self.in_queue_num = in_queue_num
        self.out_queue_num = out_queue_num
        self.save_packets = save_packets
        self.output_dir = output_dir

        self.running = False
        self.seen_packets = []

        self.out_nfq = None
        self.in_nfq = None
        self.out_thread = None
        self.in_thread = None

        self.socket = conf.L3socket()

        os.makedirs(output_dir, exist_ok=True)

        level = getattr(logging, log_level.upper(), logging.INFO)
        logging.basicConfig(
            level=level,
            format="%(asctime)s %(levelname)-7s [%(name)s] %(message)s"
        )

    # ── iptables helpers ──────────────────────────────────────────────────────

    def _iptables(self, add_or_del):
        flag = "-A" if add_or_del == "add" else "-D"
        port = self.port
        rules = [
            # Outbound UDP from this port → queue
            ["iptables", flag, "OUTPUT", "-p", "udp", "--sport", port,
             "-j", "NFQUEUE", "--queue-num", str(self.out_queue_num)],
            # Inbound UDP to this port → queue
            ["iptables", flag, "INPUT", "-p", "udp", "--dport", port,
             "-j", "NFQUEUE", "--queue-num", str(self.in_queue_num)],
        ]
        for rule in rules:
            try:
                subprocess.run(rule, check=True, capture_output=True)
                logger.debug("iptables %s: %s", add_or_del, " ".join(rule))
            except subprocess.CalledProcessError as e:
                logger.warning("iptables error: %s", e.stderr.decode().strip())

    # ── NFQueue callbacks ─────────────────────────────────────────────────────

    def _out_callback(self, nfpacket):
        """Outbound packet: run strategy, re-inject."""
        if not self.running:
            nfpacket.accept()
            return
        try:
            raw = IP(nfpacket.get_payload())
            if not raw.haslayer(UDP):
                nfpacket.accept()
                return

            pkt = UDPPacket(raw)
            nfpacket.drop()  # drop original, we'll send our own

            results = self.strategy.act_on_packet(pkt, logger)
            for out_pkt in results:
                self._send(out_pkt)

            if self.save_packets:
                self.seen_packets.append(pkt)

        except Exception:
            logger.exception("out_callback error")
            try:
                nfpacket.accept()
            except Exception:
                pass

    def _in_callback(self, nfpacket):
        """Inbound packet: run strategy (no branching on inbound)."""
        if not self.running:
            nfpacket.accept()
            return
        try:
            raw = IP(nfpacket.get_payload())
            if not raw.haslayer(UDP):
                nfpacket.accept()
                return

            pkt = UDPPacket(raw)
            results = self.strategy.act_on_packet(pkt, logger)

            if not results:
                nfpacket.drop()
                return

            # Overwrite with first result (no branching inbound)
            nfpacket.set_payload(bytes(results[0].packet))
            if results[0].sleep:
                time.sleep(results[0].sleep)
            nfpacket.accept()

        except Exception:
            logger.exception("in_callback error")
            try:
                nfpacket.accept()
            except Exception:
                pass

    def _send(self, udp_packet):
        try:
            if udp_packet.sleep:
                time.sleep(udp_packet.sleep)
            self.socket.send(udp_packet.packet)
        except Exception:
            logger.exception("send error")

    # ── NFQueue thread runners ─────────────────────────────────────────────────

    def _run_queue(self, nfq, nfq_socket, direction):
        logger.debug("NFQueue thread started: %s", direction)
        while self.running:
            try:
                nfq.run_socket(nfq_socket)
            except (socket.timeout, OSError):
                pass
            except Exception:
                if self.running:
                    logger.exception("NFQueue %s error", direction)
                break
        logger.debug("NFQueue thread stopped: %s", direction)

    # ── Start / Stop ──────────────────────────────────────────────────────────

    def start(self):
        if not NFQ_AVAILABLE:
            raise RuntimeError("netfilterqueue not installed")

        logger.info("UDPEngine starting (port=%s, strategy=%s)",
                    self.port, self.strategy)

        self._iptables("add")
        self.running = True

        # Outbound queue
        self.out_nfq = netfilterqueue.NetfilterQueue()
        self.out_nfq.bind(self.out_queue_num, self._out_callback)
        self.out_nfq_socket = socket.fromfd(
            self.out_nfq.get_fd(), socket.AF_UNIX, socket.SOCK_STREAM)
        self.out_nfq_socket.settimeout(1)

        # Inbound queue
        self.in_nfq = netfilterqueue.NetfilterQueue()
        self.in_nfq.bind(self.in_queue_num, self._in_callback)
        self.in_nfq_socket = socket.fromfd(
            self.in_nfq.get_fd(), socket.AF_UNIX, socket.SOCK_STREAM)
        self.in_nfq_socket.settimeout(1)

        self.out_thread = threading.Thread(
            target=self._run_queue,
            args=(self.out_nfq, self.out_nfq_socket, "out"),
            daemon=True)
        self.in_thread = threading.Thread(
            target=self._run_queue,
            args=(self.in_nfq, self.in_nfq_socket, "in"),
            daemon=True)

        self.out_thread.start()
        self.in_thread.start()
        logger.info("UDPEngine running")

    def stop(self):
        logger.info("UDPEngine stopping...")
        self.running = False
        self._iptables("del")
        time.sleep(0.2)

        for q in (self.out_nfq, self.in_nfq):
            try:
                if q:
                    q.unbind()
            except Exception:
                pass
        for s in (getattr(self, "out_nfq_socket", None),
                  getattr(self, "in_nfq_socket", None)):
            try:
                if s:
                    s.close()
            except Exception:
                pass
        for t in (self.out_thread, self.in_thread):
            if t and t.is_alive():
                t.join(timeout=2)

        self.socket.close()
        logger.info("UDPEngine stopped")

    def __enter__(self):
        self.start()
        return self

    def __exit__(self, *_):
        self.stop()


def _rand_id(n=8):
    import random, string
    return "".join(random.choices(string.ascii_lowercase + string.digits, k=n))
