"""
tests/test_system.py — Unit tests for Geneva-RL components.

Run with: pytest tests/ -v
"""

import os
import sys
import random
import math

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np
import pytest


# ── UDPTrigger tests ──────────────────────────────────────────────────────────

class TestUDPTrigger:

    def _make_pkt(self, dport=51820, sport=12345, payload=b"\x01\x00\x00\x00" + b"\xff" * 100):
        from scapy.layers.inet import IP, UDP
        from scapy.all import Raw
        from udp_transport import UDPPacket
        pkt = IP(dst="1.2.3.4") / UDP(sport=sport, dport=dport) / Raw(payload)
        return UDPPacket(pkt)

    def test_trigger_dport_match(self):
        from udp_transport import UDPTrigger
        import logging
        t = UDPTrigger(field="dport", value=51820)
        pkt = self._make_pkt(dport=51820)
        assert t.is_applicable(pkt, logging.getLogger()) is True

    def test_trigger_dport_no_match(self):
        from udp_transport import UDPTrigger
        import logging
        t = UDPTrigger(field="dport", value=51820)
        pkt = self._make_pkt(dport=1194)
        assert t.is_applicable(pkt, logging.getLogger()) is False

    def test_trigger_sport_match(self):
        from udp_transport import UDPTrigger
        import logging
        t = UDPTrigger(field="sport", value=12345)
        pkt = self._make_pkt(sport=12345)
        assert t.is_applicable(pkt, logging.getLogger()) is True

    def test_trigger_load_b0(self):
        from udp_transport import UDPTrigger
        import logging
        t = UDPTrigger(field="load_b0", value=1)
        pkt = self._make_pkt(payload=b"\x01\x00\x00\x00" + b"\xaa" * 50)
        assert t.is_applicable(pkt, logging.getLogger()) is True

    def test_trigger_gas(self):
        from udp_transport import UDPTrigger
        import logging
        t = UDPTrigger(field="dport", value=51820, gas=2)
        pkt = self._make_pkt(dport=51820)
        log = logging.getLogger()
        assert t.is_applicable(pkt, log) is True   # fire 1
        assert t.is_applicable(pkt, log) is True   # fire 2
        assert t.is_applicable(pkt, log) is False  # gas exhausted

    def test_trigger_parse(self):
        from udp_transport import UDPTrigger
        t = UDPTrigger.parse("[UDP:dport:51820]")
        assert t.field == "dport"
        assert t.value == 51820
        assert t.gas == -1

    def test_trigger_parse_with_gas(self):
        from udp_transport import UDPTrigger
        t = UDPTrigger.parse("[UDP:load_b0:199:5]")
        assert t.field == "load_b0"
        assert t.value == 199
        assert t.gas == 5

    def test_trigger_random(self):
        from udp_transport import UDPTrigger
        for _ in range(20):
            t = UDPTrigger.random()
            assert t.field in ["sport", "dport", "len", "chksum",
                               "load", "load_b0", "load_b1", "load_b2", "load_b3"]

    def test_trigger_mutate(self):
        from udp_transport import UDPTrigger
        t = UDPTrigger(field="dport", value=51820)
        for _ in range(10):
            m = t.mutate()
            assert m is not t  # new object


# ── UDPAction tests ───────────────────────────────────────────────────────────

class TestUDPActions:

    def _make_pkt(self, payload=None):
        from scapy.layers.inet import IP, UDP
        from scapy.all import Raw
        from udp_transport import UDPPacket
        if payload is None:
            payload = b"\x01\x00\x00\x00" + bytes(range(100))
        pkt = IP(dst="1.2.3.4") / UDP(sport=12345, dport=51820) / Raw(payload)
        return UDPPacket(pkt)

    def test_drop(self):
        from udp_transport import UDPDrop
        import logging
        a = UDPDrop()
        result = a.run(self._make_pkt(), logging.getLogger())
        assert result == []

    def test_duplicate(self):
        from udp_transport import UDPDuplicate
        import logging
        a = UDPDuplicate()
        result = a.run(self._make_pkt(), logging.getLogger())
        assert len(result) == 2

    def test_tamper_replace(self):
        from udp_transport import UDPTamper
        import logging
        from scapy.layers.inet import UDP
        a = UDPTamper("UDP", "load_b0", "replace", 0xC7)
        pkt = self._make_pkt(b"\x01\x00\x00\x00" + b"\xaa" * 50)
        result = a.run(pkt, logging.getLogger())
        assert len(result) == 1
        out_payload = bytes(result[0].packet[UDP].payload)
        assert out_payload[0] == 0xC7

    def test_tamper_corrupt(self):
        from udp_transport import UDPTamper
        import logging
        from scapy.layers.inet import UDP
        original_payload = b"\x01\x00\x00\x00" + b"\xaa" * 50
        a = UDPTamper("UDP", "load_b0", "corrupt", None)
        pkt = self._make_pkt(original_payload)
        result = a.run(pkt, logging.getLogger())
        assert len(result) == 1
        # byte 0 should be XORed (changed)
        out = bytes(result[0].packet[UDP].payload)
        assert out[0] != original_payload[0]

    def test_pad_small(self):
        from udp_transport import UDPPad
        import logging
        from scapy.layers.inet import UDP
        payload = b"\x01\x00\x00\x00" + b"\xaa" * 50
        a = UDPPad(min_pad=8, max_pad=32)
        pkt = self._make_pkt(payload)
        result = a.run(pkt, logging.getLogger())
        assert len(result) == 1
        out = bytes(result[0].packet[UDP].payload)
        assert len(out) >= len(payload) + 8
        assert len(out) <= len(payload) + 32

    def test_pad_changes_size(self):
        from udp_transport import UDPPad
        import logging
        from scapy.layers.inet import UDP
        payload = b"\x01\x00\x00\x00" + b"\xbb" * 100
        original_len = len(payload)
        a = UDPPad(min_pad=16, max_pad=16)  # fixed pad
        pkt = self._make_pkt(payload)
        result = a.run(pkt, logging.getLogger())
        out = bytes(result[0].packet[UDP].payload)
        assert len(out) == original_len + 16

    def test_fragment(self):
        from udp_transport import UDPFragment
        import logging
        payload = b"\x01\x00\x00\x00" + b"\xcc" * 100
        a = UDPFragment()
        pkt = self._make_pkt(payload)
        result = a.run(pkt, logging.getLogger())
        assert len(result) == 2
        # Two fragments together should contain all original payload bytes
        total = sum(len(bytes(r.packet)) for r in result)
        assert total > 0


# ── UDPStrategy tests ─────────────────────────────────────────────────────────

class TestUDPStrategy:

    def _make_pkt(self, dport=51820):
        from scapy.layers.inet import IP, UDP
        from scapy.all import Raw
        from udp_transport import UDPPacket
        payload = b"\x01\x00\x00\x00" + b"\xdd" * 100
        pkt = IP(dst="1.2.3.4") / UDP(sport=12345, dport=dport) / Raw(payload)
        return UDPPacket(pkt)

    def test_pass_through_no_match(self):
        from udp_transport import UDPStrategy, UDPActionTree, UDPTrigger, UDPDrop
        import logging
        # Trigger on port 9999, but packet is on 51820 → pass through
        trigger = UDPTrigger("dport", 9999)
        tree = UDPActionTree(trigger, [UDPDrop()])
        strategy = UDPStrategy(trees=[tree])
        pkt = self._make_pkt(dport=51820)
        result = strategy.act_on_packet(pkt, logging.getLogger())
        assert len(result) == 1  # passed through

    def test_drop_on_match(self):
        from udp_transport import UDPStrategy, UDPActionTree, UDPTrigger, UDPDrop
        import logging
        trigger = UDPTrigger("dport", 51820)
        tree = UDPActionTree(trigger, [UDPDrop()])
        strategy = UDPStrategy(trees=[tree])
        pkt = self._make_pkt(dport=51820)
        result = strategy.act_on_packet(pkt, logging.getLogger())
        assert result == []

    def test_random_strategy(self):
        from udp_transport import UDPStrategy
        for _ in range(10):
            s = UDPStrategy.random(num_trees=2)
            assert len(s.trees) == 2

    def test_mutate_strategy(self):
        from udp_transport import UDPStrategy
        import logging
        s = UDPStrategy.random(num_trees=1)
        for _ in range(5):
            m = s.mutate(logging.getLogger())
            assert m is not s


# ── Feature extraction tests ──────────────────────────────────────────────────

class TestFeatureExtraction:

    def test_shape(self):
        from ml_censor import extract_features, FEATURE_DIM
        payload = b"\x01\x00\x00\x00" + bytes(range(100))
        feat = extract_features(payload, 12345, 51820, 0.1, 5)
        assert feat.shape == (FEATURE_DIM,)

    def test_entropy_random(self):
        from ml_censor import payload_entropy
        data = bytes(range(256))  # uniform → max entropy
        ent = payload_entropy(data)
        assert ent > 7.9

    def test_entropy_constant(self):
        from ml_censor import payload_entropy
        data = b"\x00" * 100  # no entropy
        ent = payload_entropy(data)
        assert ent == 0.0

    def test_features_differ_by_payload(self):
        from ml_censor import extract_features
        p1 = b"\x01\x00\x00\x00" + b"\xaa" * 100
        p2 = b"\xC7\x00\x00\x00\x01" + bytes(range(100))
        f1 = extract_features(p1, 12345, 51820, 0.1, 5)
        f2 = extract_features(p2, 12345, 51820, 0.1, 5)
        assert not np.allclose(f1, f2)


# ── ML Censor tests ───────────────────────────────────────────────────────────

class TestMLCensor:

    def test_rule_based_wireguard(self):
        from ml_censor import rule_based_label, LABEL_WIREGUARD
        payload = b"\x01\x00\x00\x00" + b"\xee" * 144  # 148 bytes total
        label = rule_based_label(payload, 51820)
        assert label == LABEL_WIREGUARD

    def test_rule_based_quic(self):
        from ml_censor import rule_based_label, LABEL_QUIC
        payload = b"\xC7\x00\x00\x00\x01" + b"\xee" * 100
        label = rule_based_label(payload, 443)
        assert label == LABEL_QUIC

    def test_rule_based_dns(self):
        from ml_censor import rule_based_label, LABEL_DNS
        payload = b"\x1a\x2d" + b"\x00" * 10
        label = rule_based_label(payload, 53)
        assert label == LABEL_DNS

    def test_censor_blocks_wireguard(self):
        from ml_censor import MLCensor, LABEL_WIREGUARD
        censor = MLCensor()
        assert censor.blocks(LABEL_WIREGUARD) is True

    def test_censor_no_block_quic(self):
        from ml_censor import MLCensor, LABEL_QUIC
        censor = MLCensor()
        assert censor.blocks(LABEL_QUIC) is False

    def test_censor_fit_and_classify(self):
        from ml_censor import MLCensor, LABEL_WIREGUARD, LABEL_QUIC
        censor = MLCensor()
        censor.fit_initial(n_per_class=100)  # small for speed

        # WireGuard-like: should be classified as VPN
        wg_payload = b"\x01\x00\x00\x00" + b"\xff" * 144
        label = censor.classify(wg_payload, 12345, 51820, 0.1, 5)
        # Just check it returns a valid label
        from ml_censor import LABEL_NAMES
        assert label in LABEL_NAMES

    def test_detection_probability_range(self):
        from ml_censor import MLCensor
        censor = MLCensor()
        censor.fit_initial(n_per_class=100)
        payload = b"\x01\x00\x00\x00" + b"\xaa" * 100
        prob = censor.detection_probability(payload, 12345, 51820, 0.1, 5)
        assert 0.0 <= prob <= 1.0

    def test_score_strategy_range(self):
        from ml_censor import MLCensor
        from udp_transport import UDPStrategy
        censor = MLCensor()
        censor.fit_initial(n_per_class=100)
        strategy = UDPStrategy.random(num_trees=1)
        score = censor.score_strategy(strategy, n_packets=20)
        assert 0.0 <= score <= 1.0


# ── RL Agent tests ────────────────────────────────────────────────────────────

class TestRLAgent:

    def test_action_selection(self):
        from rl_agent import EvasionAgent, NUM_ACTIONS
        agent = EvasionAgent()
        state = np.zeros(32, dtype=np.float32)
        action = agent.select_action(state)
        assert 0 <= action < NUM_ACTIONS

    def test_replay_buffer(self):
        from rl_agent import ReplayBuffer
        buf = ReplayBuffer(capacity=100)
        for i in range(10):
            buf.push(
                np.zeros(32), i % 15, float(i), np.ones(32), False
            )
        assert len(buf) == 10
        states, actions, rewards, next_states, dones = buf.sample(5)
        assert states.shape == (5, 32)
        assert actions.shape == (5,)

    def test_numpy_net_forward(self):
        from rl_agent import NumpyNet, STATE_DIM, NUM_ACTIONS
        net = NumpyNet()
        x = np.random.randn(4, STATE_DIM).astype(np.float32)
        logits = net.forward(x)
        assert logits.shape == (4, NUM_ACTIONS)

    def test_numpy_net_proba(self):
        from rl_agent import NumpyNet, NUM_ACTIONS
        net = NumpyNet()
        state = np.random.randn(32).astype(np.float32)
        proba = net.predict_proba(state)
        assert proba.shape == (NUM_ACTIONS,)
        assert abs(proba.sum() - 1.0) < 1e-5
        assert (proba >= 0).all()

    def test_apply_action_quic(self):
        from rl_agent import EvasionAgent, ACTION_TAMPER_B0_QUIC
        agent = EvasionAgent()
        payload = b"\x01\x00\x00\x00" + b"\xaa" * 50
        out = agent._apply_action(payload, ACTION_TAMPER_B0_QUIC)
        assert out[0] == 0xC7

    def test_apply_action_pad(self):
        from rl_agent import EvasionAgent, ACTION_PAD_MEDIUM
        agent = EvasionAgent()
        payload = b"\x01\x00\x00\x00" + b"\xbb" * 50
        out = agent._apply_action(payload, ACTION_PAD_MEDIUM)
        assert len(out) > len(payload)

    def test_apply_action_noop(self):
        from rl_agent import EvasionAgent, ACTION_NOOP
        agent = EvasionAgent()
        payload = b"\x01\x00\x00\x00" + b"\xcc" * 50
        out = agent._apply_action(payload, ACTION_NOOP)
        assert out == payload

    def test_short_training(self):
        """Integration test: 5 episodes of training should not crash."""
        from rl_agent import train
        agent = train(
            n_episodes=5,
            n_packets_per_episode=10,
            batch_size=16,
            checkpoint_every=999,  # don't save
            save_dir="/tmp/geneva_rl_test",
            log_level="WARNING",
        )
        assert len(agent.episode_rewards) == 5
        assert len(agent.episode_evasion_rates) == 5

    def test_get_strategy(self):
        from rl_agent import EvasionAgent
        from udp_transport import UDPStrategy
        agent = EvasionAgent()
        strategy = agent.get_strategy()
        assert isinstance(strategy, UDPStrategy)
        assert len(strategy.trees) >= 1
