"""
evolve_rl.py — Main entrypoint for Geneva-RL.

Replaces Geneva's evolve.py (genetic algorithm) with an RL-based trainer.

Modes:
  train    — run RL training loop, save best strategy
  run      — load saved strategy and apply it to live traffic
  evaluate — score a strategy against the ML censor
  show     — print the current best strategy

Usage:
  # Train for 500 episodes against adaptive ML censor
  python3 evolve_rl.py train --episodes 500 --port 51820

  # Apply best learned strategy to live WireGuard traffic
  python3 evolve_rl.py run --port 51820 --checkpoint rl_checkpoints/policy_ep500

  # Evaluate a specific strategy string
  python3 evolve_rl.py evaluate --strategy "[UDP:dport:51820] tamper_b0_quic→pad_medium"

  # Just show best strategy from last training run
  python3 evolve_rl.py show
"""

import argparse
import json
import logging
import os
import signal
import sys
import threading
import time

import numpy as np

BASEPATH = os.path.dirname(os.path.abspath(__file__))
logger = logging.getLogger("evolve_rl")


# ── Strategy serialisation ────────────────────────────────────────────────────

def strategy_to_dict(strategy) -> dict:
    """Convert UDPStrategy to JSON-serialisable dict."""
    trees = []
    for tree in strategy.trees:
        actions = []
        for a in tree.actions:
            actions.append({
                "type": a.name,
                "params": str(a)
            })
        trees.append({
            "trigger": str(tree.trigger),
            "actions": actions,
        })
    return {
        "trees": trees,
        "fitness": getattr(strategy, "fitness", -1000.0),
    }


def save_strategy(strategy, path: str):
    d = strategy_to_dict(strategy)
    with open(path, "w") as f:
        json.dump(d, f, indent=2)
    logger.info("Strategy saved: %s", path)


def load_strategy_from_agent(checkpoint_path: str):
    """Load agent from checkpoint and reconstruct strategy."""
    from rl_agent import EvasionAgent
    agent = EvasionAgent()
    agent.load_checkpoint(checkpoint_path)
    return agent.get_strategy()


# ── Training mode ─────────────────────────────────────────────────────────────

def cmd_train(args):
    from rl_agent import train as rl_train

    logger.info("=" * 60)
    logger.info("Geneva-RL: RL-based UDP censorship evasion trainer")
    logger.info("=" * 60)
    logger.info("Episodes     : %d", args.episodes)
    logger.info("Packets/ep   : %d", args.packets)
    logger.info("Port         : %s", args.port)
    logger.info("Save dir     : %s", args.save_dir)
    logger.info("=" * 60)

    agent = rl_train(
        n_episodes=args.episodes,
        n_packets_per_episode=args.packets,
        batch_size=args.batch,
        checkpoint_every=args.checkpoint_every,
        save_dir=args.save_dir,
        log_level=args.log.upper(),
    )

    # Save best strategy
    if agent.hof_strategy:
        strat_path = os.path.join(args.save_dir, "best_strategy.json")
        save_strategy(agent.hof_strategy, strat_path)

        logger.info("")
        logger.info("═" * 60)
        logger.info("Training complete!")
        logger.info("Best evasion rate : %.1f%%", agent.hof_score * 100)
        logger.info("Best strategy     : %s", agent.hof_strategy)
        logger.info("Strategy saved to : %s", strat_path)
        logger.info("")
        logger.info("To apply strategy to live traffic:")
        logger.info("  python3 evolve_rl.py run --port %s --checkpoint %s/policy_ep%d",
                    args.port, args.save_dir, args.episodes)

    _print_action_stats(agent)


def _print_action_stats(agent):
    from rl_agent import ACTION_NAMES
    total = agent.action_counts.sum()
    if total == 0:
        return
    logger.info("")
    logger.info("Action usage statistics:")
    sorted_idx = np.argsort(agent.action_counts)[::-1]
    for i in sorted_idx:
        if agent.action_counts[i] > 0:
            pct = 100.0 * agent.action_counts[i] / total
            logger.info("  %-20s %6.1f%%", ACTION_NAMES[i], pct)


# ── Run mode (apply to live traffic) ─────────────────────────────────────────

def cmd_run(args):
    from udp_engine import UDPEngine

    if args.checkpoint:
        logger.info("Loading strategy from checkpoint: %s", args.checkpoint)
        strategy = load_strategy_from_agent(args.checkpoint)
    elif args.strategy_file:
        logger.info("Loading strategy from file: %s", args.strategy_file)
        strategy = _load_strategy_file(args.strategy_file)
    else:
        logger.info("No checkpoint or strategy file given — using random strategy")
        from udp_transport import UDPStrategy
        strategy = UDPStrategy.random(num_trees=1)

    logger.info("Strategy: %s", strategy)
    logger.info("Applying to UDP port %s", args.port)
    logger.info("Press Ctrl+C to stop")

    stop_event = threading.Event()

    def _sigint(sig, frame):
        logger.info("Stopping...")
        stop_event.set()

    signal.signal(signal.SIGINT, _sigint)
    signal.signal(signal.SIGTERM, _sigint)

    try:
        with UDPEngine(
            port=args.port,
            strategy=strategy,
            log_level=args.log,
            save_packets=args.save_packets,
        ) as engine:
            stop_event.wait()
    except RuntimeError as e:
        logger.error("Engine error: %s", e)
        logger.error("Make sure you're running as root and netfilterqueue is installed.")
        sys.exit(1)


def _load_strategy_file(path: str):
    """
    Load a strategy from a JSON file saved by save_strategy().
    Reconstructs a basic UDPStrategy from the stored description.
    """
    from udp_transport import (UDPStrategy, UDPActionTree, UDPTrigger,
                               UDPTamper, UDPPad, UDPFragment, UDPSleep,
                               UDPDuplicate, UDPDrop)

    with open(path) as f:
        d = json.load(f)

    trees = []
    for tree_d in d.get("trees", []):
        # Parse trigger string like "[UDP:dport:51820]"
        trigger = UDPTrigger.parse(tree_d["trigger"])

        actions = []
        for act_d in tree_d.get("actions", []):
            atype = act_d["type"]
            if atype == "udp_tamper":
                actions.append(UDPTamper.random())  # simplified restore
            elif atype == "udp_pad":
                actions.append(UDPPad())
            elif atype == "udp_fragment":
                actions.append(UDPFragment())
            elif atype == "udp_sleep":
                actions.append(UDPSleep())
            elif atype == "udp_drop":
                actions.append(UDPDrop())

        trees.append(UDPActionTree(trigger, actions))

    return UDPStrategy(trees=trees)


# ── Evaluate mode ─────────────────────────────────────────────────────────────

def cmd_evaluate(args):
    from ml_censor import MLCensor
    from udp_transport import UDPStrategy

    logger.info("Initialising ML censor...")
    censor = MLCensor()
    censor.fit_initial(n_per_class=500)

    if args.checkpoint:
        strategy = load_strategy_from_agent(args.checkpoint)
    elif args.strategy_file:
        strategy = _load_strategy_file(args.strategy_file)
    else:
        # Baseline: no obfuscation (pass-through)
        strategy = UDPStrategy(trees=[])

    logger.info("Strategy: %s", strategy)
    logger.info("Evaluating against ML censor (%d packets)...", args.eval_packets)

    score = censor.score_strategy(strategy, n_packets=args.eval_packets)

    print("")
    print("═" * 50)
    print("Evasion rate : %.1f%%" % (score * 100))
    print("Detection rate: %.1f%%" % ((1 - score) * 100))
    print("═" * 50)

    if score >= 0.9:
        print("★ Excellent — highly evasive strategy")
    elif score >= 0.7:
        print("✓ Good — mostly evades detection")
    elif score >= 0.5:
        print("~ Moderate — partial evasion")
    else:
        print("✗ Poor — mostly detected")


# ── Show mode ─────────────────────────────────────────────────────────────────

def cmd_show(args):
    save_dir = args.save_dir
    strat_path = os.path.join(save_dir, "best_strategy.json")

    if not os.path.exists(strat_path):
        print("No strategy found in %s" % save_dir)
        print("Run: python3 evolve_rl.py train --save-dir %s" % save_dir)
        return

    with open(strat_path) as f:
        d = json.load(f)

    print("")
    print("Best strategy from: %s" % strat_path)
    print("Fitness: %.3f" % d.get("fitness", -1))
    print("")
    for i, tree in enumerate(d.get("trees", [])):
        print("Tree %d:" % (i + 1))
        print("  Trigger : %s" % tree["trigger"])
        print("  Actions : %s" % " → ".join(
            a["type"] for a in tree.get("actions", [])))
    print("")

    # Also show stats file if available
    stats_files = []
    if os.path.exists(save_dir):
        for fn in os.listdir(save_dir):
            if fn.endswith("_stats.json"):
                stats_files.append(os.path.join(save_dir, fn))
    if stats_files:
        latest = sorted(stats_files)[-1]
        with open(latest) as f:
            stats = json.load(f)
        print("Latest checkpoint stats:")
        print("  Episode          : %d" % stats.get("episode", "?"))
        print("  Epsilon          : %.3f" % stats.get("epsilon", 1.0))
        print("  Mean evasion rate: %.1f%%" % (
            stats.get("mean_evasion_rate", 0) * 100))


# ── CLI ───────────────────────────────────────────────────────────────────────

def build_parser():
    parser = argparse.ArgumentParser(
        description="Geneva-RL: RL-based UDP censorship evasion",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python3 evolve_rl.py train --episodes 500 --port 51820
  python3 evolve_rl.py run   --port 51820 --checkpoint rl_checkpoints/policy_ep500
  python3 evolve_rl.py evaluate --checkpoint rl_checkpoints/policy_ep500
  python3 evolve_rl.py show
        """
    )

    sub = parser.add_subparsers(dest="command")

    # train
    p_train = sub.add_parser("train", help="Run RL training loop")
    p_train.add_argument("--episodes", type=int, default=500,
                         help="Number of training episodes (default: 500)")
    p_train.add_argument("--packets", type=int, default=50,
                         help="Packets per episode (default: 50)")
    p_train.add_argument("--batch", type=int, default=64,
                         help="Replay buffer batch size (default: 64)")
    p_train.add_argument("--port", default="51820",
                         help="VPN port to optimise for (default: 51820)")
    p_train.add_argument("--save-dir", default="rl_checkpoints",
                         help="Checkpoint directory")
    p_train.add_argument("--checkpoint-every", type=int, default=50,
                         help="Save checkpoint every N episodes")
    p_train.add_argument("--log", default="info",
                         choices=["debug","info","warning","error"])

    # run
    p_run = sub.add_parser("run", help="Apply strategy to live UDP traffic")
    p_run.add_argument("--port", required=True,
                       help="UDP port to intercept (e.g. 51820)")
    p_run.add_argument("--checkpoint", default=None,
                       help="Path to RL checkpoint (without .npz extension)")
    p_run.add_argument("--strategy-file", default=None,
                       help="Path to strategy JSON file")
    p_run.add_argument("--save-packets", action="store_true",
                       help="Save intercepted packets to disk")
    p_run.add_argument("--log", default="info",
                       choices=["debug","info","warning","error"])

    # evaluate
    p_eval = sub.add_parser("evaluate", help="Score a strategy against ML censor")
    p_eval.add_argument("--checkpoint", default=None)
    p_eval.add_argument("--strategy-file", default=None)
    p_eval.add_argument("--eval-packets", type=int, default=200)
    p_eval.add_argument("--log", default="info",
                        choices=["debug","info","warning","error"])

    # show
    p_show = sub.add_parser("show", help="Show best strategy from last run")
    p_show.add_argument("--save-dir", default="rl_checkpoints")

    return parser


def main():
    parser = build_parser()
    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(0)

    log_level = getattr(args, "log", "info").upper()
    logging.basicConfig(
        level=getattr(logging, log_level),
        format="%(asctime)s %(levelname)-7s %(message)s"
    )

    dispatch = {
        "train":    cmd_train,
        "run":      cmd_run,
        "evaluate": cmd_evaluate,
        "show":     cmd_show,
    }
    dispatch[args.command](args)


if __name__ == "__main__":
    main()
