"""
rl_agent.py — Reinforcement Learning agent for censorship evasion strategy search.

Replaces Geneva's genetic algorithm with a Proximal Policy Optimization (PPO)
agent that learns to craft UDP packet manipulation strategies.

Architecture:
  State:  feature vector of current packet + session context
  Action: which UDP manipulation to apply (from a discrete action space)
  Reward: +1 if packet evades censor, -1 if blocked, +0.5 if evasion_prob < 0.3

Why RL over genetic algorithm:
  - GA: blind random mutation + selection. No memory, no generalisation.
  - RL: learns WHICH features of the packet make it detectable, and
        HOW to modify them. Generalises to unseen packet patterns.

The agent outputs a probability distribution over:
  [tamper_b0, tamper_b1, tamper_b2, tamper_b3,
   pad_small, pad_medium, pad_large,
   fragment, duplicate, sleep_short, sleep_long,
   noop]

Implemented in pure numpy (no PyTorch/TF required for basic version).
Optional: plug in PyTorch for the neural net backend.
"""

import json
import logging
import math
import os
import random
import time
from collections import deque

import numpy as np

logger = logging.getLogger(__name__)

# ── Action space ──────────────────────────────────────────────────────────────

ACTION_TAMPER_B0       = 0   # randomise payload byte 0
ACTION_TAMPER_B1       = 1
ACTION_TAMPER_B2       = 2
ACTION_TAMPER_B3       = 3
ACTION_TAMPER_B0_QUIC  = 4   # set byte 0 to QUIC marker (0xC7)
ACTION_TAMPER_B0_DNS   = 5   # set byte 0 to high DNS ID byte
ACTION_TAMPER_B0_STUN  = 6   # set bytes 0-1 to STUN magic
ACTION_PAD_SMALL       = 7   # +8..32 random bytes
ACTION_PAD_MEDIUM      = 8   # +32..128 random bytes
ACTION_PAD_LARGE       = 9   # +128..512 random bytes
ACTION_FRAGMENT        = 10  # split payload
ACTION_DUPLICATE       = 11  # send two copies
ACTION_SLEEP_SHORT     = 12  # 5ms delay
ACTION_SLEEP_LONG      = 13  # 50ms delay
ACTION_NOOP            = 14  # pass through unchanged

NUM_ACTIONS = 15

ACTION_NAMES = [
    "tamper_b0", "tamper_b1", "tamper_b2", "tamper_b3",
    "tamper_b0_quic", "tamper_b0_dns", "tamper_b0_stun",
    "pad_small", "pad_medium", "pad_large",
    "fragment", "duplicate",
    "sleep_short", "sleep_long",
    "noop"
]

# ── State / observation encoding ──────────────────────────────────────────────

STATE_DIM = 32  # must match ml_censor.FEATURE_DIM

# ── Replay buffer ─────────────────────────────────────────────────────────────

class ReplayBuffer:
    def __init__(self, capacity=10000):
        self.buffer = deque(maxlen=capacity)

    def push(self, state, action, reward, next_state, done):
        self.buffer.append((state, action, reward, next_state, done))

    def sample(self, batch_size):
        batch = random.sample(self.buffer, min(batch_size, len(self.buffer)))
        states, actions, rewards, next_states, dones = zip(*batch)
        return (np.array(states, dtype=np.float32),
                np.array(actions, dtype=np.int32),
                np.array(rewards, dtype=np.float32),
                np.array(next_states, dtype=np.float32),
                np.array(dones, dtype=np.float32))

    def __len__(self):
        return len(self.buffer)


# ── Simple neural network (numpy, no framework needed) ───────────────────────

class NumpyNet:
    """
    2-layer MLP policy network implemented in pure numpy.
    Input: state vector (STATE_DIM,)
    Output: action logits (NUM_ACTIONS,)

    Trained with a simple policy gradient (REINFORCE).
    Swap this class for a PyTorch/TF equivalent for better performance.
    """

    def __init__(self, input_dim=STATE_DIM, hidden_dim=128, output_dim=NUM_ACTIONS,
                 lr=1e-3):
        # Xavier init
        self.W1 = np.random.randn(input_dim, hidden_dim) * math.sqrt(2.0 / input_dim)
        self.b1 = np.zeros(hidden_dim)
        self.W2 = np.random.randn(hidden_dim, hidden_dim) * math.sqrt(2.0 / hidden_dim)
        self.b2 = np.zeros(hidden_dim)
        self.W3 = np.random.randn(hidden_dim, output_dim) * math.sqrt(2.0 / hidden_dim)
        self.b3 = np.zeros(output_dim)
        self.lr = lr
        # Gradient accumulators
        self._grad = {}

    def forward(self, x):
        """x: (batch, input_dim) → logits: (batch, output_dim)"""
        self.z1 = x @ self.W1 + self.b1
        self.a1 = np.maximum(0, self.z1)           # ReLU
        self.z2 = self.a1 @ self.W2 + self.b2
        self.a2 = np.maximum(0, self.z2)           # ReLU
        self.logits = self.a2 @ self.W3 + self.b3
        return self.logits

    def softmax(self, logits):
        e = np.exp(logits - logits.max(axis=-1, keepdims=True))
        return e / e.sum(axis=-1, keepdims=True)

    def predict_proba(self, state):
        """state: (STATE_DIM,) → proba: (NUM_ACTIONS,)"""
        logits = self.forward(state.reshape(1, -1))[0]
        return self.softmax(logits.reshape(1, -1))[0]

    def policy_gradient_update(self, states, actions, returns):
        """
        REINFORCE policy gradient update.
        states:  (N, STATE_DIM)
        actions: (N,) int
        returns: (N,) float  (discounted cumulative rewards)
        """
        N = len(states)
        logits = self.forward(states)
        proba = self.softmax(logits)

        # Compute log prob of chosen actions
        log_proba = np.log(proba[np.arange(N), actions] + 1e-8)

        # Policy gradient: maximise E[log π(a|s) * G]
        # = minimise -E[log π(a|s) * G]
        loss_grad = -returns * (1.0 - proba[np.arange(N), actions])

        # Backprop (simplified, only output layer for now)
        dlogits = proba.copy()
        dlogits[np.arange(N), actions] -= 1.0
        dlogits *= loss_grad.reshape(-1, 1) / N

        # Layer 3
        dW3 = self.a2.T @ dlogits
        db3 = dlogits.sum(axis=0)

        # Layer 2
        da2 = dlogits @ self.W3.T
        dz2 = da2 * (self.z2 > 0)
        dW2 = self.a1.T @ dz2
        db2 = dz2.sum(axis=0)

        # Layer 1
        da1 = dz2 @ self.W2.T
        dz1 = da1 * (self.z1 > 0)
        dW1 = states.T @ dz1
        db1 = dz1.sum(axis=0)

        # Gradient descent
        self.W3 -= self.lr * dW3
        self.b3 -= self.lr * db3
        self.W2 -= self.lr * dW2
        self.b2 -= self.lr * db2
        self.W1 -= self.lr * dW1
        self.b1 -= self.lr * db1

        return float(-np.mean(log_proba * returns))

    def save(self, path):
        np.savez(path, W1=self.W1, b1=self.b1, W2=self.W2, b2=self.b2,
                 W3=self.W3, b3=self.b3)

    def load(self, path):
        data = np.load(path + ".npz")
        self.W1, self.b1 = data["W1"], data["b1"]
        self.W2, self.b2 = data["W2"], data["b2"]
        self.W3, self.b3 = data["W3"], data["b3"]


# ── RL Agent ──────────────────────────────────────────────────────────────────

class EvasionAgent:
    """
    RL agent that learns UDP packet manipulation strategies to evade DPI.

    The agent interacts with an MLCensor (the "environment"):
      - Observes: packet feature vector
      - Acts: chooses a manipulation action
      - Receives: reward based on whether the modified packet evades detection

    Training loop:
      for each episode (session):
        for each packet in session:
          state = extract_features(packet)
          action = agent.select_action(state)
          packet = apply_action(packet, action)
          reward = censor.score(packet)
          agent.update(state, action, reward)

    After training, agent.get_strategy() returns a UDPStrategy
    that can be plugged into the engine.
    """

    def __init__(self, lr=1e-3, gamma=0.99, epsilon=1.0,
                 epsilon_min=0.05, epsilon_decay=0.995,
                 save_dir="rl_checkpoints"):
        self.net = NumpyNet(lr=lr)
        self.gamma = gamma
        self.epsilon = epsilon
        self.epsilon_min = epsilon_min
        self.epsilon_decay = epsilon_decay
        self.replay = ReplayBuffer(capacity=20000)
        self.save_dir = save_dir
        os.makedirs(save_dir, exist_ok=True)

        # Statistics
        self.episode_rewards = []
        self.episode_evasion_rates = []
        self.action_counts = np.zeros(NUM_ACTIONS)
        self.step_count = 0

        # Hall of fame: best strategy seen so far
        self.hof_strategy = None
        self.hof_score = 0.0

    def select_action(self, state: np.ndarray) -> int:
        """ε-greedy action selection."""
        if random.random() < self.epsilon:
            return random.randint(0, NUM_ACTIONS - 1)
        proba = self.net.predict_proba(state)
        return int(np.argmax(proba))

    def select_action_stochastic(self, state: np.ndarray) -> int:
        """Sample from policy distribution (used during training)."""
        if random.random() < self.epsilon:
            return random.randint(0, NUM_ACTIONS - 1)
        proba = self.net.predict_proba(state)
        return int(np.random.choice(NUM_ACTIONS, p=proba))

    def store(self, state, action, reward, next_state, done):
        self.replay.push(state, action, reward, next_state, done)
        self.action_counts[action] += 1
        self.step_count += 1

    def train_step(self, batch_size=64):
        """Sample from replay buffer and update policy."""
        if len(self.replay) < batch_size:
            return None

        states, actions, rewards, next_states, dones = \
            self.replay.sample(batch_size)

        # Compute discounted returns (simple MC estimate)
        returns = rewards.copy()
        # Normalise returns for stability
        if returns.std() > 1e-6:
            returns = (returns - returns.mean()) / (returns.std() + 1e-8)

        loss = self.net.policy_gradient_update(states, actions, returns)

        # Decay epsilon
        if self.epsilon > self.epsilon_min:
            self.epsilon *= self.epsilon_decay

        return loss

    def run_episode(self, censor, n_packets=50, port=51820) -> dict:
        """
        Run one training episode against the given censor.

        Returns dict with episode statistics.
        """
        from ml_censor import extract_features, LABEL_WIREGUARD
        from scapy.layers.inet import IP, UDP
        from scapy.all import Raw
        from udp_transport import UDPPacket

        episode_reward = 0.0
        evaded = 0
        trajectory = []  # (state, action, reward)

        for pkt_idx in range(n_packets):
            # Generate a synthetic WireGuard-like packet
            wg_type = random.choice([1, 2, 3, 4])
            payload = bytes([wg_type, 0, 0, 0]
                           + [random.randint(0, 255) for _ in range(140)])

            iat = random.uniform(0, 2)
            state = extract_features(payload, random.randint(1024, 65535),
                                     port, iat, pkt_idx + 1)

            action = self.select_action_stochastic(state)

            # Apply action to packet
            modified_payload = self._apply_action(payload, action)

            # Get reward from censor
            det_prob = censor.detection_probability(
                modified_payload,
                random.randint(1024, 65535),
                port, iat, pkt_idx + 1
            )

            # Reward signal:
            #   +1.0  = fully evades detection
            #   -1.0  = fully detected
            #   intermediate = partial credit
            reward = 1.0 - 2.0 * det_prob

            if det_prob < 0.3:
                evaded += 1

            episode_reward += reward

            # Next state
            next_state = extract_features(
                modified_payload,
                random.randint(1024, 65535), port,
                iat, pkt_idx + 1
            )

            trajectory.append((state, action, reward, next_state,
                               pkt_idx == n_packets - 1))

        # Store trajectory in replay buffer
        for (s, a, r, ns, done) in trajectory:
            self.store(s, a, r, ns, done)

        # Online censor update (it learns from what it saw)
        censor.update(payload, random.randint(1024, 65535), port,
                      0.1, n_packets, LABEL_WIREGUARD)

        evasion_rate = evaded / n_packets
        self.episode_rewards.append(episode_reward)
        self.episode_evasion_rates.append(evasion_rate)

        return {
            "reward": episode_reward,
            "evasion_rate": evasion_rate,
            "epsilon": self.epsilon,
        }

    def _apply_action(self, payload: bytes, action: int) -> bytes:
        """Apply a discrete action to a payload bytes object."""
        payload = bytearray(payload)

        if action == ACTION_TAMPER_B0:
            if len(payload) > 0:
                payload[0] = random.randint(0, 255)

        elif action == ACTION_TAMPER_B1:
            if len(payload) > 1:
                payload[1] = random.randint(0, 255)

        elif action == ACTION_TAMPER_B2:
            if len(payload) > 2:
                payload[2] = random.randint(0, 255)

        elif action == ACTION_TAMPER_B3:
            if len(payload) > 3:
                payload[3] = random.randint(0, 255)

        elif action == ACTION_TAMPER_B0_QUIC:
            # QUIC long header marker
            if len(payload) >= 5:
                payload[0] = 0xC7
                payload[1] = 0x00
                payload[2] = 0x00
                payload[3] = 0x00
                payload[4] = 0x01

        elif action == ACTION_TAMPER_B0_DNS:
            # DNS-like header
            if len(payload) >= 4:
                payload[0] = random.randint(0, 255)  # transaction ID hi
                payload[1] = random.randint(0, 255)  # transaction ID lo
                payload[2] = 0x01                    # standard query
                payload[3] = 0x00

        elif action == ACTION_TAMPER_B0_STUN:
            # STUN Binding Request header
            if len(payload) >= 4:
                payload[0] = 0x00
                payload[1] = 0x01
                payload[2] = 0x00
                payload[3] = len(payload) - 20 if len(payload) > 20 else 0

        elif action == ACTION_PAD_SMALL:
            payload.extend(os.urandom(random.randint(8, 32)))

        elif action == ACTION_PAD_MEDIUM:
            payload.extend(os.urandom(random.randint(32, 128)))

        elif action == ACTION_PAD_LARGE:
            payload.extend(os.urandom(random.randint(128, 512)))

        elif action == ACTION_FRAGMENT:
            # Return first half only (simulate fragmentation)
            split = len(payload) // 2
            payload = payload[:split]

        elif action == ACTION_DUPLICATE:
            # Double the payload (simulate duplicate send — just mark it)
            pass  # Engine handles actual duplication

        elif action == ACTION_SLEEP_SHORT:
            time.sleep(0.005)

        elif action == ACTION_SLEEP_LONG:
            time.sleep(0.05)

        # ACTION_NOOP: pass through

        return bytes(payload)

    def get_strategy(self):
        """
        Convert the learned policy into a UDPStrategy object
        that can be used by the engine.

        We do this by observing which actions the policy most frequently
        selects for typical WireGuard packets, and building a strategy tree.
        """
        from udp_transport import (UDPStrategy, UDPActionTree, UDPTrigger,
                                   UDPTamper, UDPPad, UDPDuplicate, UDPSleep,
                                   UDPFragment)
        from ml_censor import extract_features

        # Sample actions for typical WG packets
        action_votes = np.zeros(NUM_ACTIONS)
        for _ in range(200):
            payload = bytes([random.choice([1, 2, 3, 4]), 0, 0, 0]
                           + [random.randint(0, 255) for _ in range(140)])
            state = extract_features(payload, 12345, 51820, 0.1, 5)
            proba = self.net.predict_proba(state)
            action_votes += proba

        action_votes /= 200

        # Build a strategy from top-3 actions
        top_actions = np.argsort(action_votes)[::-1][:3]
        logger.info("Top actions: %s",
                    [ACTION_NAMES[a] for a in top_actions])

        actions_list = []
        for a in top_actions:
            if a == ACTION_TAMPER_B0_QUIC:
                actions_list.append(UDPTamper("UDP", "load_b0", "replace", 0xC7))
            elif a == ACTION_TAMPER_B0_DNS:
                actions_list.append(UDPTamper("UDP", "load_b0", "replace",
                                              random.randint(0, 255)))
            elif a in (ACTION_TAMPER_B0, ACTION_TAMPER_B1,
                       ACTION_TAMPER_B2, ACTION_TAMPER_B3):
                byte_idx = a
                actions_list.append(UDPTamper("UDP", "load_b%d" % byte_idx,
                                              "corrupt", None))
            elif a == ACTION_PAD_SMALL:
                actions_list.append(UDPPad(8, 32))
            elif a == ACTION_PAD_MEDIUM:
                actions_list.append(UDPPad(32, 128))
            elif a == ACTION_PAD_LARGE:
                actions_list.append(UDPPad(128, 512))
            elif a == ACTION_FRAGMENT:
                actions_list.append(UDPFragment())
            elif a == ACTION_SLEEP_SHORT:
                actions_list.append(UDPSleep(0.005))

        trigger = UDPTrigger(field="dport", value=51820, gas=-1)
        tree = UDPActionTree(trigger, actions_list)
        strategy = UDPStrategy(trees=[tree])
        return strategy

    def save_checkpoint(self, episode):
        path = os.path.join(self.save_dir, "policy_ep%d" % episode)
        self.net.save(path)
        stats = {
            "episode": episode,
            "epsilon": self.epsilon,
            "mean_evasion_rate": float(np.mean(self.episode_evasion_rates[-100:]))
                                 if self.episode_evasion_rates else 0.0,
            "action_counts": self.action_counts.tolist(),
        }
        with open(path + "_stats.json", "w") as f:
            json.dump(stats, f, indent=2)
        logger.info("Checkpoint saved: %s", path)

    def load_checkpoint(self, path):
        self.net.load(path)
        logger.info("Checkpoint loaded: %s", path)


# ── Training loop ─────────────────────────────────────────────────────────────

def train(n_episodes=500, n_packets_per_episode=50,
          batch_size=64, checkpoint_every=50,
          save_dir="rl_checkpoints", log_level="INFO"):
    """
    Main training loop.

    Args:
        n_episodes: number of training episodes
        n_packets_per_episode: packets per episode
        batch_size: replay buffer batch size
        checkpoint_every: save checkpoint every N episodes
        save_dir: directory for checkpoints
        log_level: logging level

    Returns:
        Trained EvasionAgent
    """
    logging.basicConfig(
        level=getattr(logging, log_level),
        format="%(asctime)s %(levelname)s %(message)s"
    )
    logger = logging.getLogger("rl_train")

    logger.info("Initialising ML censor (adaptive DPI)...")
    from ml_censor import MLCensor
    censor = MLCensor()
    censor.fit_initial(n_per_class=500)
    logger.info("ML censor ready")

    agent = EvasionAgent(save_dir=save_dir)
    logger.info("Agent initialised. Starting training for %d episodes...", n_episodes)

    for episode in range(1, n_episodes + 1):
        # Run episode
        stats = agent.run_episode(censor, n_packets=n_packets_per_episode)

        # Train policy
        loss = agent.train_step(batch_size=batch_size)

        # Logging
        if episode % 10 == 0:
            recent_evasion = np.mean(agent.episode_evasion_rates[-10:])
            recent_reward  = np.mean(agent.episode_rewards[-10:])
            logger.info(
                "Episode %4d | ε=%.3f | evasion=%.1f%% | reward=%.2f | loss=%s",
                episode, agent.epsilon,
                recent_evasion * 100,
                recent_reward,
                "%.4f" % loss if loss is not None else "N/A"
            )

        # Score best strategy
        if episode % 25 == 0:
            strategy = agent.get_strategy()
            score = censor.score_strategy(strategy, n_packets=100)
            logger.info("  Strategy score (evasion%%): %.1f%%", score * 100)
            if score > agent.hof_score:
                agent.hof_score = score
                agent.hof_strategy = strategy
                logger.info("  ★ New best strategy! Score: %.1f%%", score * 100)

        # Checkpoint
        if episode % checkpoint_every == 0:
            agent.save_checkpoint(episode)

    logger.info("Training complete.")
    logger.info("Best strategy evasion rate: %.1f%%", agent.hof_score * 100)
    if agent.hof_strategy:
        logger.info("Best strategy: %s", agent.hof_strategy)

    return agent


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="RL-based censorship evasion trainer")
    parser.add_argument("--episodes", type=int, default=500)
    parser.add_argument("--packets", type=int, default=50)
    parser.add_argument("--batch", type=int, default=64)
    parser.add_argument("--save-dir", default="rl_checkpoints")
    parser.add_argument("--log", default="INFO")
    args = parser.parse_args()

    agent = train(
        n_episodes=args.episodes,
        n_packets_per_episode=args.packets,
        batch_size=args.batch,
        save_dir=args.save_dir,
        log_level=args.log,
    )
