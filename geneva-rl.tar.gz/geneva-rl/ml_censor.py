"""
ml_censor.py — ML-based traffic classifier used as the "censor" during training.

Instead of Geneva's hand-coded censors (censor1.py … censor11.py),
we use a trainable ML model that mimics real DPI behaviour.

Architecture:
  - Feature extractor: packet → feature vector
  - Classifier: Random Forest + optional neural net
  - Online learning: updates as it sees more evasion attempts

This serves two purposes:
  1. During RL training: acts as an adaptive adversary
  2. As a measurement tool: tells you how detectable your traffic is

Features extracted per packet:
  - Size, inter-arrival time
  - First 8 payload bytes (protocol fingerprint region)
  - Entropy of payload
  - Port numbers
  - Statistical moments (mean, variance of payload bytes)
"""

import math
import random
import struct
import time
from collections import deque

import numpy as np

# Optional: sklearn for the ML model
try:
    from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
    from sklearn.preprocessing import StandardScaler
    from sklearn.linear_model import SGDClassifier
    SKLEARN_AVAILABLE = True
except ImportError:
    SKLEARN_AVAILABLE = False


# ── Feature extraction ────────────────────────────────────────────────────────

FEATURE_DIM = 32  # size of feature vector


def payload_entropy(data: bytes) -> float:
    """Shannon entropy of byte sequence. Range [0, 8]."""
    if not data:
        return 0.0
    counts = [0] * 256
    for b in data:
        counts[b] += 1
    n = len(data)
    ent = 0.0
    for c in counts:
        if c > 0:
            p = c / n
            ent -= p * math.log2(p)
    return ent


def extract_features(packet_bytes: bytes, sport: int, dport: int,
                     inter_arrival: float, session_pkt_count: int) -> np.ndarray:
    """
    Extract a fixed-length feature vector from a UDP packet.

    Args:
        packet_bytes: raw UDP payload bytes
        sport, dport: source/dest ports
        inter_arrival: seconds since last packet in session
        session_pkt_count: how many packets seen in this session

    Returns:
        np.ndarray of shape (FEATURE_DIM,)
    """
    features = np.zeros(FEATURE_DIM, dtype=np.float32)
    payload = packet_bytes[:1472] if packet_bytes else b""

    # [0] packet size
    features[0] = len(payload)

    # [1] inter-arrival time (log scale)
    features[1] = math.log1p(inter_arrival * 1000)  # ms

    # [2] session packet count
    features[2] = min(session_pkt_count, 100)

    # [3-4] ports
    features[3] = sport / 65535.0
    features[4] = dport / 65535.0

    # [5] payload entropy
    features[5] = payload_entropy(payload) / 8.0

    # [6-13] first 8 bytes of payload (raw, normalised)
    for i in range(min(8, len(payload))):
        features[6 + i] = payload[i] / 255.0

    # [14-17] statistical moments of payload bytes
    if payload:
        arr = np.frombuffer(payload, dtype=np.uint8).astype(np.float32)
        features[14] = arr.mean() / 255.0
        features[15] = arr.std() / 128.0
        features[16] = float(np.min(arr)) / 255.0
        features[17] = float(np.max(arr)) / 255.0
    else:
        features[14:18] = 0.0

    # [18-21] byte frequency histogram (4 buckets: 0-63, 64-127, 128-191, 192-255)
    if payload:
        total = len(payload)
        buckets = [0, 0, 0, 0]
        for b in payload:
            buckets[b // 64] += 1
        for i in range(4):
            features[18 + i] = buckets[i] / total

    # [22] size modulo common MTU values (detects padding patterns)
    features[22] = (len(payload) % 64) / 64.0

    # [23] is size a "round" number? (common in VPN padding)
    features[23] = 1.0 if len(payload) % 16 == 0 else 0.0

    # [24-27] bigram frequency of first 8 bytes
    for i in range(min(4, len(payload) - 1)):
        bigram = (payload[i] << 8) | payload[i + 1]
        features[24 + i] = bigram / 65535.0

    # [28-31] reserved / future features
    features[28:32] = 0.0

    return features


# ── Protocol label definitions ────────────────────────────────────────────────

LABEL_UNKNOWN    = 0
LABEL_WIREGUARD  = 1
LABEL_OPENVPN    = 2
LABEL_QUIC       = 3
LABEL_DNS        = 4
LABEL_DTLS       = 5
LABEL_OTHER_VPN  = 6
LABEL_LEGITIMATE = 7

LABEL_NAMES = {
    LABEL_UNKNOWN:    "unknown",
    LABEL_WIREGUARD:  "wireguard",
    LABEL_OPENVPN:    "openvpn",
    LABEL_QUIC:       "quic",
    LABEL_DNS:        "dns",
    LABEL_DTLS:       "dtls",
    LABEL_OTHER_VPN:  "other_vpn",
    LABEL_LEGITIMATE: "legitimate",
}

# VPN labels that should be blocked
VPN_LABELS = {LABEL_WIREGUARD, LABEL_OPENVPN, LABEL_OTHER_VPN}


def rule_based_label(payload: bytes, dport: int) -> int:
    """
    Fast rule-based heuristic classifier.
    Used to generate training data and as fallback.
    """
    if not payload:
        return LABEL_UNKNOWN

    # WireGuard: type field in first 4 bytes (1, 2, 3, 4)
    if len(payload) >= 4:
        msg_type = payload[0]
        if msg_type in (1, 2, 3, 4) and payload[1] == 0 and payload[2] == 0 and payload[3] == 0:
            if dport in (51820, 51821) or len(payload) in (148, 92, 64):
                return LABEL_WIREGUARD

    # QUIC: first byte high bits
    if payload[0] & 0x40:  # QUIC long header
        if len(payload) > 4 and payload[1:5] == b'\x00\x00\x00\x01':
            return LABEL_QUIC

    # DNS: port 53, or DNS-like structure
    if dport == 53 or (len(payload) >= 12 and (payload[2] & 0xF8) == 0):
        return LABEL_DNS

    # DTLS
    if len(payload) >= 3 and payload[0] in (0x16, 0x17) and payload[1] == 0xFE:
        return LABEL_DTLS

    # OpenVPN: opcode in first byte
    if len(payload) >= 2:
        opcode = (payload[0] >> 3) & 0x1F
        if opcode in range(1, 10):
            return LABEL_OPENVPN

    # High entropy, large payload → likely encrypted VPN
    ent = payload_entropy(payload[:64])
    if ent > 7.5 and len(payload) > 100:
        return LABEL_OTHER_VPN

    return LABEL_LEGITIMATE


# ── ML Censor (adaptive DPI model) ───────────────────────────────────────────

class MLCensor:
    """
    Adaptive ML-based DPI classifier.

    Acts as the "censor" during RL training. Learns from what it sees,
    becoming harder to evade over time — forcing the RL agent to find
    genuinely robust strategies.

    Usage:
        censor = MLCensor()
        censor.fit_initial()          # train on synthetic data
        label = censor.classify(payload, sport, dport, iat, count)
        blocked = censor.blocks(label)
        censor.update(payload, sport, dport, iat, count, true_label)  # online update
    """

    def __init__(self, online_update_interval=50):
        self.online_update_interval = online_update_interval
        self._buffer_X = []
        self._buffer_y = []
        self._update_count = 0

        if SKLEARN_AVAILABLE:
            # Primary classifier: gradient boosting (good at learning subtle patterns)
            self.model = GradientBoostingClassifier(
                n_estimators=100,
                max_depth=4,
                learning_rate=0.1,
                subsample=0.8,
                random_state=42
            )
            # Online updatable secondary classifier
            self.online_model = SGDClassifier(
                loss="log_loss",
                max_iter=1,
                warm_start=True,
                random_state=42
            )
            self.scaler = StandardScaler()
            self._fitted = False
            self._online_fitted = False
        else:
            self.model = None
            self._fitted = False

    def _generate_synthetic_data(self, n_per_class=500):
        """
        Generate synthetic training data for each protocol class.
        Used to bootstrap the classifier before real traffic is seen.
        """
        X, y = [], []

        for _ in range(n_per_class):
            # WireGuard-like
            payload = bytes([random.choice([1, 2, 3, 4]), 0, 0, 0]
                            + [random.randint(0, 255) for _ in range(140)])
            feat = extract_features(payload, random.randint(1024, 65535), 51820,
                                    random.uniform(0, 2), random.randint(1, 20))
            X.append(feat); y.append(LABEL_WIREGUARD)

            # QUIC-like
            payload = bytes([0xC7, 0, 0, 0, 1]
                            + [random.randint(0, 255) for _ in range(120)])
            feat = extract_features(payload, random.randint(1024, 65535),
                                    random.choice([443, 8443]), random.uniform(0, 0.1),
                                    random.randint(1, 50))
            X.append(feat); y.append(LABEL_QUIC)

            # DNS-like
            payload = bytes([random.randint(0, 255), random.randint(0, 255),
                             1, 0, 0, 1, 0, 0, 0, 0, 0, 0]
                            + [random.randint(0, 255) for _ in range(20)])
            feat = extract_features(payload, random.randint(1024, 65535), 53,
                                    random.uniform(0, 0.5), random.randint(1, 5))
            X.append(feat); y.append(LABEL_DNS)

            # OpenVPN-like
            opcode = random.randint(1, 9) << 3
            payload = bytes([opcode] + [random.randint(0, 255) for _ in range(100)])
            feat = extract_features(payload, random.randint(1024, 65535), 1194,
                                    random.uniform(0, 1), random.randint(1, 30))
            X.append(feat); y.append(LABEL_OPENVPN)

            # Legitimate random UDP
            payload = bytes([random.randint(0, 255) for _ in range(random.randint(10, 200))])
            feat = extract_features(payload, random.randint(1024, 65535),
                                    random.randint(1024, 65535), random.uniform(0, 5),
                                    random.randint(1, 100))
            X.append(feat); y.append(LABEL_LEGITIMATE)

        return np.array(X), np.array(y)

    def fit_initial(self, n_per_class=500):
        """Train classifier on synthetic data."""
        if not SKLEARN_AVAILABLE:
            return
        X, y = self._generate_synthetic_data(n_per_class)
        X_scaled = self.scaler.fit_transform(X)
        self.model.fit(X_scaled, y)
        # Prime online model via partial_fit (supports classes= param)
        self.online_model.partial_fit(X_scaled[:100], y[:100],
                                      classes=list(LABEL_NAMES.keys()))
        self._fitted = True
        self._online_fitted = True

    def classify(self, payload: bytes, sport: int, dport: int,
                 inter_arrival: float = 0.1, session_count: int = 1) -> int:
        """
        Classify a packet. Returns LABEL_* constant.
        Falls back to rule-based if ML not available.
        """
        feat = extract_features(payload, sport, dport, inter_arrival, session_count)

        if SKLEARN_AVAILABLE and self._fitted:
            feat_scaled = self.scaler.transform(feat.reshape(1, -1))
            # Blend ML + rule-based for robustness
            ml_label = int(self.model.predict(feat_scaled)[0])
            rule_label = rule_based_label(payload, dport)
            # If they agree, high confidence; else use ML
            if ml_label == rule_label:
                return ml_label
            # Online model as tiebreaker
            if self._online_fitted:
                online_label = int(self.online_model.predict(feat_scaled)[0])
                if online_label == ml_label or online_label == rule_label:
                    return online_label
            return ml_label

        return rule_based_label(payload, dport)

    def blocks(self, label: int) -> bool:
        """Returns True if the censor would block this traffic label."""
        return label in VPN_LABELS

    def classify_and_block(self, payload: bytes, sport: int, dport: int,
                            inter_arrival: float = 0.1,
                            session_count: int = 1) -> tuple:
        """
        Returns (label, is_blocked).
        """
        label = self.classify(payload, sport, dport, inter_arrival, session_count)
        return label, self.blocks(label)

    def detection_probability(self, payload: bytes, sport: int, dport: int,
                              inter_arrival: float = 0.1,
                              session_count: int = 1) -> float:
        """
        Returns probability [0, 1] that this packet is detected as VPN.
        Used as a soft reward signal for RL.
        """
        feat = extract_features(payload, sport, dport, inter_arrival, session_count)

        if SKLEARN_AVAILABLE and self._fitted:
            feat_scaled = self.scaler.transform(feat.reshape(1, -1))
            proba = self.model.predict_proba(feat_scaled)[0]
            # Sum probabilities of VPN labels
            vpn_prob = sum(
                proba[i] for i, cls in enumerate(self.model.classes_)
                if cls in VPN_LABELS
            )
            return float(vpn_prob)

        # Fallback: rule-based → binary
        label = rule_based_label(payload, dport)
        return 1.0 if self.blocks(label) else 0.0

    def update(self, payload: bytes, sport: int, dport: int,
               inter_arrival: float, session_count: int, true_label: int):
        """
        Online update: teach the model about a new packet.
        This makes the censor adaptive — it learns from evasion attempts.
        """
        if not SKLEARN_AVAILABLE or not self._online_fitted:
            return

        feat = extract_features(payload, sport, dport, inter_arrival, session_count)
        feat_scaled = self.scaler.transform(feat.reshape(1, -1))

        self._buffer_X.append(feat_scaled[0])
        self._buffer_y.append(true_label)
        self._update_count += 1

        if self._update_count % self.online_update_interval == 0:
            X_batch = np.array(self._buffer_X[-self.online_update_interval:])
            y_batch = np.array(self._buffer_y[-self.online_update_interval:])
            self.online_model.partial_fit(X_batch, y_batch)
            # Clear old buffer (keep last 500 for memory efficiency)
            if len(self._buffer_X) > 500:
                self._buffer_X = self._buffer_X[-500:]
                self._buffer_y = self._buffer_y[-500:]

    def score_strategy(self, strategy, n_packets=100) -> float:
        """
        Score a UDPStrategy by running synthetic VPN packets through it
        and measuring how often the censor detects them.

        Returns evasion rate [0, 1]. Higher = better evasion.
        """
        import logging
        _log = logging.getLogger("ml_censor.score")

        evaded = 0
        for _ in range(n_packets):
            # Generate a fake WireGuard-like packet
            payload = bytes([random.choice([1, 2, 3, 4]), 0, 0, 0]
                           + [random.randint(0, 255) for _ in range(140)])

            # Wrap in UDPPacket and run through strategy
            try:
                from scapy.layers.inet import IP, UDP
                from scapy.all import Raw
                from udp_transport import UDPPacket

                pkt = IP(dst="1.2.3.4") / UDP(sport=12345, dport=51820) / Raw(payload)
                udp_pkt = UDPPacket(pkt)
                results = strategy.act_on_packet(udp_pkt, _log)

                for result_pkt in results:
                    out_payload = bytes(result_pkt.packet[UDP].payload) \
                        if result_pkt.packet.haslayer(UDP) else b""
                    label, blocked = self.classify_and_block(
                        out_payload, 12345, 51820,
                        random.uniform(0, 0.5), 5
                    )
                    if not blocked:
                        evaded += 1
                        break
            except Exception as e:
                _log.debug("score_strategy error: %s", e)
                continue

        return evaded / n_packets
