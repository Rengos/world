# Geneva-RL

Расширение Geneva с заменой генетического алгоритма на Reinforcement Learning
и добавлением полноценной поддержки UDP.

---

## Что это такое

**Geneva** (оригинал, Университет Мэриленда) — инструмент, который автоматически
ищет стратегии обхода цензуры через манипуляции с пакетами. Работает только на TCP.

**Geneva-RL** добавляет:
- Полный UDP-стек (триггеры, actions, деревья стратегий)
- ML-классификатор трафика вместо rule-based цензора
- RL-агент (policy gradient) вместо генетического алгоритма
- Адаптивный цензор — учится во время тренировки

---

## Архитектура

```
┌──────────────────────────────────────────────────────┐
│                    Geneva-RL                          │
│                                                       │
│  ┌─────────────┐      ┌──────────────────────────┐   │
│  │  RL Agent   │◄────►│     ML Censor            │   │
│  │  (Policy    │      │  (адаптивный DPI-        │   │
│  │   Network)  │      │   классификатор)         │   │
│  └──────┬──────┘      └──────────────────────────┘   │
│         │                                             │
│         ▼                                             │
│  ┌─────────────┐      ┌──────────────────────────┐   │
│  │ UDP Strategy│─────►│     UDP Engine           │   │
│  │ (деревья    │      │  (NFQueue перехват)      │   │
│  │  действий)  │      │                          │   │
│  └─────────────┘      └──────────────────────────┘   │
└──────────────────────────────────────────────────────┘
```

### Компоненты

| Файл | Роль |
|---|---|
| `udp_transport.py` | UDP-слой: триггеры, actions, стратегии |
| `ml_censor.py` | Адаптивный ML DPI-классификатор |
| `rl_agent.py` | RL-агент + цикл обучения |
| `udp_engine.py` | NFQueue-перехватчик для живого трафика |
| `evolve_rl.py` | CLI: train / run / evaluate / show |

---

## Установка

```bash
# Зависимости системы
sudo apt-get install -y \
    python3-pip \
    libnetfilter-queue-dev \
    python3-dev \
    build-essential

# Python зависимости
pip3 install -r requirements.txt
```

---

## Использование

### 1. Тренировка

```bash
# 500 эпизодов против ML-цензора, оптимизация для WireGuard (порт 51820)
python3 evolve_rl.py train --episodes 500 --port 51820

# Более интенсивная тренировка
python3 evolve_rl.py train \
    --episodes 2000 \
    --packets 100 \
    --batch 128 \
    --save-dir my_checkpoints
```

Что происходит во время тренировки:
1. ML-цензор обучается на синтетических данных (WireGuard, QUIC, DNS, OpenVPN…)
2. RL-агент пробует разные манипуляции с пакетами
3. Получает reward: +1 если цензор не детектирует, -1 если детектирует
4. ML-цензор адаптируется — учится распознавать новые паттерны
5. Агент вынужден искать более глубокие стратегии

### 2. Применение к живому трафику

```bash
# Нужны права root (для NFQueue)
sudo python3 evolve_rl.py run \
    --port 51820 \
    --checkpoint rl_checkpoints/policy_ep500
```

### 3. Оценка стратегии

```bash
python3 evolve_rl.py evaluate \
    --checkpoint rl_checkpoints/policy_ep500 \
    --eval-packets 500
```

Вывод:
```
══════════════════════════════════════════════════
Evasion rate : 73.4%
Detection rate: 26.6%
══════════════════════════════════════════════════
✓ Good — mostly evades detection
```

### 4. Просмотр лучшей стратегии

```bash
python3 evolve_rl.py show
```

---

## Как устроены стратегии

### Триггеры

```
[UDP:dport:51820]       — срабатывает на пакеты к порту 51820
[UDP:sport:12345]       — срабатывает на пакеты с порта 12345
[UDP:load_b0:1]         — срабатывает если первый байт payload = 1
[UDP:load_b0:1:5]       — то же, но только первые 5 раз (gas=5)
```

### Actions

| Action | Что делает |
|---|---|
| `tamper_b0_quic` | Первые 5 байт → QUIC Long Header (0xC7 0x00 0x00 0x00 0x01) |
| `tamper_b0_dns` | Первые 4 байта → DNS query header |
| `tamper_b0_stun` | Первые 4 байта → STUN Binding Request |
| `tamper_b0..b3` | Рандомизировать байты 0-3 payload |
| `pad_small` | Добавить 8-32 случайных байта |
| `pad_medium` | Добавить 32-128 случайных байта |
| `pad_large` | Добавить 128-512 случайных байта |
| `fragment` | Разрезать payload пополам → 2 датаграммы |
| `duplicate` | Отправить 2 копии пакета |
| `sleep_short` | Задержка 5ms (timing обфускация) |
| `sleep_long` | Задержка 50ms |
| `noop` | Пропустить без изменений |

### Пример найденной стратегии

```
[UDP:dport:51820] tamper_b0_quic → pad_medium → sleep_short
```

DPI видит:
- Байт 0 = 0xC7 → QUIC Long Header
- Размер пакета: +64 случайных байт → не совпадает с WireGuard сигнатурой
- Timing: небольшая задержка → ломает timing fingerprint

---

## Тесты

```bash
pip3 install pytest
pytest tests/ -v
```

Покрытие:
- UDPTrigger: parse, match, gas, random, mutate
- UDPActions: drop, duplicate, tamper, pad, fragment
- UDPStrategy: pass-through, match, mutate
- ML Censor: feature extraction, classification, scoring
- RL Agent: action selection, buffer, network, training

---

## Ключевые отличия от оригинального Geneva

| | Geneva (оригинал) | Geneva-RL |
|---|---|---|
| Протокол | TCP only | TCP (оригинал) + **UDP** |
| Алгоритм поиска | Генетический алгоритм | **Reinforcement Learning** |
| Цензор | Простые rule-based эмуляторы | **Адаптивный ML-классификатор** |
| Обучение цензора | Статичный | **Онлайн-обновление** |
| Обобщение | Не обобщает | **Учится паттернам** |

---

## Дальнейшее развитие

- [ ] PyTorch backend для нейросети (вместо numpy)
- [ ] PPO вместо REINFORCE (стабильнее сходится)
- [ ] Тестирование против реальных nDPI/Suricata
- [ ] Интеграция с оригинальным Geneva (общий evaluator)
- [ ] Поддержка DTLS, QUIC как транспортных слоёв
- [ ] Распределённая тренировка (несколько серверов)

---

## Академические источники

- Kevin Bock et al. — "Geneva: Evolving Censorship Evasion" (CCS 2019)
- Schulman et al. — "Proximal Policy Optimization Algorithms" (2017)
- Anderson et al. — "Machine Learning for Encrypted Traffic Classification" (2017)
- Juarez et al. — "Toward an Efficient Website Fingerprinting Defense" (2016)
