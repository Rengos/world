"""
udp_transport.py — UDP transport layer for Geneva-RL.

Geneva original works only at TCP level via NFQueue.
This module adds full UDP packet manipulation support:
  - UDP trigger matching (sport, dport, len, payload bytes)
  - UDP-aware fragment, duplicate, tamper, drop actions
  - NFQueue-based interception for UDP traffic

Designed to plug directly into Geneva's existing action/trigger
infrastructure with minimal changes to the original codebase.
"""

import logging
import os
import random
import socket
import struct

# Suppress scapy IPv6 route errors in sandboxed environments
import scapy.config
scapy.config.conf.ipv6_enabled = False

from scapy.layers.inet import IP, UDP
from scapy.packet import Raw

logger = logging.getLogger(__name__)


# ── UDP Field definitions (mirrors Geneva's TCP layer pattern) ────────────────

UDP_FIELDS = {
    "sport":   {"type": int,   "min": 0,     "max": 65535},
    "dport":   {"type": int,   "min": 0,     "max": 65535},
    "len":     {"type": int,   "min": 8,     "max": 65535},
    "chksum":  {"type": int,   "min": 0,     "max": 65535},
    # Payload fields (first N bytes)
    "load":    {"type": bytes, "min": 0,     "max": 1472},
    "load_b0": {"type": int,   "min": 0,     "max": 255},   # byte 0 of payload
    "load_b1": {"type": int,   "min": 0,     "max": 255},
    "load_b2": {"type": int,   "min": 0,     "max": 255},
    "load_b3": {"type": int,   "min": 0,     "max": 255},
}


class UDPPacket:
    """
    Wrapper around a Scapy IP/UDP packet that mirrors Geneva's
    layers.packet.Packet interface enough to be used in action trees.
    """

    def __init__(self, scapy_packet):
        self.packet = scapy_packet
        self.sleep = 0  # Geneva compatibility

    def haslayer(self, layer):
        return self.packet.haslayer(layer)

    def get(self, layer, field):
        """Get a field value from the given layer."""
        try:
            if layer == "UDP":
                if field == "load_b0":
                    raw = bytes(self.packet[UDP].payload)
                    return raw[0] if raw else 0
                if field.startswith("load_b"):
                    idx = int(field[6:])
                    raw = bytes(self.packet[UDP].payload)
                    return raw[idx] if len(raw) > idx else 0
                return getattr(self.packet[UDP], field)
            elif layer == "IP":
                return getattr(self.packet[IP], field)
        except Exception:
            return None

    def set(self, layer, field, value):
        """Set a field value in the given layer."""
        try:
            if layer == "UDP":
                if field.startswith("load_b"):
                    idx = int(field[6:])
                    raw = bytearray(bytes(self.packet[UDP].payload))
                    if len(raw) > idx:
                        raw[idx] = value & 0xFF
                    self.packet[UDP].payload = Raw(bytes(raw))
                    # Recalculate
                    del self.packet[UDP].chksum
                    del self.packet[UDP].len
                else:
                    setattr(self.packet[UDP], field, value)
                    del self.packet[UDP].chksum
            elif layer == "IP":
                setattr(self.packet[IP], field, value)
                del self.packet[IP].chksum
        except Exception as e:
            logger.debug("UDPPacket.set error: %s", e)

    def copy(self):
        return UDPPacket(self.packet.copy())

    def fragment(self, fragsize=None):
        """
        Fragment UDP payload into two UDP packets.
        Since UDP has no built-in fragmentation, we split the payload
        and send two separate datagrams.
        """
        raw = bytes(self.packet[UDP].payload)
        if not raw or len(raw) < 4:
            return [self, self.copy()]

        if fragsize is None:
            fragsize = max(1, len(raw) // 2)

        part1 = raw[:fragsize]
        part2 = raw[fragsize:]

        p1 = self.packet.copy()
        p1[UDP].payload = Raw(part1)
        del p1[UDP].len; del p1[UDP].chksum; del p1[IP].chksum

        p2 = self.packet.copy()
        p2[UDP].payload = Raw(part2)
        del p2[UDP].len; del p2[UDP].chksum; del p2[IP].chksum

        return [UDPPacket(p1), UDPPacket(p2)]

    def __bytes__(self):
        return bytes(self.packet)

    def __len__(self):
        return len(self.packet)

    def __str__(self):
        return self.packet.summary()


# ── UDP Trigger ───────────────────────────────────────────────────────────────

class UDPTrigger:
    """
    Trigger that fires on UDP packets matching a field/value condition.

    Syntax mirrors Geneva: [UDP:dport:51820]
    Supports: sport, dport, len, load_b0, load_b1, load_b2, load_b3
    """

    TRIGGER_PROTO = "UDP"

    def __init__(self, field="dport", value=0, gas=-1):
        self.field = field
        self.value = value
        # Gas: how many times this trigger can fire (-1 = unlimited)
        self.gas = gas
        self._fired = 0

    def is_applicable(self, packet, logger):
        """Check if this trigger applies to the given packet."""
        if not packet.haslayer("UDP"):
            return False

        if self.gas != -1 and self._fired >= self.gas:
            return False

        pkt_val = packet.get("UDP", self.field)
        if pkt_val is None:
            return False

        match = (pkt_val == self.value)
        if match:
            self._fired += 1
        return match

    def __str__(self):
        gas_str = "" if self.gas == -1 else ":%d" % self.gas
        return "[UDP:%s:%s%s]" % (self.field, self.value, gas_str)

    def __repr__(self):
        return self.__str__()

    @classmethod
    def parse(cls, trigger_str):
        """
        Parse trigger string like '[UDP:dport:51820]' or '[UDP:load_b0:199]'
        """
        trigger_str = trigger_str.strip("[]")
        parts = trigger_str.split(":")
        if len(parts) < 3 or parts[0] != "UDP":
            raise ValueError("Invalid UDP trigger: %s" % trigger_str)
        field = parts[1]
        value_str = parts[2]
        gas = -1
        if len(parts) == 4:
            gas = int(parts[3])
        # Parse value
        if value_str.startswith("0x"):
            value = int(value_str, 16)
        else:
            try:
                value = int(value_str)
            except ValueError:
                value = value_str
        return cls(field=field, value=value, gas=gas)

    @classmethod
    def random(cls, fields=None):
        """Generate a random UDP trigger."""
        if fields is None:
            fields = list(UDP_FIELDS.keys())
        field = random.choice(fields)
        info = UDP_FIELDS[field]
        if info["type"] == int:
            value = random.randint(info["min"], info["max"])
        else:
            value = random.randint(0, 255)
        return cls(field=field, value=value)

    def mutate(self):
        """Return a mutated copy of this trigger."""
        t = UDPTrigger(self.field, self.value, self.gas)
        info = UDP_FIELDS.get(self.field, {"type": int, "min": 0, "max": 65535})
        # Either change field or change value
        if random.random() < 0.3:
            t.field = random.choice(list(UDP_FIELDS.keys()))
            info = UDP_FIELDS[t.field]
        if info["type"] == int:
            delta = random.randint(-100, 100)
            t.value = max(info["min"], min(info["max"], t.value + delta))
        return t


# ── UDP Actions ───────────────────────────────────────────────────────────────

class UDPAction:
    """Base class for UDP packet actions."""

    name = "udp_base"

    def run(self, packet, logger):
        """
        Process packet, return list of packets to send.
        Empty list = drop.
        """
        raise NotImplementedError


class UDPDrop(UDPAction):
    name = "udp_drop"

    def run(self, packet, logger):
        logger.debug("UDP drop")
        return []

    def __str__(self):
        return "udp_drop"


class UDPDuplicate(UDPAction):
    name = "udp_duplicate"

    def __init__(self, left=None, right=None):
        self.left = left    # action to apply to copy 1
        self.right = right  # action to apply to copy 2

    def run(self, packet, logger):
        copy1 = packet.copy()
        copy2 = packet.copy()
        out = []
        if self.left:
            out.extend(self.left.run(copy1, logger))
        else:
            out.append(copy1)
        if self.right:
            out.extend(self.right.run(copy2, logger))
        else:
            out.append(copy2)
        return out

    def __str__(self):
        l = str(self.left) if self.left else ""
        r = str(self.right) if self.right else ""
        return "udp_duplicate(%s,%s)" % (l, r)


class UDPTamper(UDPAction):
    """
    Tamper with a specific UDP field.
    Modes: replace, corrupt, add
    """
    name = "udp_tamper"

    def __init__(self, layer="UDP", field="load_b0", mode="replace", value=None):
        self.layer = layer
        self.field = field
        self.mode = mode
        self.value = value

    def run(self, packet, logger):
        p = packet.copy()
        current = p.get(self.layer, self.field)

        if self.mode == "replace":
            p.set(self.layer, self.field, self.value)
        elif self.mode == "corrupt":
            if isinstance(current, int):
                p.set(self.layer, self.field,
                      current ^ random.randint(1, 255))
        elif self.mode == "add":
            if isinstance(current, int):
                info = UDP_FIELDS.get(self.field, {"max": 255})
                p.set(self.layer, self.field,
                      min(info["max"], current + self.value))

        logger.debug("UDP tamper %s:%s:%s → %s", self.layer, self.field, self.mode, self.value)
        return [p]

    def __str__(self):
        return "udp_tamper{%s:%s:%s:%s}" % (
            self.layer, self.field, self.mode, self.value)

    @classmethod
    def random(cls):
        field = random.choice(list(UDP_FIELDS.keys()))
        info = UDP_FIELDS[field]
        mode = random.choice(["replace", "corrupt", "add"])
        if info["type"] == int:
            value = random.randint(info["min"], info["max"])
        else:
            value = random.randint(0, 255)
        return cls(field=field, mode=mode, value=value)

    def mutate(self):
        t = UDPTamper(self.layer, self.field, self.mode, self.value)
        choice = random.random()
        if choice < 0.3:
            t.field = random.choice(list(UDP_FIELDS.keys()))
        elif choice < 0.6:
            t.mode = random.choice(["replace", "corrupt", "add"])
        else:
            info = UDP_FIELDS.get(self.field, {"type": int, "min": 0, "max": 255})
            if info["type"] == int:
                delta = random.randint(-50, 50)
                t.value = max(info["min"], min(info["max"],
                              (self.value or 0) + delta))
        return t


class UDPFragment(UDPAction):
    """Split UDP payload into two datagrams."""
    name = "udp_fragment"

    def __init__(self, fragsize=None, left=None, right=None):
        self.fragsize = fragsize
        self.left = left
        self.right = right

    def run(self, packet, logger):
        fragments = packet.fragment(self.fragsize)
        out = []
        if len(fragments) >= 2:
            f1, f2 = fragments[0], fragments[1]
        else:
            f1 = f2 = fragments[0]

        if self.left:
            out.extend(self.left.run(f1, logger))
        else:
            out.append(f1)
        if self.right:
            out.extend(self.right.run(f2, logger))
        else:
            out.append(f2)
        return out

    def __str__(self):
        return "udp_fragment{%s}" % (self.fragsize or "auto")


class UDPSleep(UDPAction):
    """Delay packet sending (timing obfuscation)."""
    name = "udp_sleep"

    def __init__(self, delay=0.1):
        self.delay = delay

    def run(self, packet, logger):
        import time
        time.sleep(self.delay)
        return [packet]

    def __str__(self):
        return "udp_sleep{%.3f}" % self.delay


class UDPPad(UDPAction):
    """
    Add random padding bytes to UDP payload.
    This is the S4 equivalent — breaks size-based fingerprinting.
    """
    name = "udp_pad"

    def __init__(self, min_pad=8, max_pad=64):
        self.min_pad = min_pad
        self.max_pad = max_pad

    def run(self, packet, logger):
        p = packet.copy()
        pad_len = random.randint(self.min_pad, self.max_pad)
        padding = os.urandom(pad_len)
        raw = bytes(p.packet[UDP].payload) if p.packet.haslayer(UDP) else b""
        p.packet[UDP].payload = Raw(raw + padding)
        del p.packet[UDP].len
        del p.packet[UDP].chksum
        del p.packet[IP].chksum
        logger.debug("UDP pad +%d bytes", pad_len)
        return [p]

    def __str__(self):
        return "udp_pad{%d,%d}" % (self.min_pad, self.max_pad)

    def mutate(self):
        delta = random.randint(-16, 16)
        new_min = max(0, self.min_pad + delta)
        new_max = max(new_min + 1, self.max_pad + random.randint(-16, 16))
        return UDPPad(new_min, new_max)


# ── UDP Action Tree ───────────────────────────────────────────────────────────

class UDPActionTree:
    """
    A trigger + action chain for UDP packets.
    Simpler than Geneva's binary tree — linear chain for now,
    enough for RL to learn useful strategies.
    """

    def __init__(self, trigger, actions=None):
        self.trigger = trigger
        self.actions = actions or []  # list of UDPAction

    def is_applicable(self, packet, logger):
        return self.trigger.is_applicable(packet, logger)

    def run(self, packet, logger):
        """Apply all actions in sequence."""
        packets = [packet]
        for action in self.actions:
            new_packets = []
            for p in packets:
                result = action.run(p, logger)
                new_packets.extend(result)
            packets = new_packets
            if not packets:
                break
        return packets

    def mutate(self, logger):
        """Random structural mutation."""
        t = UDPActionTree(self.trigger.mutate(),
                          [a for a in self.actions])

        choice = random.random()
        if choice < 0.25 and t.actions:
            # Remove a random action
            idx = random.randrange(len(t.actions))
            t.actions.pop(idx)
        elif choice < 0.5:
            # Add a random action
            new_action = random.choice([
                UDPTamper.random(),
                UDPPad(
                    random.randint(4, 32),
                    random.randint(32, 128)
                ),
                UDPDuplicate(),
                UDPSleep(random.uniform(0.001, 0.05)),
            ])
            t.actions.insert(random.randint(0, len(t.actions)), new_action)
        elif choice < 0.75 and t.actions:
            # Mutate an existing action
            idx = random.randrange(len(t.actions))
            a = t.actions[idx]
            if hasattr(a, "mutate"):
                t.actions[idx] = a.mutate()
        else:
            # Mutate trigger
            t.trigger = self.trigger.mutate()

        return t

    def __str__(self):
        actions_str = "→".join(str(a) for a in self.actions)
        return "%s [%s]" % (self.trigger, actions_str)

    def __len__(self):
        return len(self.actions)


# ── UDP Strategy ──────────────────────────────────────────────────────────────

class UDPStrategy:
    """
    Collection of UDPActionTrees forming a complete UDP obfuscation strategy.
    Equivalent to Geneva's Strategy but for UDP.
    """

    def __init__(self, trees=None, environment_id=None):
        self.trees = trees or []
        self.environment_id = environment_id
        self.fitness = -1000.0

    def act_on_packet(self, packet, logger):
        """Run all applicable trees on the packet."""
        for tree in self.trees:
            if tree.is_applicable(packet, logger):
                return tree.run(packet, logger)
        return [packet]  # no tree matched: pass through

    def mutate(self, logger):
        """Return a mutated copy of this strategy."""
        import copy
        s = UDPStrategy(
            trees=[t.mutate(logger) for t in self.trees],
            environment_id=self.environment_id
        )
        # Occasionally add or remove a tree
        if random.random() < 0.1 and len(s.trees) > 1:
            s.trees.pop(random.randrange(len(s.trees)))
        elif random.random() < 0.1:
            s.trees.append(UDPActionTree(
                UDPTrigger.random(),
                [UDPTamper.random()]
            ))
        return s

    @classmethod
    def random(cls, num_trees=1):
        trees = []
        for _ in range(num_trees):
            trigger = UDPTrigger.random()
            actions = [UDPTamper.random() for _ in range(random.randint(1, 3))]
            trees.append(UDPActionTree(trigger, actions))
        return cls(trees=trees)

    def __str__(self):
        return " | ".join(str(t) for t in self.trees)

    def __len__(self):
        return sum(len(t) for t in self.trees)
